package com.t9dialer.app.ui

import androidx.activity.compose.BackHandler
import com.t9dialer.app.data.UsageLog
import androidx.compose.runtime.collectAsState
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.filled.Link
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import com.t9dialer.app.data.UiStyle
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import com.t9dialer.app.data.numberKey
import com.t9dialer.app.data.EmergencyContact
import com.t9dialer.app.data.AppPrefs
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.content.pm.PackageManager
import android.content.Intent
import android.content.ActivityNotFoundException
import android.app.Activity
import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.t9dialer.app.data.Prefs
import com.t9dialer.app.data.DEFAULT_READY_WA
import com.t9dialer.app.data.DEFAULT_READY_SMS
import com.t9dialer.app.data.READY_COUNT
import com.t9dialer.app.data.ThemeMode
import com.t9dialer.app.data.TapAction
import com.t9dialer.app.data.HomeView
import com.t9dialer.app.data.DialpadSize
import com.t9dialer.app.data.DEFAULT_FONT_SIZE
import com.t9dialer.app.data.FONT_SIZE_RANGE
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.input.KeyboardType
import kotlin.math.roundToInt
import com.t9dialer.app.data.VIBRATE_DURATIONS
import com.t9dialer.app.data.vibrateLabel
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView

private enum class StyleTarget { MAIN, MENUS }

/**
 * Picker with a miniature of each style. For Settings & menus there is also "Same as main screen"
 * (passed back as null).
 */
@Composable
private fun StylePickerDialog(target: StyleTarget, current: UiStyle?, dark: Boolean, onPick: (UiStyle?) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (target == StyleTarget.MAIN) "Main screen style" else "Settings & menus style") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    if (target == StyleTarget.MAIN) "Top bar, lists, quick actions and keypad. Only the look changes; everything stays the same size and in the same place."
                    else "Settings, the \u2630 and \u22ee menus, pop-ups and their screens.",
                    color = c.inkMuted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(bottom = 10.dp),
                )
                if (target == StyleTarget.MENUS) {
                    StyleOption("Same as main screen", selected = current == null, onClick = { onPick(null) }) {
                        Icon(Icons.Filled.Link, contentDescription = null, tint = c.accent, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                }
                UiStyle.entries.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { st ->
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                    .background(if (st == current) c.accent.copy(alpha = 0.16f) else c.inkMuted.copy(alpha = 0.08f))
                                    .border(1.5.dp, if (st == current) c.accent else Color.Transparent, RoundedCornerShape(12.dp))
                                    .clickable { onPick(st) }.padding(6.dp),
                            ) {
                                StyleMiniature(st, dark, Modifier.fillMaxWidth().height(104.dp))
                                Row(Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(st.label, color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
                                    RadioButton(selected = st == current, onClick = null, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun StyleOption(label: String, selected: Boolean, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(if (selected) c.accent.copy(alpha = 0.16f) else c.inkMuted.copy(alpha = 0.08f))
            .border(1.5.dp, if (selected) c.accent else Color.Transparent, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(10.dp))
        Text(label, color = c.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
        RadioButton(selected = selected, onClick = null, modifier = Modifier.size(18.dp))
    }
}

private data class ReadyEdit(val whatsapp: Boolean, val index: Int)

private val OutgoingBlueSettings = androidx.compose.ui.graphics.Color(0xFF1E90FF)
private val WaGreenSettings = androidx.compose.ui.graphics.Color(0xFF25D366)

private enum class TextSetting(val title: String, val help: String) {
    DialPrefix("Prefix for every call", "Added in front of each number you call. Left off numbers that start with + and codes like *123#."),
    LongPressPrefix("Prefix when you long-press call", "For example +91. If it starts with +, a leading 0 in the number is dropped."),
    Lookup("Look up unknown numbers", "Web address to open from an unknown number's menu. {number} is replaced with the number."),
    EmergencyMessage("Emergency message", "Sent as a text to your emergency contacts when you type the emergency code."),
}

private val SHORTCUTS = listOf(
    "Swipe the keypad down to hide it, up to show it.",
    "Swipe a row right to call, left to send a message.",
    "Tap a name for quick actions (call, message, info, WhatsApp), or set it to open the full contact. Tick One touch dialing to call instead.",
    "Tap \u2630 at the top left for Call log, Contacts, Favourites, Frequently called, Add contact and Settings.",
    "Number bar: tap or swipe to move the cursor. Long-press and drag across digits to select them, then Cut, Copy or Paste. Long-press without dragging to Paste or Select all.",
    "Long-press a row for more: speed dial, copy, edit before calling, ready SMS or WhatsApp messages, delete from call log.",
    "In quick actions, long-press SMS or WA chat to pick a ready message.",
    "Long-press 1 for voicemail, 0 for +.",
    "Long-press 2 to 9 to call a speed dial. For 10 to 99, tap the first digit, then long-press the second.",
    "Long-press # to open settings.",
    "Press 0 for a space between first and last name: 5646 0 36 finds John Doe, not John Smith.",
    "Type * in a search to stand for any letters: 5*3 finds J... D...",
    "Long-press call to dial with your long-press prefix.",
)

@Composable
fun SettingsScreen(
    vm: DialerViewModel,
    onBack: () -> Unit,
    onOpenSpeedDial: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenHelp: () -> Unit,
    onOpenAbout: (AboutPage) -> Unit,
) {
    val c = LocalDialerColors.current
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    var editing by rememberSaveable { mutableStateOf<TextSetting?>(null) }
    var choosingTheme by rememberSaveable { mutableStateOf(false) }
    var choosingStyle by rememberSaveable { mutableStateOf<StyleTarget?>(null) }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    var choosingView by rememberSaveable { mutableStateOf(false) }
    var choosingSize by rememberSaveable { mutableStateOf(false) }
    var choosingTap by rememberSaveable { mutableStateOf(false) }
    var choosingFont by rememberSaveable { mutableStateOf(false) }
    var choosingDuration by rememberSaveable { mutableStateOf(false) }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val context = LocalContext.current
    val appVersion = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "Unknown"
    }
    var editingEmergencyCode by rememberSaveable { mutableStateOf(false) }
    var removingEmergency by rememberSaveable { mutableStateOf<Int?>(null) }
    var editingReady by remember { mutableStateOf<ReadyEdit?>(null) }
    var ringtoneFor by remember { mutableStateOf<com.t9dialer.app.data.PhoneEntry?>(null) }
    var usageOn by remember { mutableStateOf(UsageLog.isEnabled()) }
    var showUsageLog by remember { mutableStateOf(false) }
    var confirmClearUsage by remember { mutableStateOf(false) }
    val phoneState by vm.state.collectAsState()
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val emergencyPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val picked = runCatching {
            context.contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) (cur.getString(0) ?: cur.getString(1)) to cur.getString(1) else null
            }
        }.getOrNull()
        val number = picked?.second
        if (picked != null && !number.isNullOrBlank()) {
            vm.updatePrefs { p ->
                if (p.emergencyContacts.any { numberKey(it.number) == numberKey(number) } || p.emergencyContacts.size >= AppPrefs.MAX_EMERGENCY) p
                else p.copy(emergencyContacts = p.emergencyContacts + EmergencyContact(picked.first, number))
            }
        }
    }

    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text("Settings", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(contentPadding = PaddingValues(bottom = navBottom + 24.dp)) {
            // Each section starts collapsed; tap its title to open it
            // Help & guide card at the very top
            item(key = "help") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).clip(RoundedCornerShape(14.dp))
                        .background(c.accent.copy(alpha = 0.14f)).border(1.dp, c.accent.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .clickable { onOpenHelp() }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFF2547C9)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Help & guide", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("How every feature works", color = c.inkMuted, fontSize = 13.sp)
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = c.inkMuted)
                }
            }
            item(key = "h-General") { ExpandHeader("General", "General" in expanded) { expanded = expanded.toggle("General") } }
            if ("General" in expanded) {
                item { ValueRow("Permissions", "See what the app is allowed to do, and unlock blocked ones") { onOpenSetup() } }
                item { ValueRow("Default view", prefs.defaultView.label) { choosingView = true } }
            }

            item(key = "h-Appearance") { ExpandHeader("Appearance", "Appearance" in expanded) { expanded = expanded.toggle("Appearance") } }
            if ("Appearance" in expanded) {
                item { ValueRow("Theme", prefs.theme.label) { choosingTheme = true } }
                item {
                    ValueRow("Settings & menus style", prefs.menuStyle?.label ?: "Same as main screen (${prefs.mainStyle.label})") {
                        choosingStyle = StyleTarget.MENUS
                    }
                }
                item { ValueRow("Main screen style", prefs.mainStyle.label) { choosingStyle = StyleTarget.MAIN } }
                item {
                    SwitchRow(
                        "Allow rotation",
                        "Off: the app stays upright however you hold the phone. On: it turns with the phone, with the list and keypad side by side when sideways.",
                        prefs.allowRotation,
                    ) { on -> vm.updatePrefs { it.copy(allowRotation = on) } }
                }
                item { ValueRow("Dialpad size", prefs.dialpadSize.label) { choosingSize = true } }
                item {
                    ValueRow(
                        "Font size",
                        if (prefs.listFontSize == DEFAULT_FONT_SIZE) "$DEFAULT_FONT_SIZE (default)" else "${prefs.listFontSize} (default $DEFAULT_FONT_SIZE)",
                    ) { choosingFont = true }
                }
                item {
                    CheckboxRow(
                        "Multiline mode",
                        if (prefs.multilineNames) "Long names wrap onto a second line" else "Long names are cut off with \u2026",
                        prefs.multilineNames,
                    ) { on -> vm.updatePrefs { it.copy(multilineNames = on) } }
                }
                item {
                    CheckboxRow(
                        "Show company and job",
                        if (prefs.showOrg) "Job title and company show under each name" else "Only names and numbers are shown",
                        prefs.showOrg,
                    ) { on -> vm.updatePrefs { it.copy(showOrg = on) } }
                }
            }

            item(key = "h-Calling") { ExpandHeader("Calling", "Calling" in expanded) { expanded = expanded.toggle("Calling") } }
            if ("Calling" in expanded) {
                item { ValueRow(TextSetting.DialPrefix.title, prefs.dialPrefix.ifBlank { "None" }) { editing = TextSetting.DialPrefix } }
                item { ValueRow(TextSetting.LongPressPrefix.title, prefs.longPressPrefix.ifBlank { "None" }) { editing = TextSetting.LongPressPrefix } }
                item { ValueRow(TextSetting.Lookup.title, prefs.lookupUrl) { editing = TextSetting.Lookup } }
                item {
                    SwitchRow(
                        "Call forwarding codes",
                        "Off by default. *#21# (check) and ##002# (stop all) always work. Turn on only if you need other forwarding codes; each one still shows a red warning before you can send it.",
                        prefs.forwardingCodes,
                    ) { on ->
                        vm.updatePrefs { it.copy(forwardingCodes = on) }
                        if (on) {
                            Toast.makeText(
                                context,
                                "Call forwarding codes enabled. It's advised to turn this off again as soon as you're done.",
                                Toast.LENGTH_LONG,
                            ).show()
                        }
                    }
                }
            }

            item(key = "h-Emergency") { ExpandHeader("Emergency", "Emergency" in expanded) { expanded = expanded.toggle("Emergency") } }
            if ("Emergency" in expanded) {
                item {
                    Note(
                        if (prefs.emergencyReady) "Type ${prefs.emergencyCode}## on the keypad, or ${prefs.emergencyCode} and the call button, to text your emergency contacts."
                        else "Set a message and at least one contact to turn this on."
                    )
                }
                item {
                    ValueRow(
                        "Emergency code",
                        if (prefs.emergencyCode.isEmpty()) "Off" else "${prefs.emergencyCode}##, or ${prefs.emergencyCode} and the call button",
                    ) { editingEmergencyCode = true }
                }
                item {
                    ValueRow("Emergency message", prefs.emergencyMessage.ifBlank { "Not set yet" }) {
                        editing = TextSetting.EmergencyMessage
                    }
                }
                items(prefs.emergencyContacts.withIndex().toList(), key = { "em${it.index}" }) { (i, e) ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, color = c.ink, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(e.number, color = c.inkMuted, fontSize = 13.sp, maxLines = 1)
                        }
                        // Asks before removing, so a contact isn't lost by an accidental tap
                        IconButton(onClick = { removingEmergency = i }) {
                            Icon(Icons.Filled.Close, contentDescription = "Remove ${e.name}", tint = c.inkMuted)
                        }
                    }
                }
                if (prefs.emergencyContacts.size < AppPrefs.MAX_EMERGENCY) {
                    item {
                        ValueRow(
                            "Add emergency contact",
                            "${prefs.emergencyContacts.size} of ${AppPrefs.MAX_EMERGENCY} added",
                        ) {
                                try { emergencyPicker.launch(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI)) } catch (_: ActivityNotFoundException) {}
                        }
                    }
                }
                item {
                    CheckboxRow("Countdown before sending", "5 seconds to cancel, in case it was typed by accident", prefs.emergencyCountdown) { on ->
                        vm.updatePrefs { it.copy(emergencyCountdown = on) }
                    }
                }
                item {
                    CheckboxRow("Add my location", "Adds a Google Maps link to where you are", prefs.emergencyLocation) { on ->
                        vm.updatePrefs { it.copy(emergencyLocation = on) }
                        if (on) locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }
                item {
                    CheckboxRow(
                        "Call first contact afterwards",
                        "Calls ${prefs.emergencyContacts.firstOrNull()?.name ?: "your first emergency contact"} once the texts are sent",
                        prefs.emergencyCall,
                    ) { on -> vm.updatePrefs { it.copy(emergencyCall = on) } }
                }
            }

            item(key = "h-Search and keypad") { ExpandHeader("Search and keypad", "Search and keypad" in expanded) { expanded = expanded.toggle("Search and keypad") } }
            if ("Search and keypad" in expanded) {
                item {
                    CheckboxRow(
                        "Vibrate on tap",
                        if (prefs.vibrateOnTap) "Keys vibrate when you press them" else "Silent: no vibration",
                        prefs.vibrateOnTap,
                    ) { on -> vm.updatePrefs { it.copy(vibrateOnTap = on) } }
                }
                item {
                    ValueRow(
                        "Vibrate duration",
                        if (prefs.vibrateOnTap) vibrateLabel(prefs.vibrateMs) else "Tick Vibrate on tap to choose",
                        enabled = prefs.vibrateOnTap,
                    ) { choosingDuration = true }
                }
                item {
                    CheckboxRow(
                        "Key tones",
                        if (prefs.keyTones) "Keys play a tone (if the phone's dial-pad tones are on)" else "Off: keys only vibrate",
                        prefs.keyTones,
                    ) { on -> vm.updatePrefs { it.copy(keyTones = on) } }
                }
                item {
                    ValueRow("Tapping a name", prefs.tapAction.label) { choosingTap = true }
                }
                item {
                    CheckboxRow(
                        "One touch dialing",
                        if (prefs.oneTouchDial) "Tap a name to call straight away"
                        else "Off: tapping a name does what's set in Tapping a name",
                        prefs.oneTouchDial,
                    ) { on -> vm.updatePrefs { it.copy(oneTouchDial = on) } }
                }
                item {
                    SwitchRow("Swipe rows to call or message", "Right to call, left to message", prefs.swipeActions) { on ->
                        vm.updatePrefs { it.copy(swipeActions = on) }
                    }
                }
                item {
                    SwitchRow("Russian letters on the keys", "Search finds English and Russian names either way", prefs.cyrillicKeys) { on ->
                        vm.updatePrefs { it.copy(cyrillicKeys = on) }
                    }
                }
            }

            item(key = "h-Ready messages") { ExpandHeader("Ready messages", "Ready messages" in expanded) { expanded = expanded.toggle("Ready messages") } }
            if ("Ready messages" in expanded) {
                item { Note("Long-press SMS or WA chat in a contact's quick actions (or use the long-press menu) to pick one. Tap a line to edit it.") }
                item { Text("SMS (opens Messages with the text typed)", color = OutgoingBlueSettings, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 20.dp, top = 8.dp)) }
                items(READY_COUNT) { i ->
                    ValueRow("SMS ${i + 1}", prefs.readySms.getOrNull(i).orEmpty().ifBlank { "Empty (not shown)" }) { editingReady = ReadyEdit(false, i) }
                }
                item { Text("WhatsApp (opens with the text typed)", color = WaGreenSettings, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 20.dp, top = 12.dp)) }
                items(READY_COUNT) { i ->
                    ValueRow("WhatsApp ${i + 1}", prefs.readyWa.getOrNull(i).orEmpty().ifBlank { "Empty (not shown)" }) { editingReady = ReadyEdit(true, i) }
                }
                item {
                    TextButton(
                        onClick = { vm.updatePrefs { it.copy(readySms = DEFAULT_READY_SMS, readyWa = DEFAULT_READY_WA) } },
                        modifier = Modifier.padding(start = 8.dp),
                    ) { Text("Restore the example messages") }
                }
            }

            item(key = "h-Ringtones") { ExpandHeader("Ringtones", "Ringtones" in expanded) { expanded = expanded.toggle("Ringtones") } }
            if ("Ringtones" in expanded) {
                val withTones = phoneState.contacts.filter { it.ringtone != null }.distinctBy { it.contactId }
                if (withTones.isEmpty()) {
                    item { Note("No contact has a personal ringtone yet. Long-press a contact in the list and choose Set ringtone\u2026") }
                } else {
                    item { Note("Contacts with their own ringtone. Tap one to change or reset it.") }
                    items(withTones, key = { "rt${it.contactId}" }) { e ->
                        val title = rememberRingtoneTitle(e.ringtone)
                        ValueRow(e.name, title ?: "\u2026") { ringtoneFor = e }
                    }
                }
            }

            item(key = "h-Speed dial") { ExpandHeader("Speed dial", "Speed dial" in expanded) { expanded = expanded.toggle("Speed dial") } }
            if ("Speed dial" in expanded) {
                item {
                    val set = prefs.speedDials.size
                    ValueRow(
                        "Edit speed dial",
                        if (set == 0) "Nothing set yet: tap to choose contacts for keys 2 to 9"
                        else "$set set: tap to add, change or remove",
                    ) { onOpenSpeedDial() }
                }
            }

            item(key = "h-Usage log") { ExpandHeader("Usage log", "Usage log" in expanded) { expanded = expanded.toggle("Usage log") } }
            if ("Usage log" in expanded) {
                item {
                    SwitchRow(
                        "Keep a usage log",
                        "Counts which features you use and notes any errors. Never names, numbers, contacts, messages or notes. Stays on this phone.",
                        usageOn,
                    ) { on ->
                        UsageLog.setEnabled(on)
                        usageOn = on
                    }
                }
                item {
                    val errs = UsageLog.errors().size
                    val since = UsageLog.since()?.let { java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(it)) }
                    ValueRow("View log", (since?.let { "Since $it" } ?: "Nothing recorded yet") + " \u00B7 $errs ${if (errs == 1) "error" else "errors"}") { showUsageLog = true }
                }
                item { ValueRow("Send usage report", "Opens your email with the report attached, to $REPORT_EMAIL") { sendUsageReport(context, prefs) } }
                item { ValueRow("Clear log", "Deletes everything recorded so far") { confirmClearUsage = true } }
            }

            item(key = "h-Shortcuts") { ExpandHeader("Shortcuts", "Shortcuts" in expanded) { expanded = expanded.toggle("Shortcuts") } }
            if ("Shortcuts" in expanded) {
                items(SHORTCUTS) { Note(it) }
            }

        }
    }

    if (choosingDuration) {
        DurationDialog(
            current = prefs.vibrateMs,
            onPick = { ms -> vm.updatePrefs { it.copy(vibrateMs = ms) } },
            onDismiss = { choosingDuration = false },
        )
    }

    if (choosingFont) {
        FontSizeDialog(
            current = prefs.listFontSize,
            onSave = { size -> vm.updatePrefs { it.copy(listFontSize = size) }; choosingFont = false },
            onDismiss = { choosingFont = false },
        )
    }

    editingReady?.let { edit ->
        val list = if (edit.whatsapp) prefs.readyWa else prefs.readySms
        var text by remember(edit) { mutableStateOf(list.getOrNull(edit.index).orEmpty()) }
        AlertDialog(
            onDismissRequest = { editingReady = null },
            title = { Text(if (edit.whatsapp) "WhatsApp message ${edit.index + 1}" else "SMS ${edit.index + 1}") },
            text = {
                Column {
                    OutlinedTextField(value = text, onValueChange = { text = it }, minLines = 2)
                    Text("Leave it empty to hide this one.", color = c.inkMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = text.trim()
                    vm.updatePrefs { p ->
                        if (edit.whatsapp) p.copy(readyWa = p.readyWa.toMutableList().also { it[edit.index] = clean })
                        else p.copy(readySms = p.readySms.toMutableList().also { it[edit.index] = clean })
                    }
                    editingReady = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingReady = null }) { Text("Cancel") } },
        )
    }

    removingEmergency?.let { index ->
        val contact = prefs.emergencyContacts.getOrNull(index)
        if (contact == null) {
            removingEmergency = null
        } else {
            AlertDialog(
                onDismissRequest = { removingEmergency = null },
                title = { Text("Remove emergency contact?") },
                text = { Text("${contact.name} (${contact.number}) will no longer get your emergency message.") },
                confirmButton = {
                    TextButton(onClick = {
                        removingEmergency = null
                        vm.updatePrefs { p -> p.copy(emergencyContacts = p.emergencyContacts.filterIndexed { j, _ -> j != index }) }
                    }) { Text("Remove", color = c.missed) }
                },
                dismissButton = { TextButton(onClick = { removingEmergency = null }) { Text("Cancel") } },
            )
        }
    }

    if (editingEmergencyCode) {
        EmergencyCodeDialog(
            current = prefs.emergencyCode,
            vm = vm,
            onSaved = { code -> vm.updatePrefs { it.copy(emergencyCode = code) }; editingEmergencyCode = false },
            onDismiss = { editingEmergencyCode = false },
        )
    }

    if (choosingTap) {
        AlertDialog(
            onDismissRequest = { choosingTap = false },
            title = { Text("Tapping a name") },
            text = {
                Column(Modifier.selectableGroup()) {
                    for (a in TapAction.entries) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .selectable(selected = a == prefs.tapAction, role = Role.RadioButton, onClick = {
                                    vm.updatePrefs { it.copy(tapAction = a) }
                                    choosingTap = false
                                })
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = a == prefs.tapAction, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(a.label, color = LocalDialerColors.current.ink, fontSize = 16.sp)
                                Text(a.summary, color = LocalDialerColors.current.inkMuted, fontSize = 13.sp)
                            }
                        }
                    }
                    Text(
                        "If One touch dialing is ticked, tapping a name calls instead.",
                        color = LocalDialerColors.current.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { choosingTap = false }) { Text("Cancel") } },
        )
    }

    if (choosingSize) {
        SizeDialog(
            current = prefs.dialpadSize,
            onPick = { size -> vm.updatePrefs { it.copy(dialpadSize = size) }; choosingSize = false },
            onDismiss = { choosingSize = false },
        )
    }

    if (choosingView) {
        ViewDialog(
            current = prefs.defaultView,
            onPick = { v -> vm.updatePrefs { it.copy(defaultView = v) }; choosingView = false },
            onDismiss = { choosingView = false },
        )
    }

    if (showUsageLog) {
        UsageLogScreen(prefs, onBack = { showUsageLog = false })
        return
    }
    if (confirmClearUsage) {
        AlertDialog(
            onDismissRequest = { confirmClearUsage = false },
            title = { Text("Clear usage log?") },
            text = { Text("Everything recorded so far is deleted. The log keeps running if it's switched on.") },
            confirmButton = { TextButton(onClick = { UsageLog.clear(); confirmClearUsage = false; Toast.makeText(context, "Usage log cleared", Toast.LENGTH_SHORT).show() }) { Text("Clear", color = c.missed) } },
            dismissButton = { TextButton(onClick = { confirmClearUsage = false }) { Text("Cancel") } },
        )
    }

    ringtoneFor?.let { e ->
        RingtonePicker(vm, e.name, e.contactId, current = e.ringtone, onDismiss = { ringtoneFor = null })
    }

    choosingStyle?.let { target ->
        StylePickerDialog(
            target = target,
            current = if (target == StyleTarget.MAIN) prefs.mainStyle else prefs.menuStyle,
            dark = isDark(prefs.theme),
            onPick = { picked ->
                vm.updatePrefs { p -> if (target == StyleTarget.MAIN) p.copy(mainStyle = picked ?: UiStyle.CLASSIC) else p.copy(menuStyle = picked) }
                choosingStyle = null
            },
            onDismiss = { choosingStyle = null },
        )
    }

    if (choosingTheme) {
        ThemeDialog(
            current = prefs.theme,
            onPick = { mode -> vm.updatePrefs { it.copy(theme = mode) }; choosingTheme = false },
            onDismiss = { choosingTheme = false },
        )
    }

    editing?.let { setting ->
        TextSettingDialog(setting, prefs, onSave = { value ->
            vm.updatePrefs {
                when (setting) {
                    TextSetting.DialPrefix -> it.copy(dialPrefix = value.trim())
                    TextSetting.LongPressPrefix -> it.copy(longPressPrefix = value.trim())
                    TextSetting.Lookup -> it.copy(lookupUrl = value.trim().ifBlank { Prefs.DEFAULT_LOOKUP_URL })
                    TextSetting.EmergencyMessage -> it.copy(emergencyMessage = value.trim())
                }
            }
            editing = null
        }, onDismiss = { editing = null })
    }
}

/** Type a size or drag the slider; the default is always shown, with a button to go back to it. */
@Composable
private fun FontSizeDialog(current: Int, onSave: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var size by remember { mutableIntStateOf(current) }
    var input by remember { mutableStateOf(current.toString()) }
    val typed = input.toIntOrNull()
    val valid = typed != null && typed in FONT_SIZE_RANGE
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Font size") },
        text = {
            Column {
                Text("Default size: $DEFAULT_FONT_SIZE", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Text size for names in Call log, Contacts and search results. Numbers and details grow or shrink with it.",
                    color = c.inkMuted, fontSize = 13.sp, lineHeight = 18.sp,
                )
                Spacer(Modifier.height(12.dp))
                // Live preview at the chosen size
                Surface(color = c.bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text("Shubham Mittal", color = c.ink, fontSize = size.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text("+91 99 58 959820", color = c.inkMuted, fontSize = (size * 13f / 16f).sp, maxLines = 1)
                    }
                }
                Slider(
                    value = size.toFloat(),
                    onValueChange = { v -> size = v.roundToInt(); input = size.toString() },
                    valueRange = FONT_SIZE_RANGE.first.toFloat()..FONT_SIZE_RANGE.last.toFloat(),
                    steps = FONT_SIZE_RANGE.last - FONT_SIZE_RANGE.first - 1,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { v ->
                            input = v.filter { it.isDigit() }.take(2)
                            input.toIntOrNull()?.takeIf { it in FONT_SIZE_RANGE }?.let { size = it }
                        },
                        label = { Text("Size") },
                        singleLine = true,
                        isError = !valid,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(110.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    TextButton(
                        enabled = size != DEFAULT_FONT_SIZE,
                        onClick = { size = DEFAULT_FONT_SIZE; input = DEFAULT_FONT_SIZE.toString() },
                    ) { Text("Use default ($DEFAULT_FONT_SIZE)") }
                }
                if (!valid) {
                    Text(
                        "Enter a size from ${FONT_SIZE_RANGE.first} to ${FONT_SIZE_RANGE.last}.",
                        color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onSave(size) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SizeDialog(current: DialpadSize, onPick: (DialpadSize) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dialpad size") },
        text = {
            Column(Modifier.selectableGroup()) {
                for (size in DialpadSize.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .selectable(selected = size == current, role = Role.RadioButton, onClick = { onPick(size) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = size == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        // Each option is written at roughly the size its digits will be
                        Text("5", color = c.ink, fontSize = 22.sp * size.scale, modifier = Modifier.width(30.dp))
                        Text(size.label, color = c.ink, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ViewDialog(current: HomeView, onPick: (HomeView) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Default view") },
        text = {
            Column(Modifier.selectableGroup()) {
                Text("What the app shows when it opens.", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                for (v in HomeView.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .selectable(selected = v == current, role = Role.RadioButton, onClick = { onPick(v) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = v == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(v.label, color = c.ink, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ThemeDialog(current: ThemeMode, onPick: (ThemeMode) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Theme") },
        text = {
            Column(Modifier.selectableGroup()) {
                for (mode in ThemeMode.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .selectable(selected = mode == current, role = Role.RadioButton, onClick = { onPick(mode) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = mode == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(mode.label, color = c.ink, fontSize = 16.sp)
                            if (mode == ThemeMode.SYSTEM) {
                                Text("Follows your phone's dark mode", color = c.inkMuted, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

/** Picking an option vibrates once at that length so you can feel it; the dialog stays open to compare. */
@Composable
private fun DurationDialog(current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val view = LocalView.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Vibrate duration") },
        text = {
            Column(Modifier.selectableGroup().verticalScroll(rememberScrollState())) {
                Text("Tap an option to feel it.", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                for (ms in VIBRATE_DURATIONS) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .selectable(selected = ms == current, role = Role.RadioButton, onClick = {
                                onPick(ms)
                                if (ms <= 0) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                else vibrateFor(context, ms)
                            }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = ms == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(vibrateLabel(ms), color = c.ink, fontSize = 16.sp)
                        if (ms <= 0) Text("  phone's own light tick", color = c.inkMuted, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

private fun Set<String>.toggle(name: String) = if (name in this) this - name else this + name

/** A section title you tap to open or close the settings under it. */
@Composable
private fun ExpandHeader(title: String, open: Boolean, onToggle: () -> Unit) {
    val c = LocalDialerColors.current
    val look = LocalMenuLook.current
    val chevron = if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore
    val label = if (open) "Close $title" else "Open $title"
    when {
        // Small grey capitals above each group (kept for possible future styles)
        look.headerCaps -> Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title.uppercase(), color = if (open) c.accent else c.inkMuted, fontSize = 13.sp, letterSpacing = 0.4.sp, modifier = Modifier.weight(1f))
            Icon(chevron, contentDescription = label, tint = c.inkMuted, modifier = Modifier.size(20.dp))
        }
        // Flat: each section on its own solid colour
        look.headerSolid -> Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(look.corner))
                .background(sectionColor(title)).clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(chevron, contentDescription = label, tint = Color.White)
        }
        // Neumorphic (raised, pressed in when open) and Glassmorphic (frosted)
        look.headerFill != null -> {
            val shape = RoundedCornerShape(look.corner)
            val base = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
            val deco = if (look.style == UiStyle.NEUMORPHIC) {
                if (open) base.clip(shape).background(look.shadowDark.copy(alpha = 0.25f))
                else base.softRaised(look.headerFill, look.shadowLight, look.shadowDark, look.corner)
            } else {
                base.clip(shape).background(look.headerFill).border(1.dp, Color.White.copy(alpha = 0.28f), shape)
            }
            Row(deco.clip(shape).clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = if (open) c.accent else c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(chevron, contentDescription = label, tint = c.inkMuted)
            }
        }
        // Classic
        else -> Column {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(title, color = if (open) c.accent else c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(chevron, contentDescription = label, tint = c.inkMuted)
            }
            HorizontalDivider(thickness = 0.5.dp, color = c.inkMuted.copy(alpha = 0.22f))
        }
    }
}

/** 3 to 6 digits; ## is added when typing it. Must differ from the notes codes. */
@Composable
private fun EmergencyCodeDialog(current: String, vm: DialerViewModel, onSaved: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf(current) }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Emergency code") },
        text = {
            Column {
                Text("3 to 6 digits. Type them followed by ##, or press the call button after them.", color = c.inkMuted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { v -> code = v.filter { it.isDigit() }.take(6); error = null },
                    label = { Text("Code") },
                    suffix = { Text("##") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                error?.let { Text(it, color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(enabled = !checking, onClick = {
                if (code.length !in 3..6) {
                    error = "Use 3 to 6 digits."
                } else {
                    checking = true
                    scope.launch {
                        val clash = withContext(Dispatchers.Default) { vm.vault.isUsed("$code##") }
                        checking = false
                        if (clash) error = "Choose a different code." else onSaved(code)
                    }
                }
            }) { Text(if (checking) "Checking…" else "Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ValueRow(title: String, value: String, enabled: Boolean = true, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(title, color = if (enabled) c.ink else c.inkMuted.copy(alpha = 0.6f), fontSize = 16.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, color = c.inkMuted, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CheckboxRow(title: String, summary: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.ink, fontSize = 16.sp)
            Spacer(Modifier.height(2.dp))
            Text(summary, color = c.inkMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.width(12.dp))
        Checkbox(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SwitchRow(title: String, summary: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.ink, fontSize = 16.sp)
            Spacer(Modifier.height(2.dp))
            Text(summary, color = c.inkMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        color = LocalDialerColors.current.inkMuted,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
    )
}

@Composable
private fun TextSettingDialog(setting: TextSetting, prefs: Prefs, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val initial = when (setting) {
        TextSetting.DialPrefix -> prefs.dialPrefix
        TextSetting.LongPressPrefix -> prefs.longPressPrefix
        TextSetting.Lookup -> prefs.lookupUrl
        TextSetting.EmergencyMessage -> prefs.emergencyMessage
    }
    var value by remember(setting) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(setting.title) },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    singleLine = setting != TextSetting.EmergencyMessage,
                    minLines = if (setting == TextSetting.EmergencyMessage) 3 else 1,
                )
                Spacer(Modifier.height(10.dp))
                Text(setting.help, color = c.inkMuted, fontSize = 14.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(value) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
