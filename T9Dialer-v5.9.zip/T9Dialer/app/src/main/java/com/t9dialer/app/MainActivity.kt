package com.t9dialer.app

import android.content.Intent
import android.graphics.Color
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.t9dialer.app.ui.DialerApp
import com.t9dialer.app.ui.DialerTheme
import com.t9dialer.app.ui.DialerViewModel
import com.t9dialer.app.ui.isDark
import com.t9dialer.app.data.UiStyle

class MainActivity : ComponentActivity() {

    private val vm: DialerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.t9dialer.app.data.UsageLog.init(applicationContext)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            runCatching {
                val where = e.stackTrace.firstOrNull { it.className.startsWith("com.t9dialer") }
                com.t9dialer.app.data.UsageLog.error(
                    "App closed unexpectedly: ${e.javaClass.simpleName}" +
                        (where?.let { " in ${it.className.substringAfterLast('.')}.${it.methodName}" } ?: ""),
                )
            }
            previous?.uncaughtException(thread, e)
        }
        enableEdgeToEdge()   // required on Android 16; the UI handles system bar insets itself
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            val prefs by vm.prefs.collectAsStateWithLifecycle()
            val dark = isDark(prefs.theme)
            // Keep status and navigation bar icons readable: light icons on dark themes, and on the
            // Glassmorphic background or the solid blue Flat top bar whatever the theme
            val lightIcons = dark || prefs.mainStyle == UiStyle.GLASS || prefs.mainStyle == UiStyle.FLAT ||
                (prefs.menuStyle ?: prefs.mainStyle) == UiStyle.GLASS
            // Off (default): the app stays upright, ignoring how the phone is held. On: it turns with the phone,
            // following the phone's own auto-rotate setting.
            LaunchedEffect(prefs.allowRotation) {
                requestedOrientation = if (prefs.allowRotation) ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                else ActivityInfo.SCREEN_ORIENTATION_NOSENSOR
            }
            LaunchedEffect(lightIcons) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightIcons) SystemBarStyle.dark(Color.TRANSPARENT)
                                     else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = if (lightIcons) SystemBarStyle.dark(Color.TRANSPARENT)
                                         else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                )
            }
            DialerTheme(dark) { DialerApp(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Pre-fills the keypad when another app or a tel: link asks to dial a number. */
    private fun handleIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "tel") vm.setQuery(data.schemeSpecificPart.orEmpty())
    }
}
