package com.t9dialer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.t9dialer.app.data.UiStyle

/*
 * Visual styles. A style only changes colours, fills, borders and shadows. It never changes
 * sizes, padding or spacing, so every style shows exactly what Classic shows, in the same place.
 */

/** How keypad keys are decorated (drawn behind the digit, inside the key's existing cell). */
enum class KeyDeco { NONE, RAISED, ROUND, SQUARE, GLASS }

/** Extra looks for the main screen, on top of the colours in [DialerColors]. */
@Immutable
data class MainLook(
    val style: UiStyle,
    val background: Brush,
    val rowBg: Color,
    val divider: Color,
    val dividerHighlight: Color?,     // second, lighter line under the divider (Neumorphic groove)
    val swipeContentBg: Color,        // behind a row while it isn't being swiped
    val topBarBg: Color,
    val topBarMono: Boolean,          // top bar icons in the text colour (on a solid coloured bar)
    val tabPill: Color?,              // background behind the selected tab
    val keypadBg: Color,
    val keypadBorder: Color?,
    val keypadShadow: Dp,
    val numberBarBg: Color,
    val keyDeco: KeyDeco,
    val keyFill: Color,
    val shadowLight: Color,
    val shadowDark: Color,
    val lightStatusIcons: Boolean,    // a dark background under the status bar, whatever the theme
)

/** Extra looks for Settings, the menus and pop-ups. */
@Immutable
data class MenuLook(
    val style: UiStyle,
    val background: Brush,
    val headerFill: Color?,           // behind a section title (null: plain title with a line)
    val headerSolid: Boolean,         // Flat: each section title on its own solid colour
    val headerCaps: Boolean,          // small grey capitals above each group (not used by any style now)
    val cardFill: Color,              // menus, drawer items, sheets
    val iconTile: Boolean,            // icons on coloured rounded squares
    val iconRaised: Boolean,          // Neumorphic: icons on raised circles
    val selectedFill: Color,
    val shadowLight: Color,
    val shadowDark: Color,
    val corner: Dp,
)

val LocalMainLook = staticCompositionLocalOf { mainLook(UiStyle.CLASSIC, true) }
val LocalMenuLook = staticCompositionLocalOf { menuLook(UiStyle.CLASSIC, true) }
/** Colours for Settings and menus, which can differ from the main screen's. */
val LocalMenuColors = staticCompositionLocalOf { ClassicDark }

private val GlassGradient = Brush.linearGradient(
    listOf(Color(0xFF3B2B7A), Color(0xFF1F4FA8), Color(0xFF0F7E86), Color(0xFF8E3B5A)),
)

/** Text and accent colours for a style. Grey text is kept light enough to read on its background. */
fun styleColors(style: UiStyle, dark: Boolean): DialerColors = when (style) {
    UiStyle.CLASSIC -> if (dark) ClassicDark else ClassicLight
    UiStyle.NEUMORPHIC -> if (dark) ClassicDark.copy(bg = Color(0xFF232A35), panel = Color(0xFF232A35))
                          else ClassicLight.copy(bg = Color(0xFFE6EBF1), panel = Color(0xFFE6EBF1), inkMuted = Color(0xFF56616F))
    UiStyle.FLAT -> if (dark) ClassicDark.copy(bg = Color(0xFF1B212B), panel = Color(0xFF262F3D), ink = Color.White, inkMuted = Color(0xFFB3BDCB), accent = Color(0xFF8FB0FF))
                    else ClassicLight.copy(bg = Color(0xFFF4F6F9), panel = Color.White, inkMuted = Color(0xFF55606F))
    UiStyle.GLASS -> ClassicDark.copy(
        bg = Color.Transparent, panel = Color(0x2EFFFFFF), ink = Color.White, inkMuted = Color(0xFFE3E8F0),
        accent = Color(0xFFB8F5D8), onAccent = Color(0xFF0E3B2C), call = Color(0xFF7CF0BF), missed = Color(0xFFFFB4A9),
    )
}

fun mainLook(style: UiStyle, dark: Boolean): MainLook {
    val c = styleColors(style, dark)
    val hiN = if (dark) Color(0xFF2F3846) else Color.White
    val loN = if (dark) Color(0xFF141920) else Color(0xFFBFC8D3)
    return when (style) {
        // Classic, dark: black behind the top bar and lists; the keypad keeps its own colours
        UiStyle.CLASSIC -> {
            val screen = if (dark) Color.Black else c.bg
            MainLook(style, Brush.linearGradient(listOf(screen, screen)), Color.Transparent,
                c.inkMuted.copy(alpha = 0.22f), null, screen, Color.Transparent, false, null,
                c.panel, c.accent.copy(alpha = 0.7f), 12.dp, c.bg, KeyDeco.NONE, Color.Transparent, hiN, loN, false)
        }
        UiStyle.NEUMORPHIC -> MainLook(style, Brush.linearGradient(listOf(c.bg, c.bg)), Color.Transparent,
            loN.copy(alpha = if (dark) 0.9f else 0.7f), hiN.copy(alpha = 0.6f), c.bg, Color.Transparent, false, loN.copy(alpha = 0.35f),
            c.bg, null, 10.dp, if (dark) Color(0xFF1E242E) else Color(0xFFDDE3EA), KeyDeco.RAISED, c.bg, hiN, loN, false)
        UiStyle.FLAT -> MainLook(style, Brush.linearGradient(listOf(c.bg, c.bg)), c.panel,
            c.bg, null, c.panel, Color(0xFF2547C9), true, Color.White.copy(alpha = 0.22f),
            c.panel, null, 0.dp, c.bg, KeyDeco.SQUARE, if (dark) Color(0xFF313B4C) else Color(0xFFE8ECF2), hiN, loN, false)
        UiStyle.GLASS -> MainLook(style, GlassGradient, Color(0x1FFFFFFF),
            Color.White.copy(alpha = 0.16f), null, Color.Transparent, Color(0x26FFFFFF), false, Color.White.copy(alpha = 0.22f),
            Color(0x47101830), Color.White.copy(alpha = 0.3f), 0.dp, Color(0x33000000), KeyDeco.GLASS, Color(0x24FFFFFF), hiN, loN, true)
    }
}

fun menuLook(style: UiStyle, dark: Boolean): MenuLook {
    val c = styleColors(style, dark)
    val hiN = if (dark) Color(0xFF2F3846) else Color.White
    val loN = if (dark) Color(0xFF141920) else Color(0xFFBFC8D3)
    return when (style) {
        UiStyle.CLASSIC -> MenuLook(style, Brush.linearGradient(listOf(c.bg, c.bg)), null, false, false, c.panel, false, false,
            c.accent.copy(alpha = 0.15f), hiN, loN, 6.dp)
        UiStyle.NEUMORPHIC -> MenuLook(style, Brush.linearGradient(listOf(c.bg, c.bg)), c.bg, false, false, c.bg, false, true,
            loN.copy(alpha = 0.35f), hiN, loN, 14.dp)
        UiStyle.FLAT -> MenuLook(style, Brush.linearGradient(listOf(c.bg, c.bg)), null, true, false, c.panel, true, false,
            Color(0xFF2547C9), hiN, loN, 8.dp)
        UiStyle.GLASS -> MenuLook(style, GlassGradient, Color(0x29FFFFFF), false, false, Color(0xE6253066), false, false,
            Color.White.copy(alpha = 0.22f), hiN, loN, 16.dp)
    }
}

/** Soft raised shadow (Neumorphic): a light glow top-left and a dark shade bottom-right, drawn behind. */
fun Modifier.softRaised(fill: Color, light: Color, dark: Color, corner: Dp, blur: Dp = 6.dp, offset: Dp = 3.dp, inset: Dp = 0.dp) =
    drawBehind { drawSoft(fill, light, dark, corner.toPx(), blur.toPx(), offset.toPx(), inset.toPx()) }

private fun DrawScope.drawSoft(fill: Color, light: Color, dark: Color, corner: Float, blur: Float, offset: Float, inset: Float) {
    drawIntoCanvas { canvas ->
        val paint = Paint().asFrameworkPaint().apply { isAntiAlias = true; color = fill.toArgb() }
        val l = inset; val t = inset; val r = size.width - inset; val b = size.height - inset
        paint.setShadowLayer(blur, offset, offset, dark.toArgb())
        canvas.nativeCanvas.drawRoundRect(l, t, r, b, corner, corner, paint)
        paint.setShadowLayer(blur, -offset, -offset, light.toArgb())
        canvas.nativeCanvas.drawRoundRect(l, t, r, b, corner, corner, paint)
    }
}

/** Draws the chosen key decoration inside the key's own cell (the cell's size is unchanged). */
fun Modifier.keyDecoration(look: MainLook): Modifier = if (look.keyDeco == KeyDeco.NONE) this else drawBehind {
    val side = minOf(size.width, size.height) - 6.dp.toPx()
    val left = (size.width - side) / 2f
    val top = (size.height - side) / 2f
    when (look.keyDeco) {
        KeyDeco.RAISED -> drawIntoCanvas { canvas ->
            val paint = Paint().asFrameworkPaint().apply { isAntiAlias = true; color = look.keyFill.toArgb() }
            val rad = side / 2f; val cx = size.width / 2f; val cy = size.height / 2f
            paint.setShadowLayer(4.dp.toPx(), 2.dp.toPx(), 2.dp.toPx(), look.shadowDark.toArgb())
            canvas.nativeCanvas.drawCircle(cx, cy, rad, paint)
            paint.setShadowLayer(4.dp.toPx(), -2.dp.toPx(), -2.dp.toPx(), look.shadowLight.toArgb())
            canvas.nativeCanvas.drawCircle(cx, cy, rad, paint)
        }
        KeyDeco.ROUND -> drawCircle(look.keyFill, radius = side / 2f)
        KeyDeco.SQUARE -> drawRoundRect(
            look.keyFill, topLeft = androidx.compose.ui.geometry.Offset(3.dp.toPx(), top),
            size = androidx.compose.ui.geometry.Size(size.width - 6.dp.toPx(), side),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
        )
        KeyDeco.GLASS -> {
            val tl = androidx.compose.ui.geometry.Offset(3.dp.toPx(), top)
            val sz = androidx.compose.ui.geometry.Size(size.width - 6.dp.toPx(), side)
            val cr = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx())
            drawRoundRect(look.keyFill, topLeft = tl, size = sz, cornerRadius = cr)
            drawRoundRect(Color.White.copy(alpha = 0.22f), topLeft = tl, size = sz, cornerRadius = cr,
                style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        }
        KeyDeco.NONE -> Unit
    }
}

/** A solid colour for each Settings section title in the Flat style. */
fun sectionColor(title: String): Color = when (title) {
    "General" -> Color(0xFF2547C9)
    "Appearance" -> Color(0xFF7B3FBF)
    "Calling" -> Color(0xFF2E7D5B)
    "Emergency" -> Color(0xFFC0392B)
    "Search and keypad" -> Color(0xFF1E78D6)
    "Ready messages" -> Color(0xFF1FA855)
    "Speed dial" -> Color(0xFFE07A1E)
    "Ringtones" -> Color(0xFFB8860B)
    "Usage log" -> Color(0xFF00897B)
    "Shortcuts" -> Color(0xFF5D6B7E)
    "About" -> Color(0xFFD6457B)
    else -> Color(0xFF2547C9)
}

/** Miniature of a style for the picker: title bar, two rows, a switch, keys and the call button. */
@Composable
fun StyleMiniature(style: UiStyle, dark: Boolean, modifier: Modifier = Modifier) {
    val c = styleColors(style, dark)
    val m = mainLook(style, dark)
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(m.background)
            .border(1.dp, c.inkMuted.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .padding(7.dp),
    ) {
        Column(Modifier.fillMaxWidth()) {
            if (m.topBarMono) {
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(3.dp)).background(m.topBarBg))
            } else {
                Box(Modifier.width(44.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(c.ink.copy(alpha = 0.85f)))
            }
            Spacer(Modifier.height(6.dp))
            repeat(2) { i ->
                val rowMod = when (style) {
                    UiStyle.NEUMORPHIC -> Modifier.softRaised(c.bg, m.shadowLight, m.shadowDark, 5.dp, 3.dp, 1.5.dp)
                    UiStyle.FLAT -> Modifier.clip(RoundedCornerShape(3.dp)).background(m.rowBg)
                    UiStyle.GLASS -> Modifier.clip(RoundedCornerShape(6.dp)).background(m.rowBg).border(0.5.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                    UiStyle.CLASSIC -> Modifier
                }
                Row(rowMod.fillMaxWidth().padding(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    val shape = if (style == UiStyle.CLASSIC || style == UiStyle.FLAT) RoundedCornerShape(2.dp) else CircleShape
                    Box(Modifier.size(11.dp).clip(shape).background(c.avatars[i].first))
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.inkMuted.copy(alpha = 0.55f)))
                    if (i == 1) {
                        Spacer(Modifier.width(4.dp))
                        Box(Modifier.width(16.dp).height(9.dp).clip(RoundedCornerShape(5.dp)).background(c.accent)) {
                            Box(Modifier.align(Alignment.CenterEnd).offset(x = (-1).dp).size(7.dp).clip(CircleShape).background(Color.White))
                        }
                    }
                }
                if (style == UiStyle.CLASSIC) Box(Modifier.fillMaxWidth().height(0.5.dp).background(m.divider)) else Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                repeat(3) {
                    Box(Modifier.weight(1f).height(12.dp).keyDecoration(m)) {
                        if (m.keyDeco == KeyDeco.NONE) Box(Modifier.align(Alignment.Center).size(4.dp).clip(CircleShape).background(c.ink))
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier.align(Alignment.CenterHorizontally).width(30.dp).height(11.dp)
                    .clip(RoundedCornerShape(if (style == UiStyle.FLAT) 3.dp else 6.dp)).background(c.call),
            )
        }
    }
}
