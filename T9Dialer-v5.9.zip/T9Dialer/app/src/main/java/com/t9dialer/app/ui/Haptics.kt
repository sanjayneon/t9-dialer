package com.t9dialer.app.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Vibrates for exactly [ms] milliseconds. */
fun vibrateFor(context: Context, ms: Int) {
    if (ms <= 0) return
    val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
        context.getSystemService(VibratorManager::class.java)?.defaultVibrator
    } else {
        context.getSystemService(Vibrator::class.java)
    }
    if (vibrator == null || !vibrator.hasVibrator()) return
    runCatching { vibrator.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE)) }
}

/**
 * Warning vibration and tone for warning pages: three strong pulses and an error tone, played on the
 * alarm stream so it is heard even when the ringer is quiet.
 */
fun playWarning(context: android.content.Context) {
    try {
        val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(android.content.Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
        }
        vibrator.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 400, 150, 400, 150, 700), -1))
    } catch (_: Exception) { }
    try {
        val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_ALARM, 90)
        tone.startTone(android.media.ToneGenerator.TONE_SUP_ERROR, 1500)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ tone.release() }, 1800)
    } catch (_: Exception) { }
}
