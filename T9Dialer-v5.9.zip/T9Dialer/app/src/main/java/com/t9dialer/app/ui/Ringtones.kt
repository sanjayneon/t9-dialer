package com.t9dialer.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The phone's own ringtones, as (title, address) pairs. */
private fun phoneRingtones(context: Context): List<Pair<String, String>> = try {
    val rm = RingtoneManager(context).apply { setType(RingtoneManager.TYPE_RINGTONE) }
    val out = ArrayList<Pair<String, String>>()
    rm.cursor.use { c ->
        while (c.moveToNext()) {
            val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: continue
            val uri = rm.getRingtoneUri(c.position)?.toString() ?: continue
            out += title to uri
        }
    }
    out
} catch (_: Exception) {
    emptyList()
}

/** A ringtone's name for display, e.g. "Sunrise" or "Kesariya.mp3". Slow: call off the main thread. */
fun ringtoneTitle(context: Context, uri: String): String =
    runCatching { RingtoneManager.getRingtone(context, Uri.parse(uri))?.getTitle(context) }.getOrNull()
        ?.takeIf { it.isNotBlank() } ?: "Personal ringtone"

/** The title of [uri] once it has been looked up (null while loading or for no ringtone). */
@Composable
fun rememberRingtoneTitle(uri: String?): String? {
    val context = LocalContext.current
    val title by produceState<String?>(null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) { ringtoneTitle(context, uri) }
    }
    return title
}

/**
 * Picks a personal ringtone for one contact: a song or sound file, the phone's default, or one of the
 * phone's ringtones (tap ▶ to hear it). Saving writes it into the phone's contacts, so the phone plays it
 * when that person calls. Asks for permission to change contacts the first time.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RingtonePicker(vm: DialerViewModel, name: String, contactId: Long, current: String?, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tones by produceState<List<Pair<String, String>>?>(null) { value = withContext(Dispatchers.IO) { phoneRingtones(context) } }
    var selected by remember { mutableStateOf(current) }          // null = the phone's default
    var playing by remember { mutableStateOf<String?>(null) }
    val player = remember { mutableStateOf<Ringtone?>(null) }
    var pending by remember { mutableStateOf<Pair<Boolean, String?>?>(null) }   // (waiting, uri) while asking permission

    fun stop() {
        runCatching { player.value?.stop() }
        player.value = null
        playing = null
    }
    fun preview(uri: String) {
        stop()
        runCatching { RingtoneManager.getRingtone(context, Uri.parse(uri)) }.getOrNull()?.let {
            runCatching { it.play() }
            player.value = it
            playing = uri
        }
    }
    DisposableEffect(Unit) { onDispose { stop() } }

    fun doSave(uri: String?) {
        stop()
        vm.setRingtone(contactId, uri) { ok ->
            Toast.makeText(
                context,
                when {
                    !ok -> "Couldn't change the ringtone"
                    uri == null -> "$name now uses the default ringtone"
                    else -> "Ringtone set for $name"
                },
                Toast.LENGTH_SHORT,
            ).show()
            if (ok) onDismiss()
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val p = pending
        pending = null
        if (granted && p != null) doSave(p.second)
        else if (!granted) Toast.makeText(context, "Allow Dialer NEXT to change contacts to set a ringtone", Toast.LENGTH_LONG).show()
    }
    fun save(uri: String?) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            doSave(uri)
        } else {
            pending = true to uri
            permission.launch(Manifest.permission.WRITE_CONTACTS)
        }
    }
    val songPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val ready = vm.importRingtone(uri)
            if (ready != null) save(ready) else Toast.makeText(context, "Couldn't use that file as a ringtone", Toast.LENGTH_SHORT).show()
        }
    }

    ModalBottomSheet(onDismissRequest = { stop(); onDismiss() }, containerColor = LocalMenuLook.current.cardFill) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).heightIn(max = 600.dp)) {
            Text("Ringtone for $name", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.accent.copy(alpha = 0.10f))
                    .clickable { stop(); songPicker.launch(arrayOf("audio/*")) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.MusicNote, contentDescription = null, tint = c.accent)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Choose a song or sound file\u2026", color = c.accent, fontSize = 15.sp)
                    Text("From music and downloads on your phone", color = c.inkMuted, fontSize = 12.sp)
                }
            }
            ToneRow("Default ringtone", "phone's own", selected == null, playingThis = false, onSelect = { stop(); selected = null }, onPlay = null)
            Text("PHONE RINGTONES", color = c.inkMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
            val list = tones
            if (list == null) {
                CircularProgressIndicator(Modifier.padding(16.dp).align(Alignment.CenterHorizontally))
            } else {
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    // A personal tone that isn't one of the phone's (e.g. a song) is listed first
                    val extra = current?.takeIf { cur -> list.none { it.second == cur } }
                    if (extra != null) {
                        item { ToneRow(rememberRingtoneTitle(extra) ?: "Current ringtone", "current", selected == extra, playing == extra, { selected = extra }, { if (playing == extra) stop() else preview(extra) }) }
                    }
                    items(list, key = { it.second }) { (title, uri) ->
                        ToneRow(title, null, selected == uri, playing == uri, { selected = uri }, { if (playing == uri) stop() else preview(uri) })
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { save(selected) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
                shape = RoundedCornerShape(12.dp),
            ) { Text("Save", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun ToneRow(title: String, note: String?, selected: Boolean, playingThis: Boolean, onSelect: () -> Unit, onPlay: (() -> Unit)?) {
    val c = LocalDialerColors.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onSelect).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(title, color = if (selected) c.accent else c.ink, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (note != null) Text(note, color = c.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
        if (onPlay != null) {
            IconButton(onClick = onPlay) {
                Icon(if (playingThis) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = if (playingThis) "Stop" else "Play", tint = c.accent, modifier = Modifier.size(24.dp))
            }
        }
    }
}
