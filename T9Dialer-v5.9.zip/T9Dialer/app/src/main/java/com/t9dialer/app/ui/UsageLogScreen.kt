package com.t9dialer.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.t9dialer.app.data.Prefs
import com.t9dialer.app.data.UsageLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Where usage reports are sent. */
const val REPORT_EMAIL = "san222@gmail.com"

private fun appVersion(context: Context): String =
    runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"

/** The settings summary included in the report (choices only, nothing personal). */
fun usageSettings(p: Prefs): List<Pair<String, String>> = listOf(
    "Main screen style" to p.mainStyle.label,
    "Settings & menus style" to (p.menuStyle?.label ?: "Same as main screen"),
    "Theme" to p.theme.label,
    "Font size" to p.listFontSize.toString(),
    "Dialpad size" to p.dialpadSize.label,
    "Default view" to p.defaultView.label,
    "One touch dialing" to if (p.oneTouchDial) "On" else "Off",
    "Swipe rows" to if (p.swipeActions) "On" else "Off",
    "Vibrate on tap" to if (p.vibrateOnTap) "On" else "Off",
    "Key tones" to if (p.keyTones) "On" else "Off",
    "Emergency message set up" to if (p.emergencyReady) "Yes" else "No",
    "Speed dials set" to p.speedDials.size.toString(),
)

/**
 * Opens the user's email app with the report attached and san222@gmail.com filled in.
 * Nothing is sent until the user taps Send there.
 */
fun sendUsageReport(context: Context, prefs: Prefs) {
    val version = appVersion(context)
    val text = UsageLog.report(version, usageSettings(prefs))
    val dir = File(context.cacheDir, "reports").apply { mkdirs() }
    val file = File(dir, "dialer-next-usage-report.txt").apply { writeText(text) }
    val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    val calls = UsageLog.total(UsageLog.Event.CALL)
    val searches = UsageLog.total(UsageLog.Event.KEYPAD_SEARCH) + UsageLog.total(UsageLog.Event.KEYBOARD_SEARCH)
    val body = "Usage report from Dialer NEXT $version on ${UsageLog.device()}.\n\n" +
        "$calls calls, $searches searches, ${UsageLog.total(UsageLog.Event.QUICK_ACTIONS)} quick actions, ${UsageLog.errors().size} errors.\n\n" +
        "The full report is attached. It contains no names, numbers, contacts or messages."
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_EMAIL, arrayOf(REPORT_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, "Dialer NEXT usage report \u00B7 $version")
        putExtra(Intent.EXTRA_TEXT, body)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    // Prefer email apps; if none answers that way, offer every app that can share it
    val emailOnly = Intent(send).apply { selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")) }
    try {
        context.startActivity(emailOnly)
    } catch (_: ActivityNotFoundException) {
        try {
            context.startActivity(Intent.createChooser(send, "Send usage report"))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No email app on this phone", Toast.LENGTH_SHORT).show()
        }
    }
}

/** Everything the usage log has recorded, in plain words. */
@Composable
fun UsageLogScreen(prefs: Prefs, onBack: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    val totals = remember { UsageLog.Event.entries.map { it to UsageLog.total(it) }.filter { it.second > 0 }.sortedByDescending { it.second } }
    val errors = remember { UsageLog.errors().asReversed() }
    val since = remember { UsageLog.since()?.let { SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(it)) } }

    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text("Usage log", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
            Text(
                (since?.let { "Since $it" } ?: "Not started") + " \u00B7 Dialer NEXT ${appVersion(context)} \u00B7 ${UsageLog.device()}",
                color = c.inkMuted, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
            )
            LogCard("Most used") {
                if (totals.isEmpty()) Text("Nothing recorded yet.", color = c.inkMuted, fontSize = 14.sp)
                val top = totals.firstOrNull()?.second ?: 1
                totals.forEach { (e, n) ->
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        Text(e.label, color = c.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text(n.toString(), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Box(Modifier.fillMaxWidth(n.toFloat() / top).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.accent))
                }
            }
            LogCard("Settings in use") {
                usageSettings(prefs).forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(top = 3.dp)) {
                        Text(k, color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text(v, color = c.ink, fontSize = 14.sp)
                    }
                }
            }
            LogCard("Errors (${errors.size})", titleColor = c.missed) {
                if (errors.isEmpty()) Text("None", color = c.inkMuted, fontSize = 14.sp)
                errors.forEach { Text(it, color = c.ink, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 3.dp)) }
            }
            Text(
                "Kept small on purpose: totals, the last 12 months and the latest 100 errors. Never names, numbers, contacts, messages or notes.",
                color = c.inkMuted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(4.dp, 8.dp, 4.dp, 20.dp),
            )
        }
    }
}

@Composable
private fun LogCard(title: String, titleColor: androidx.compose.ui.graphics.Color? = null, content: @Composable () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
            .background(c.inkMuted.copy(alpha = 0.10f)).padding(12.dp),
    ) {
        Text(title.uppercase(), color = titleColor ?: c.inkMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        content()
    }
}
