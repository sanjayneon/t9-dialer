package com.t9dialer.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.t9dialer.app.data.AppPrefs
import com.t9dialer.app.data.PhoneRepository
import com.t9dialer.app.data.PhoneState
import com.t9dialer.app.data.Prefs
import com.t9dialer.app.data.Search
import com.t9dialer.app.data.SearchResult
import com.t9dialer.app.data.SpeedDial
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DialerViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = PhoneRepository(app).also { com.t9dialer.app.data.UsageLog.init(app) }
    private val appPrefs = AppPrefs(app)
    /** Hidden notes opened by secret keypad codes. */
    val vault = com.t9dialer.app.data.VaultStore(app)
    val prefs: StateFlow<Prefs> = appPrefs.prefs

    /** Digits typed on the keypad. */
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    /** Letters typed in keyboard search; null when keyboard search is closed. */
    private val _text = MutableStateFlow<String?>(null)
    val text: StateFlow<String?> = _text.asStateFlow()

    private val _state = MutableStateFlow(PhoneState())
    val state: StateFlow<PhoneState> = _state.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val results: StateFlow<SearchResult> = combine(_query, _text, _state) { q, t, s -> Triple(q, t, s) }
        .mapLatest { (q, t, s) -> if (t != null) Search.runText(t, s) else Search.run(q, s) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, SearchResult.EMPTY)

    private var loadJob: Job? = null

    /** Re-reads contacts and call history. Runs every time the app comes to the foreground. */
    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.value = withContext(Dispatchers.IO) { repo.load() }
        }
    }

    /** Where the next key goes, counted in characters of [query] (0 = before the first). */
    private val _cursor = MutableStateFlow(0)
    val cursor: StateFlow<Int> = _cursor.asStateFlow()

    private fun at(): Int = _cursor.value.coerceIn(0, _query.value.length)

    /** Selected digits as start (inclusive) to end (exclusive), or null when nothing is selected. */
    private val _selection = MutableStateFlow<Pair<Int, Int>?>(null)
    val selection: StateFlow<Pair<Int, Int>?> = _selection.asStateFlow()

    /** Selects between two positions (in either order); the cursor sits at the end of the selection. */
    fun select(a: Int, b: Int) {
        val len = _query.value.length
        val start = minOf(a, b).coerceIn(0, len)
        val end = maxOf(a, b).coerceIn(0, len)
        _selection.value = if (start == end) null else start to end
        _cursor.value = end
    }

    fun selectAll() = select(0, _query.value.length)

    fun clearSelection() { _selection.value = null }

    fun selectedText(): String = _selection.value?.let { (s, e) -> _query.value.substring(s, e) }.orEmpty()

    /** Removes the selected digits; returns false if nothing was selected. */
    fun deleteSelection(): Boolean {
        val (s, e) = _selection.value ?: return false
        _query.value = _query.value.removeRange(s, e)
        _cursor.value = s
        _selection.value = null
        return true
    }

    /** Types a key at the cursor. */
    fun press(key: Char) = insert(key.toString())

    /** Inserts pasted or typed characters at the cursor; anything that isn't 0-9, +, * or # is dropped. */
    fun insert(text: String) {
        if (_query.value.isEmpty() && text.isNotEmpty()) com.t9dialer.app.data.UsageLog.count(com.t9dialer.app.data.UsageLog.Event.KEYPAD_SEARCH)
        val clean0 = text.filter { it.isDigit() || it in "+*#" }
        if (clean0.isEmpty()) return
        deleteSelection()   // typing or pasting over a selection replaces it
        val q = _query.value
        val clean = clean0.take(MAX_LENGTH - q.length)
        if (clean.isEmpty()) return
        val c = at()
        _query.value = q.substring(0, c) + clean + q.substring(c)
        _cursor.value = c + clean.length
    }

    /** Deletes the character just before the cursor. */
    fun backspace() {
        if (deleteSelection()) return
        val c = at()
        if (c == 0) return
        _query.value = _query.value.removeRange(c - 1, c)
        _cursor.value = c - 1
    }

    fun clear() {
        _query.value = ""
        _cursor.value = 0
        _selection.value = null
    }

    fun setQuery(raw: String) {
        _query.value = raw.filter { it.isDigit() || it in "+*#" }.take(MAX_LENGTH)
        _cursor.value = _query.value.length
        _selection.value = null
    }

    fun moveCursor(to: Int) {
        _selection.value = null
        _cursor.value = to.coerceIn(0, _query.value.length)
    }

    fun openTextSearch() {
        _text.value = ""
        com.t9dialer.app.data.UsageLog.count(com.t9dialer.app.data.UsageLog.Event.KEYBOARD_SEARCH)
    }
    fun setText(t: String) { _text.value = t }
    fun closeTextSearch() { _text.value = null }

    fun format(number: String): String = repo.format(number)

    fun internationalDigits(number: String): String? = repo.internationalDigits(number)

    /** Empties the whole call log (never contacts), then reloads. [done] gets the number deleted, or -1 without permission. */
    fun clearCallLog(done: (Int) -> Unit) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { repo.clearCallLog() }
            done(n)
            refresh()
        }
    }

    /** Removes call log entries (never contacts), then reloads the lists. [done] gets the number deleted, or -1 without permission. */
    fun deleteCalls(ids: List<Long>, done: (Int) -> Unit) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { repo.deleteCalls(ids) }
            done(n)
            refresh()
        }
    }

    /** Sets or removes a contact's personal ringtone, then reloads the lists. [done] gets true if it worked. */
    fun setRingtone(contactId: Long, uri: String?, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { repo.setRingtone(contactId, uri) }
            if (ok && uri != null) com.t9dialer.app.data.UsageLog.count(com.t9dialer.app.data.UsageLog.Event.RINGTONE_SET)
            done(ok)
            if (ok) refresh()
        }
    }

    /** Prepares a chosen song or sound file as a ringtone; returns its address, or null if it couldn't. */
    suspend fun importRingtone(uri: android.net.Uri): String? = withContext(Dispatchers.IO) { repo.importRingtone(uri) }

    fun updatePrefs(change: (Prefs) -> Prefs) = appPrefs.update(change)

    fun setSpeedDial(slot: Int, name: String, number: String) = appPrefs.update { p ->
        // One slot per number: moving a number to a new slot frees its old one
        val kept = p.speedDials.filterValues { com.t9dialer.app.data.numberKey(it.number) != com.t9dialer.app.data.numberKey(number) }
        p.copy(speedDials = kept + (slot to SpeedDial(slot, name, number)))
    }

    fun removeSpeedDial(slot: Int) = appPrefs.update { it.copy(speedDials = it.speedDials - slot) }

    private companion object {
        const val MAX_LENGTH = 60
    }
}
