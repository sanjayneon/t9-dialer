package com.t9dialer.app.data

import android.content.Context
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Optional usage log, kept only on this phone and off unless the user turns it on.
 * It keeps counters (not one line per action) so it stays small: totals, the last 12 months,
 * and the latest 100 errors. It never records names, numbers, contacts, messages, notes or codes.
 */
object UsageLog {
    private const val FILE = "usage_log"
    private const val MAX_ERRORS = 100
    private const val MONTHS_KEPT = 12
    private var app: Context? = null

    /** Feature counters, in the order they appear in the report. */
    enum class Event(val label: String) {
        CALL("Calls from the app"),
        KEYPAD_SEARCH("Keypad searches"),
        KEYBOARD_SEARCH("Keyboard searches"),
        QUICK_ACTIONS("Quick actions opened"),
        LONG_PRESS_MENU("Long-press menus opened"),
        SWIPE("Swipe to call or message"),
        SPEED_DIAL("Speed dial calls"),
        READY_SMS("Ready SMS opened"),
        READY_WHATSAPP("Ready WhatsApp opened"),
        WHATSAPP("WhatsApp buttons used"),
        EMERGENCY("Emergency message used"),
        FORWARDING_WARNING("Call forwarding warnings shown"),
        RINGTONE_SET("Personal ringtones set"),
        PUZZLE_PLAYED("Puzzle levels played"),
        PUZZLE_SOLVED("Puzzle levels solved"),
        HELP_OPENED("Help guide opened"),
        CALL_LOG_CLEARED("Call log cleared"),
    }

    fun init(context: Context) {
        app = context.applicationContext
    }

    private fun sp() = app?.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = sp()?.getBoolean("enabled", false) ?: false

    fun setEnabled(on: Boolean) {
        val s = sp() ?: return
        s.edit().putBoolean("enabled", on).apply()
        if (on && !s.contains("since")) s.edit().putLong("since", System.currentTimeMillis()).apply()
    }

    private fun month(time: Long = System.currentTimeMillis()) = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(time))

    /** Adds one to a feature counter (only while the log is on). */
    fun count(event: Event) {
        val s = sp() ?: return
        if (!isEnabled()) return
        val m = month()
        s.edit()
            .putInt("t_${event.name}", s.getInt("t_${event.name}", 0) + 1)
            .putInt("m_${m}_${event.name}", s.getInt("m_${m}_${event.name}", 0) + 1)
            .apply()
        pruneMonths()
    }

    /** Notes an error. [what] must be a short description with no personal details. */
    fun error(what: String) {
        val s = sp() ?: return
        if (!isEnabled()) return
        val stamp = SimpleDateFormat("d MMM yyyy HH:mm", Locale.US).format(Date())
        val list = errors() + "$stamp \u00B7 ${what.take(140).replace('\n', ' ')}"
        s.edit().putString("errors", list.takeLast(MAX_ERRORS).joinToString("\n")).commit()
    }

    fun errors(): List<String> = sp()?.getString("errors", null)?.split('\n')?.filter { it.isNotBlank() } ?: emptyList()

    fun total(event: Event): Int = sp()?.getInt("t_${event.name}", 0) ?: 0

    fun since(): Long? = sp()?.getLong("since", 0L)?.takeIf { it > 0 }

    /** Months that have any counts, newest first, with their counters. */
    fun months(): List<Pair<String, Map<Event, Int>>> {
        val all = sp()?.all ?: return emptyList()
        val byMonth = sortedMapOf<String, MutableMap<Event, Int>>(compareByDescending { it })
        for ((k, v) in all) {
            if (!k.startsWith("m_") || v !is Int) continue
            val m = k.substring(2, 9)
            val e = runCatching { Event.valueOf(k.substring(10)) }.getOrNull() ?: continue
            byMonth.getOrPut(m) { mutableMapOf() }[e] = v
        }
        return byMonth.map { it.key to it.value.toMap() }
    }

    private fun pruneMonths() {
        val s = sp() ?: return
        val keep = months().take(MONTHS_KEPT).map { it.first }.toSet()
        val old = s.all.keys.filter { it.startsWith("m_") && it.substring(2, 9) !in keep }
        if (old.isNotEmpty()) s.edit().apply { old.forEach { remove(it) } }.apply()
    }

    /** Deletes everything recorded (the on/off choice stays). */
    fun clear() {
        val s = sp() ?: return
        val on = isEnabled()
        s.edit().clear().putBoolean("enabled", on).apply()
        if (on) s.edit().putLong("since", System.currentTimeMillis()).apply()
    }

    fun device(): String = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}"

    /** The full plain-text report that is attached to the email. */
    fun report(version: String, settings: List<Pair<String, String>>): String = buildString {
        val fmt = SimpleDateFormat("d MMM yyyy", Locale.US)
        appendLine("Dialer NEXT usage report")
        appendLine("Version $version \u00B7 ${device()}")
        appendLine("Log kept since: ${since()?.let { fmt.format(Date(it)) } ?: "not started"}")
        appendLine("Report made: ${fmt.format(Date())}")
        appendLine("This report has no names, numbers, contacts, messages or notes.")
        appendLine()
        appendLine("TOTALS")
        Event.entries.forEach { e -> appendLine("  ${e.label}: ${total(e)}") }
        appendLine()
        appendLine("BY MONTH (last $MONTHS_KEPT)")
        val ms = months()
        if (ms.isEmpty()) appendLine("  Nothing yet")
        ms.forEach { (m, counts) ->
            appendLine("  $m: " + Event.entries.filter { (counts[it] ?: 0) > 0 }.joinToString(", ") { "${it.label} ${counts[it]}" })
        }
        appendLine()
        appendLine("SETTINGS IN USE")
        settings.forEach { (k, v) -> appendLine("  $k: $v") }
        appendLine()
        val errs = errors()
        appendLine("ERRORS (${errs.size}, newest last, up to $MAX_ERRORS kept)")
        if (errs.isEmpty()) appendLine("  None")
        errs.forEach { appendLine("  $it") }
    }
}
