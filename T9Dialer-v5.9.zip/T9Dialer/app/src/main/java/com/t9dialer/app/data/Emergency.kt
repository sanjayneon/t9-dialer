package com.t9dialer.app.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/** Sends the emergency text and finds a location link for it. */
object Emergency {

    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED



    /** A Google Maps link to where the phone is, or null if location is off or takes too long (8 s). */
    @SuppressLint("MissingPermission")
    suspend fun locationLink(context: Context): String? {
        if (!granted(context, Manifest.permission.ACCESS_FINE_LOCATION) &&
            !granted(context, Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var best: Location? = null
        if (Build.VERSION.SDK_INT >= 30 && providers.isNotEmpty()) {
            best = withTimeoutOrNull(8_000) {
                suspendCancellableCoroutine<Location?> { cont ->
                    val cancel = CancellationSignal()
                    cont.invokeOnCancellation { cancel.cancel() }
                    lm.getCurrentLocation(providers.first(), cancel, context.mainExecutor) { loc -> if (cont.isActive) cont.resume(loc) }
                }
            }
        }
        if (best == null) {
            best = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        }
        return best?.let { String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f", it.latitude, it.longitude) }
    }
}
