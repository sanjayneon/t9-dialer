package com.t9dialer.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Organization
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.t9dialer.app.t9.T9Name
import com.t9dialer.app.t9.T9Number
import com.t9dialer.app.t9.fold
import java.util.Locale

/** One phone number belonging to a contact. A contact with two numbers gives two entries. */
class PhoneEntry(
    val contactId: Long,
    val lookupKey: String?,
    val name: String,
    val number: String,
    val label: String,
    val photoUri: String?,
    val starred: Boolean,
    /** Job title and company from the contact, e.g. "Sales Manager, Simplo Tiles". */
    val org: String? = null,
    /** The contact's personal ringtone (a content:// address), or null for the phone's default. */
    val ringtone: String? = null,
) {
    val key: String = numberKey(number)
}

/** One call from the phone's call log; [duration] is in seconds (0 for missed or unanswered calls). */
class CallEntry(val id: Long, val number: String, val cachedName: String?, val type: Int, val date: Long, val duration: Long = 0)

/** Consecutive calls with the same number, shown as one row: "Mum (3)". */
class RecentGroup(
    val key: String,
    val number: String,
    val name: String?,
    val contact: PhoneEntry?,
    val type: Int,
    val date: Long,
    val count: Int,
    /** Call log row ids of the calls in this group, for deleting them. */
    val callIds: List<Long> = emptyList(),
    /** How long the most recent call in this group lasted, in seconds. */
    val duration: Long = 0,
)

class CallStat(val count: Int, val last: Long)

/** WhatsApp details WhatsApp itself adds to a contact: the number it uses and the rows that start calls. */
class WaInfo(val digits: String, val voiceId: Long?, val videoId: Long?)

class FrequentItem(val recent: RecentGroup, val count: Int)

class IndexedContact(val entry: PhoneEntry, val name: T9Name, val number: T9Number) {
    val folded: String = fold(entry.name)
}

/** The latest call log row for each number, searchable by name (if known) and number. */
class IndexedRecent(val recent: RecentGroup, val name: T9Name?, val number: T9Number) {
    val folded: String? = recent.name?.let { fold(it) }
}

class PhoneState(
    val loaded: Boolean = false,
    val hasContacts: Boolean = false,
    val hasCallLog: Boolean = false,
    /** One entry per contact, A to Z. */
    val contacts: List<PhoneEntry> = emptyList(),
    val recents: List<RecentGroup> = emptyList(),
    val contactIndex: List<IndexedContact> = emptyList(),
    val recentIndex: List<IndexedRecent> = emptyList(),
    val stats: Map<String, CallStat> = emptyMap(),
    /** Numbers you've called or been called by at least twice, most calls first. */
    val frequent: List<FrequentItem> = emptyList(),
    /** WhatsApp details by number (see [numberKey]); empty if WhatsApp isn't installed. */
    val whatsapp: Map<String, WaInfo> = emptyMap(),
    val hasWhatsApp: Boolean = false,
) {
    /** Contacts starred as favourites in the phone's Contacts app, A to Z. */
    val favourites: List<PhoneEntry> get() = contacts.filter { it.starred }

    val lastDialed: String?
        get() = recents.firstOrNull { it.type == CallLog.Calls.OUTGOING_TYPE && it.number.isNotBlank() }?.number
}

/**
 * Matches numbers regardless of formatting or country code by comparing the
 * last nine digits: "+44 7700 900123" and "07700900123" give the same key.
 */
fun numberKey(number: String): String {
    val digits = number.filter { it.isDigit() }
    return if (digits.length > 9) digits.takeLast(9) else digits
}

class PhoneRepository(private val context: Context) {

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private val countryIso: String by lazy {
        val tm = context.getSystemService(TelephonyManager::class.java)
        val iso = tm?.networkCountryIso?.takeIf { it.isNotBlank() }
            ?: tm?.simCountryIso?.takeIf { it.isNotBlank() }
            ?: Locale.getDefault().country
        iso.uppercase(Locale.ROOT)
    }

    fun format(number: String): String =
        if (number.isBlank()) "" else PhoneNumberUtils.formatNumber(number, countryIso) ?: number

    fun load(): PhoneState {
        val hasContacts = granted(Manifest.permission.READ_CONTACTS)
        val hasCallLog = granted(Manifest.permission.READ_CALL_LOG)
        val phones = if (hasContacts) queryPhones(queryOrganizations()) else emptyList()
        val hasWhatsApp = runCatching { context.packageManager.getPackageInfo(WHATSAPP, 0); true }.getOrDefault(false)
        val whatsapp = if (hasContacts && hasWhatsApp) queryWhatsApp() else emptyMap()
        val calls = if (hasCallLog) queryCalls() else emptyList()

        val byKey = HashMap<String, PhoneEntry>()
        for (p in phones) if (p.key.isNotEmpty()) byKey.putIfAbsent(p.key, p)

        // Calls arrive newest first, so the first one seen per number is the latest.
        val stats = HashMap<String, CallStat>()
        for (call in calls) {
            val k = numberKey(call.number)
            if (k.isEmpty()) continue
            val s = stats[k]
            stats[k] = if (s == null) CallStat(1, call.date) else CallStat(s.count + 1, s.last)
        }

        val recents = groupRecents(calls, byKey)

        val nameCache = HashMap<String, T9Name>()
        fun t9(name: String) = nameCache.getOrPut(name) { T9Name(name) }
        val index = phones.map { IndexedContact(it, t9(it.name), T9Number(it.number)) }
        val recentIndex = recents
            .filter { it.key.isNotEmpty() }
            .distinctBy { it.key }
            .map { IndexedRecent(it, it.name?.let(::t9), T9Number(it.number)) }

        return PhoneState(
            loaded = true,
            hasContacts = hasContacts,
            hasCallLog = hasCallLog,
            contacts = phones.distinctBy { it.contactId },
            recents = recents,
            contactIndex = index,
            recentIndex = recentIndex,
            stats = stats,
            frequent = recentIndex
                .map { FrequentItem(it.recent, stats[it.recent.key]?.count ?: 0) }
                .filter { it.count >= 2 }
                .sortedWith(compareByDescending<FrequentItem> { it.count }.thenByDescending { it.recent.date })
                .take(MAX_FREQUENT),
            whatsapp = whatsapp,
            hasWhatsApp = hasWhatsApp,
        )
    }

    private fun groupRecents(calls: List<CallEntry>, byKey: Map<String, PhoneEntry>): List<RecentGroup> {
        val out = ArrayList<RecentGroup>()
        var i = 0
        while (i < calls.size && out.size < MAX_RECENTS) {
            val first = calls[i]
            val key = numberKey(first.number)
            var j = i + 1
            while (j < calls.size && key.isNotEmpty() && numberKey(calls[j].number) == key) j++
            val contact = byKey[key]
            out += RecentGroup(
                key = key,
                number = format(first.number),
                name = contact?.name ?: first.cachedName?.takeIf { it.isNotBlank() },
                contact = contact,
                type = first.type,
                date = first.date,
                count = j - i,
                callIds = calls.subList(i, j).map { it.id },
                duration = first.duration,
            )
            i = j
        }
        return out
    }

    /** International form without the +, for WhatsApp chat links: "098100 83013" in India gives "919810083013". */
    fun internationalDigits(number: String): String? {
        val e164 = PhoneNumberUtils.formatNumberToE164(number, countryIso) ?: return null
        return e164.filter { it.isDigit() }.takeIf { it.length >= 8 }
    }

    private fun queryWhatsApp(): Map<String, WaInfo> {
        val out = HashMap<String, WaInfo>()
        try {
            context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1),
                "${ContactsContract.Data.MIMETYPE} IN (?,?)", arrayOf(WA_VOICE, WA_VIDEO), null,
            )?.use { c ->
                while (c.moveToNext()) {
                    // DATA1 is WhatsApp's id for the person, like 919810083013@s.whatsapp.net
                    val digits = c.getString(2)?.substringBefore('@')?.filter { it.isDigit() }.orEmpty()
                    if (digits.isEmpty()) continue
                    val key = numberKey(digits)
                    val old = out[key]
                    val id = c.getLong(0)
                    out[key] = if (c.getString(1) == WA_VOICE) WaInfo(digits, id, old?.videoId)
                               else WaInfo(digits, old?.voiceId, id)
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    /** Contact id to "Job title, Company" (either part may be missing). */
    private fun queryOrganizations(): Map<Long, String> {
        val out = HashMap<Long, String>()
        val projection = arrayOf(Organization.CONTACT_ID, Organization.COMPANY, Organization.TITLE)
        try {
            context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI, projection,
                "${ContactsContract.Data.MIMETYPE} = ?", arrayOf(Organization.CONTENT_ITEM_TYPE), null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    if (out.containsKey(id)) continue
                    val text = listOf(c.getString(2), c.getString(1))
                        .mapNotNull { it?.trim()?.takeIf { t -> t.isNotEmpty() } }
                        .joinToString(", ")
                    if (text.isNotEmpty()) out[id] = text
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    private fun queryPhones(orgs: Map<Long, String>): List<PhoneEntry> {
        val projection = arrayOf(
            Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME_PRIMARY, Phone.NUMBER,
            Phone.TYPE, Phone.LABEL, Phone.PHOTO_THUMBNAIL_URI, Phone.STARRED, Phone.CUSTOM_RINGTONE,
        )
        val out = ArrayList<PhoneEntry>()
        val seen = HashSet<String>()
        try {
            context.contentResolver.query(
                Phone.CONTENT_URI, projection, null, null,
                "${Phone.DISPLAY_NAME_PRIMARY} COLLATE LOCALIZED ASC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val number = c.getString(3)?.trim().orEmpty()
                    if (number.isEmpty()) continue
                    if (!seen.add("$id:${numberKey(number)}")) continue
                    val name = c.getString(2)?.takeIf { it.isNotBlank() } ?: number
                    val label = Phone.getTypeLabel(context.resources, c.getInt(4), c.getString(5)).toString()
                    out += PhoneEntry(id, c.getString(1), name, number, label, c.getString(6), c.getInt(7) == 1, orgs[id], c.getString(8)?.takeIf { it.isNotBlank() })
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    private fun queryCalls(): List<CallEntry> {
        val projection = arrayOf(
            CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
        )
        val out = ArrayList<CallEntry>()
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI, projection, null, null, "${CallLog.Calls.DATE} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < MAX_CALLS) {
                    out += CallEntry(c.getLong(0), c.getString(1).orEmpty(), c.getString(2), c.getInt(3), c.getLong(4), c.getLong(5))
                }
            }
        } catch (_: SecurityException) {
        }
        return out
    }

    /** Sets (or with null, removes) a contact's personal ringtone in the phone's contacts. */
    fun setRingtone(contactId: Long, uri: String?): Boolean = try {
        val values = android.content.ContentValues().apply {
            if (uri == null) putNull(ContactsContract.Contacts.CUSTOM_RINGTONE) else put(ContactsContract.Contacts.CUSTOM_RINGTONE, uri)
        }
        context.contentResolver.update(
            ContactsContract.Contacts.CONTENT_URI, values, "${ContactsContract.Contacts._ID} = ?", arrayOf(contactId.toString()),
        ) > 0
    } catch (_: Exception) {
        false
    }

    /**
     * Makes a song or sound file the phone can always play as a ringtone. On Android 10 and newer it is copied
     * into the phone's Ringtones folder (Ringtones/Dialer NEXT); on older phones the file itself is used.
     */
    fun importRingtone(source: android.net.Uri): String? = try {
        val resolver = context.contentResolver
        if (android.os.Build.VERSION.SDK_INT < 29) {
            runCatching { resolver.takePersistableUriPermission(source, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            source.toString()
        } else {
            var name = "Ringtone"
            resolver.query(source, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { name = it }
            }
            val mime = resolver.getType(source) ?: "audio/mpeg"
            val media = android.provider.MediaStore.Audio.Media.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, mime)
                put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_RINGTONES + "/Dialer NEXT")
                put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, 1)
                put(android.provider.MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val dest = resolver.insert(media, values)
            if (dest == null) null else {
                resolver.openInputStream(source)?.use { input -> resolver.openOutputStream(dest)?.use { output -> input.copyTo(output) } }
                resolver.update(dest, android.content.ContentValues().apply { put(android.provider.MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
                dest.toString()
            }
        }
    } catch (_: Exception) {
        null
    }

    /** Deletes every entry in the phone's call log (contacts are untouched). Returns how many, or -1 without permission. */
    fun clearCallLog(): Int = try {
        context.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null)
    } catch (_: SecurityException) {
        -1
    }

    /**
     * Deletes the given call log entries. Only the call history rows are removed;
     * contacts are never touched. Returns how many were deleted.
     */
    fun deleteCalls(ids: List<Long>): Int {
        if (ids.isEmpty()) return 0
        return try {
            ids.chunked(200).sumOf { chunk ->
                val marks = chunk.joinToString(",") { "?" }
                context.contentResolver.delete(
                    CallLog.Calls.CONTENT_URI,
                    "${CallLog.Calls._ID} IN ($marks)",
                    chunk.map { it.toString() }.toTypedArray(),
                )
            }
        } catch (_: SecurityException) {
            -1
        }
    }

    companion object {
        const val WHATSAPP = "com.whatsapp"
        const val WA_VOICE = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        const val WA_VIDEO = "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        private const val MAX_CALLS = 1000
        private const val MAX_RECENTS = 150
        private const val MAX_FREQUENT = 30
    }
}
