package com.t9dialer.app.ui

import android.app.Activity
import java.io.File
import androidx.core.content.FileProvider
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Image
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Password
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.t9dialer.app.data.SecretNote
import com.t9dialer.app.data.VaultSession
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.t9dialer.app.data.VaultStore

/**
 * Hidden notes, opened by typing a secret code on the keypad. Up to 10 notes per code, each with text and photos.
 * "Save & lock" encrypts and hides everything again. The notes also lock themselves when
 * the app goes to the background, and the screen can't be captured while they're open.
 */
@Composable
fun SecretNotesScreen(session: VaultSession, onLock: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    var notes by remember { mutableStateOf(session.notes) }
    val scope = rememberCoroutineScope()
    var editingId by remember { mutableStateOf<Long?>(null) }   // null = list, NEW = new note
    var draft by remember { mutableStateOf("") }
    var draftPhotos by remember { mutableStateOf<List<String>>(emptyList()) }
    var addingPhoto by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<String?>(null) }          // photo shown full screen
    val thumbs = remember { mutableStateMapOf<String, ImageBitmap>() }  // decrypted previews, in memory only
    // True while the gallery or camera is open for us, so leaving the app briefly doesn't lock the notes
    var pickingOutside by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var changingCode by remember { mutableStateOf(false) }

    // No screenshots, screen recording or previews in the recent-apps screen while notes are open
    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun persist(list: List<SecretNote>) {
        notes = list
        session.save(list)
    }

    /** Saves whatever is in the editor (an empty note is simply not kept). */
    fun commitDraft() {
        val id = editingId ?: return
        val text = draft.trimEnd()
        val photos = draftPhotos
        val now = System.currentTimeMillis()
        val old = notes.firstOrNull { it.id == id }
        val empty = text.isBlank() && photos.isEmpty()
        // Photo files that are no longer part of this note
        val dropped = (old?.photos.orEmpty() - photos.toSet()) + (if (empty) photos else emptyList())
        persist(
            when {
                id == NEW && empty -> notes
                id == NEW -> notes + SecretNote(now, text, now, photos)
                empty -> notes.filterNot { it.id == id }
                else -> notes.map {
                    if (it.id == id && (it.text != text || it.photos != photos)) SecretNote(id, text, now, photos) else it
                }
            }
        )
        if (dropped.isNotEmpty()) session.deletePhotos(dropped)
    }

    fun openNote(note: SecretNote?) {
        draft = note?.text.orEmpty()
        draftPhotos = note?.photos.orEmpty()
        editingId = note?.id ?: NEW
    }

    /** Shrinks, encrypts and stores a photo, then adds it to the note being edited. */
    fun addPhoto(bytes: ByteArray?) {
        if (bytes == null) { Toast.makeText(context, "Couldn't read that photo", Toast.LENGTH_SHORT).show(); return }
        addingPhoto = true
        scope.launch {
            val id = withContext(Dispatchers.Default) {
                PhotoTools.prepare(bytes)?.let { (photo, thumb) -> session.addPhoto(photo, thumb) }
            }
            addingPhoto = false
            if (id == null) Toast.makeText(context, "That isn't a photo", Toast.LENGTH_SHORT).show()
            else draftPhotos = draftPhotos + id
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
        pickingOutside = false
        uris.forEach { uri -> addPhoto(PhotoTools.readUri(context, uri)) }
    }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        pickingOutside = false
        val f = cameraFile
        cameraFile = null
        if (ok && f != null) addPhoto(runCatching { f.readBytes() }.getOrNull())
        f?.delete()   // the unencrypted camera file is removed straight away
    }
    fun takePhoto() {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val f = File(dir, "shot.jpg")
        cameraFile = f
        pickingOutside = true
        runCatching { camera.launch(FileProvider.getUriForFile(context, "${context.packageName}.files", f)) }
            .onFailure { pickingOutside = false; Toast.makeText(context, "No camera app found", Toast.LENGTH_SHORT).show() }
    }

    fun saveAndLock() {
        commitDraft()
        editingId = null
        onLock()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { if (!pickingOutside) saveAndLock() }
    BackHandler {
        if (editingId != null) { commitDraft(); editingId = null } else saveAndLock()
    }

    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        if (editingId == null) {
            // ---------- list of notes ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { saveAndLock() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Lock and close", tint = c.ink) }
                Text("Notes", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box {
                    var menu by remember { mutableStateOf(false) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = c.inkMuted) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Change code") },
                            leadingIcon = { Icon(Icons.Filled.Password, contentDescription = null) },
                            onClick = { menu = false; changingCode = true },
                        )
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            ) {
                if (notes.isEmpty()) {
                    Text("No notes yet.", color = c.inkMuted, fontSize = 15.sp, modifier = Modifier.padding(vertical = 12.dp))
                }
                for (note in notes.sortedByDescending { it.updated }) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(NotePaper)
                            .clickable { openNote(note) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                    ) {
                        Text(
                            note.text.lineSequence().firstOrNull()?.takeIf { it.isNotBlank() } ?: "Photo note",
                            color = NoteInk, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        val rest = note.text.lineSequence().drop(1).joinToString(" ").trim()
                        if (rest.isNotEmpty()) {
                            Text(rest, color = NoteInkSoft, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (note.photos.isNotEmpty()) {
                            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                note.photos.take(3).forEach { id ->
                                    Thumb(id, session, thumbs, Modifier.padding(end = 6.dp).size(44.dp))
                                }
                                Text(
                                    if (note.photos.size == 1) "1 photo" else "${note.photos.size} photos",
                                    color = NoteInkSoft, fontSize = 12.sp,
                                )
                            }
                        }
                        Text(
                            DateUtils.getRelativeTimeSpanString(note.updated).toString(),
                            color = NoteInkSoft, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (notes.size < VaultStore.MAX_NOTES) {
                    OutlinedButton(onClick = { openNote(null) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("New note  (${notes.size} of ${VaultStore.MAX_NOTES})")
                    }
                } else {
                    Text(
                        "You have ${VaultStore.MAX_NOTES} notes, the most allowed. Delete one to add another.",
                        color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
            LockButton { saveAndLock() }
        } else {
            // ---------- one note ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { commitDraft(); editingId = null }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Save and go back to notes", tint = c.ink)
                }
                Text(if (editingId == NEW) "New note" else "Note", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (editingId != NEW) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete note", tint = c.missed) }
                }
            }
            if (draftPhotos.isNotEmpty() || addingPhoto) {
                LazyRow(
                    Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(draftPhotos, key = { it }) { id ->
                        Box {
                            Thumb(id, session, thumbs, Modifier.size(96.dp).clickable { viewing = id })
                            // Remove from the note
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA000000))
                                    .clickable { draftPhotos = draftPhotos - id },
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = Color.White, modifier = Modifier.size(16.dp)) }
                        }
                    }
                    if (addingPhoto) {
                        item {
                            Box(Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)).background(NotePaper), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = NoteInk, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                }
            }
            TextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Write your note", color = NoteInkSoft) },
                textStyle = TextStyle(color = NoteInk, fontSize = 17.sp, lineHeight = 24.sp),
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = NotePaper,
                    unfocusedContainerColor = NotePaper,
                    focusedTextColor = NoteInk,
                    unfocusedTextColor = NoteInk,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = NoteInk,
                ),
                shape = RoundedCornerShape(14.dp),
            )
            // Add photos: gallery, camera, or a photo copied to the clipboard
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                PhotoAction(Icons.Filled.PhotoLibrary, "Gallery") {
                    pickingOutside = true
                    gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                PhotoAction(Icons.Filled.PhotoCamera, "Camera") { takePhoto() }
                PhotoAction(Icons.Filled.ContentPaste, "Paste photo") {
                    val uri = PhotoTools.clipboardImage(context)
                    if (uri == null) Toast.makeText(context, "No photo on the clipboard. Copy one first.", Toast.LENGTH_SHORT).show()
                    else addPhoto(PhotoTools.readUri(context, uri))
                }
            }
            LockButton { saveAndLock() }
        }
    }

    viewing?.let { id ->
        PhotoViewer(id, session, onRemove = { draftPhotos = draftPhotos - id; viewing = null }, onClose = { viewing = null })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this note?") },
            text = { Text("It can't be recovered.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = editingId
                    editingId = null
                    val photos = (notes.firstOrNull { it.id == id }?.photos.orEmpty() + draftPhotos).distinct()
                    persist(notes.filterNot { it.id == id })
                    session.deletePhotos(photos)
                }) { Text("Delete", color = c.missed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    if (changingCode) {
        ChangeCodeDialog(
            // Making a key from the code is slow on purpose, so it runs off the main thread
            onSave = { digits, result -> scope.launch { result(withContext(Dispatchers.Default) { session.changeCode(digits) }) } },
            onDismiss = { changingCode = false },
        )
    }
}

/** A small decrypted preview; loads in the background the first time it's shown. */
@Composable
private fun Thumb(id: String, session: VaultSession, cache: MutableMap<String, ImageBitmap>, modifier: Modifier) {
    val bmp = cache[id]
    LaunchedEffect(id) {
        if (cache[id] == null) {
            withContext(Dispatchers.Default) {
                session.thumb(id)?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
            }?.let { cache[id] = it }
        }
    }
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(NotePaper), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, contentDescription = "Photo", contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
    }
}

@Composable
private fun PhotoAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(24.dp))
        Text(label, color = c.inkMuted, fontSize = 12.sp)
    }
}

/** Full-screen photo with Close and Remove. The decrypted image only ever lives in memory. */
@Composable
private fun PhotoViewer(id: String, session: VaultSession, onRemove: () -> Unit, onClose: () -> Unit) {
    var bmp by remember(id) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(id) {
        bmp = withContext(Dispatchers.Default) {
            session.photo(id)?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
        }
    }
    // Its own window, so it needs its own no-screenshots flag
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val image = bmp
            if (image != null) {
                Image(image, contentDescription = "Photo", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp)) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, contentDescription = "Remove photo from note", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun LockButton(onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
        shape = RoundedCornerShape(14.dp),
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text("Save & lock", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** New code: digits only; "##" is always added at the end. [onSave] returns an error or null. */
@Composable
private fun ChangeCodeDialog(onSave: (String, (String?) -> Unit) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var code by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (done) "Code changed" else "Change code") },
        text = {
            if (done) {
                Text("From now on, type $code## on the keypad to open these notes. The old code no longer works.")
            } else {
                Column {
                    Text(
                        "Enter ${VaultStore.MIN_DIGITS} to ${VaultStore.MAX_DIGITS} digits. ## is added at the end automatically.",
                        color = c.inkMuted, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = code,
                        onValueChange = { v -> code = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("New code") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = again,
                        onValueChange = { v -> again = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("Type it again") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    error?.let { Text(it, color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = {
            if (done) {
                TextButton(onClick = onDismiss) { Text("OK") }
            } else {
                TextButton(enabled = !saving, onClick = {
                    if (code != again) {
                        error = "The two codes don't match."
                    } else {
                        saving = true
                        onSave(code) { problem ->
                            saving = false
                            error = problem
                            if (problem == null) done = true
                        }
                    }
                }) { Text(if (saving) "Saving…" else "Save") }
            }
        },
        dismissButton = { if (!done) TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private const val NEW = -1L

// Notes look like bright yellow sticky notes with dark text, easy to read on both themes
private val NotePaper = Color(0xFFFFF1B8)
private val NoteInk = Color(0xFF2B2410)
private val NoteInkSoft = Color(0xFF6B5B2E)
