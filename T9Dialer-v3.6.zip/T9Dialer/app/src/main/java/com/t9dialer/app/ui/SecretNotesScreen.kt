package com.t9dialer.app.ui

import android.app.Activity
import android.text.format.DateUtils
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Password
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.t9dialer.app.data.SecretNote
import com.t9dialer.app.data.Vault
import com.t9dialer.app.data.VaultStore

/**
 * Hidden notes, opened by typing a secret code on the keypad. Up to 5 notes per code.
 * "Save & lock" encrypts and hides everything again. The notes also lock themselves when
 * the app goes to the background, and the screen can't be captured while they're open.
 */
@Composable
fun SecretNotesScreen(store: VaultStore, vault: Vault, onLock: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    var notes by remember { mutableStateOf(store.load(vault)) }
    var editingId by remember { mutableStateOf<Long?>(null) }   // null = list, NEW = new note
    var draft by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    var changingCode by remember { mutableStateOf(false) }

    // No screenshots, screen recording or previews in the recent-apps screen while notes are open
    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun persist(list: List<SecretNote>) {
        notes = list
        store.save(vault, list)
    }

    /** Saves whatever is in the editor (an empty note is simply not kept). */
    fun commitDraft() {
        val id = editingId ?: return
        val text = draft.trimEnd()
        val now = System.currentTimeMillis()
        persist(
            when {
                id == NEW && text.isBlank() -> notes
                id == NEW -> notes + SecretNote(now, text, now)
                text.isBlank() -> notes.filterNot { it.id == id }
                else -> notes.map { if (it.id == id && it.text != text) SecretNote(id, text, now) else it }
            }
        )
    }

    fun saveAndLock() {
        commitDraft()
        editingId = null
        onLock()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { saveAndLock() }
    BackHandler {
        if (editingId != null) { commitDraft(); editingId = null } else saveAndLock()
    }

    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        if (editingId == null) {
            // ---------- list of notes ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { saveAndLock() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Lock and close", tint = c.ink) }
                Text("Notes", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box {
                    var menu by remember { mutableStateOf(false) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = c.inkMuted) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Change code") },
                            leadingIcon = { Icon(Icons.Filled.Password, contentDescription = null) },
                            onClick = { menu = false; changingCode = true },
                        )
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            ) {
                if (notes.isEmpty()) {
                    Text("No notes yet.", color = c.inkMuted, fontSize = 15.sp, modifier = Modifier.padding(vertical = 12.dp))
                }
                for (note in notes.sortedByDescending { it.updated }) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(c.panel)
                            .clickable { draft = note.text; editingId = note.id }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                    ) {
                        Text(
                            note.text.lineSequence().firstOrNull().orEmpty(),
                            color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        val rest = note.text.lineSequence().drop(1).joinToString(" ").trim()
                        if (rest.isNotEmpty()) {
                            Text(rest, color = c.inkMuted, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            DateUtils.getRelativeTimeSpanString(note.updated).toString(),
                            color = c.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (notes.size < VaultStore.MAX_NOTES) {
                    OutlinedButton(onClick = { draft = ""; editingId = NEW }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("New note  (${notes.size} of ${VaultStore.MAX_NOTES})")
                    }
                } else {
                    Text(
                        "You have ${VaultStore.MAX_NOTES} notes, the most allowed. Delete one to add another.",
                        color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
            LockButton { saveAndLock() }
        } else {
            // ---------- one note ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { commitDraft(); editingId = null }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Save and go back to notes", tint = c.ink)
                }
                Text(if (editingId == NEW) "New note" else "Note", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (editingId != NEW) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete note", tint = c.missed) }
                }
            }
            TextField(
                value = draft,
                onValueChange = { draft = it },
                placeholder = { Text("Write your note", color = c.inkMuted) },
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.panel,
                    unfocusedContainerColor = c.panel,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = c.accent,
                ),
                shape = RoundedCornerShape(14.dp),
            )
            LockButton { saveAndLock() }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this note?") },
            text = { Text("It can't be recovered.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = editingId
                    editingId = null
                    persist(notes.filterNot { it.id == id })
                }) { Text("Delete", color = c.missed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    if (changingCode) {
        ChangeCodeDialog(
            onSave = { digits -> store.changeCode(vault, digits) },
            onDismiss = { changingCode = false },
        )
    }
}

@Composable
private fun LockButton(onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
        shape = RoundedCornerShape(14.dp),
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text("Save & lock", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** New code: digits only; "##" is always added at the end. [onSave] returns an error or null. */
@Composable
private fun ChangeCodeDialog(onSave: (String) -> String?, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var code by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (done) "Code changed" else "Change code") },
        text = {
            if (done) {
                Text("From now on, type $code## on the keypad to open these notes. The old code no longer works.")
            } else {
                Column {
                    Text(
                        "Enter ${VaultStore.MIN_DIGITS} to ${VaultStore.MAX_DIGITS} digits. ## is added at the end automatically.",
                        color = c.inkMuted, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = code,
                        onValueChange = { v -> code = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("New code") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = again,
                        onValueChange = { v -> again = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("Type it again") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    error?.let { Text(it, color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = {
            if (done) {
                TextButton(onClick = onDismiss) { Text("OK") }
            } else {
                TextButton(onClick = {
                    error = when {
                        code != again -> "The two codes don't match."
                        else -> onSave(code)
                    }
                    if (error == null) done = true
                }) { Text("Save") }
            }
        },
        dismissButton = { if (!done) TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private const val NEW = -1L
