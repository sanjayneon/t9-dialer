package com.t9dialer.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Two separate sets of hidden notes, each opened by its own keypad code. */
enum class Vault(val id: String, val defaultCode: String) {
    FIRST("a", "123456##"),
    SECOND("b", "654321##"),
}

class SecretNote(val id: Long, val text: String, val updated: Long)

/**
 * Hidden notes. Each set lives in its own file in the app's private no-backup folder,
 * encrypted with AES-256-GCM using a key kept in Android's hardware-backed keystore.
 * The files can't be seen by other apps or file managers and are never backed up.
 * Codes are stored only as salted SHA-256 hashes, never as the code itself.
 */
class VaultStore(private val context: Context) {

    private val sp = context.getSharedPreferences("vault", Context.MODE_PRIVATE)

    /** The set of notes [code] opens, or null. */
    fun match(code: String): Vault? = Vault.entries.firstOrNull { opens(it, code) }

    private fun opens(v: Vault, code: String): Boolean {
        val hash = sp.getString("hash_${v.id}", null) ?: return code == v.defaultCode
        val salt = sp.getString("salt_${v.id}", null) ?: return false
        return hash == hash(code, salt)
    }

    /**
     * Changes the code for one set of notes. [digits] is the part before "##".
     * Returns an error message, or null when saved.
     */
    fun changeCode(v: Vault, digits: String): String? {
        if (digits.length !in MIN_DIGITS..MAX_DIGITS || !digits.all { it.isDigit() }) {
            return "Use $MIN_DIGITS to $MAX_DIGITS digits."
        }
        val code = "$digits##"
        if (Vault.entries.any { it != v && opens(it, code) }) return "Choose a different code."
        val salt = Base64.encodeToString(ByteArray(16).also { SecureRandom().nextBytes(it) }, Base64.NO_WRAP)
        sp.edit().putString("salt_${v.id}", salt).putString("hash_${v.id}", hash(code, salt)).apply()
        return null
    }

    fun load(v: Vault): List<SecretNote> {
        val file = file(v)
        if (!file.exists()) return emptyList()
        return try {
            val json = JSONArray(String(decrypt(file.readBytes()), Charsets.UTF_8))
            List(json.length()) { i ->
                val o = json.getJSONObject(i)
                SecretNote(o.getLong("id"), o.getString("text"), o.getLong("updated"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(v: Vault, notes: List<SecretNote>) {
        val json = JSONArray()
        notes.forEach { json.put(JSONObject().put("id", it.id).put("text", it.text).put("updated", it.updated)) }
        val bytes = encrypt(json.toString().toByteArray(Charsets.UTF_8))
        // Write to a temporary file first so a crash mid-save can't damage the notes
        val target = file(v)
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    private fun file(v: Vault) = File(context.noBackupFilesDir, "notes_${v.id}.bin")

    private fun hash(code: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + code).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    /** Output: 12-byte IV followed by the encrypted data and tag. */
    private fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        return cipher.iv + cipher.doFinal(plain)
    }

    private fun decrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, data, 0, IV_SIZE))
        return cipher.doFinal(data, IV_SIZE, data.size - IV_SIZE)
    }

    companion object {
        const val MAX_NOTES = 5
        const val MIN_DIGITS = 4
        const val MAX_DIGITS = 12
        private const val KEY_ALIAS = "dialer_next_notes"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
    }
}
