package com.t9dialer.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.t9dialer.app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/*
 * Jigsaw puzzle of the About photo, started from "I am feeling bored".
 * All pieces start shuffled inside the grid; drag one onto another to swap them.
 * A piece in its right place locks. Five levels: squares, triangles, diamonds, hexagons.
 * Coordinates are in a unit square (0..1); the photo is cropped to a square.
 */

/** One piece: its home shape, which shapes it may swap with, and whether it is a fixed edge piece. */
private class Piece(val poly: List<Offset>, val group: Int, val fixed: Boolean) {
    val center: Offset = Offset(
        poly.sumOf { it.x.toDouble() }.toFloat() / poly.size,
        poly.sumOf { it.y.toDouble() }.toFloat() / poly.size,
    )
}

/** All pieces of a level and how many rotation steps a piece has (1 means no rotation). */
private class Board(val pieces: List<Piece>, val steps: Int) {
    val movable: Int get() = pieces.count { !it.fixed }
}

private enum class PuzzleLevel(val title: String, val shape: String, val rotates: Boolean) {
    EASY("Easy", "squares", true),
    NORMAL("Normal", "squares", true),
    TRICKY("Tricky", "triangles", false),
    HARD("Hard", "diamonds", true),
    EXPERT("Expert", "hexagons", true);

    fun board(): Board = when (this) {
        EASY -> squares(3)
        NORMAL -> squares(4)
        TRICKY -> triangles(4)
        HARD -> diamonds(4)
        EXPERT -> hexagons(15f / 180f)
    }
}

// ---------- shapes ----------

private fun squares(n: Int): Board {
    val s = 1f / n
    val list = ArrayList<Piece>()
    for (r in 0 until n) for (c in 0 until n) {
        val x = c * s
        val y = r * s
        list += Piece(listOf(Offset(x, y), Offset(x + s, y), Offset(x + s, y + s), Offset(x, y + s)), 0, false)
    }
    return Board(list, 4)
}

/** Each square cut on the same diagonal: two kinds of triangle, each only swaps with its own kind. */
private fun triangles(n: Int): Board {
    val s = 1f / n
    val list = ArrayList<Piece>()
    for (r in 0 until n) for (c in 0 until n) {
        val x = c * s
        val y = r * s
        list += Piece(listOf(Offset(x, y), Offset(x + s, y), Offset(x, y + s)), 0, false)
        list += Piece(listOf(Offset(x + s, y), Offset(x + s, y + s), Offset(x, y + s)), 1, false)
    }
    return Board(list, 1)
}

/** Diamonds on lattice points and square centres; the cut-off ones round the edge stay in place. */
private fun diamonds(n: Int): Board {
    val d = 1f / n
    val h = d / 2f
    val list = ArrayList<Piece>()
    fun diamond(cx: Float, cy: Float) = listOf(Offset(cx, cy - h), Offset(cx + h, cy), Offset(cx, cy + h), Offset(cx - h, cy))
    for (r in 0..n) for (c in 0..n) {
        val p = diamond(c * d, r * d)
        if (c in 1 until n && r in 1 until n) {
            list += Piece(p, 0, false)
        } else {
            val cut = clipToUnit(p)
            if (cut.size >= 3 && area(cut) > 1e-5f) list += Piece(cut, 9, true)
        }
    }
    for (r in 0 until n) for (c in 0 until n) list += Piece(diamond(c * d + h, r * d + h), 0, false)
    return Board(list, 2)
}

/** Pointy-top honeycomb; whole hexagons swap, edge pieces cut by the frame stay in place. */
private fun hexagons(radius: Float): Board {
    val hw = sqrt(3f) * radius
    val vh = 1.5f * radius
    val list = ArrayList<Piece>()
    var row = 0
    while (row * vh <= 1f + radius) {
        var col = -1
        while (col * hw <= 1f + hw) {
            val cx = col * hw + if (row % 2 == 1) hw / 2f else 0f
            val cy = row * vh
            val p = List(6) { i ->
                val a = (PI / 180.0 * (60 * i - 90)).toFloat()
                Offset(cx + radius * cos(a), cy + radius * sin(a))
            }
            val inside = p.all { it.x >= -1e-4f && it.x <= 1f + 1e-4f && it.y >= -1e-4f && it.y <= 1f + 1e-4f }
            if (inside) {
                list += Piece(p, 0, false)
            } else {
                val cut = clipToUnit(p)
                if (cut.size >= 3 && area(cut) > 1e-5f) list += Piece(cut, 9, true)
            }
            col++
        }
        row++
    }
    return Board(list, 6)
}

/** Sutherland-Hodgman clip of a polygon to the unit square. */
private fun clipToUnit(poly: List<Offset>): List<Offset> {
    var out: List<Offset> = poly
    for (e in 0 until 4) {
        val input = out
        if (input.isEmpty()) break
        val result = ArrayList<Offset>()
        for (i in input.indices) {
            val cur = input[i]
            val prev = input[(i + input.size - 1) % input.size]
            val ci = insideEdge(e, cur)
            val pi = insideEdge(e, prev)
            if (ci) {
                if (!pi) result += crossEdge(e, prev, cur)
                result += cur
            } else if (pi) {
                result += crossEdge(e, prev, cur)
            }
        }
        out = result
    }
    return out
}

private fun insideEdge(e: Int, p: Offset): Boolean = when (e) {
    0 -> p.x >= 0f
    1 -> p.y >= 0f
    2 -> p.x <= 1f
    else -> p.y <= 1f
}

private fun crossEdge(e: Int, a: Offset, b: Offset): Offset = when (e) {
    0 -> Offset(0f, a.y + (b.y - a.y) * (0f - a.x) / (b.x - a.x))
    1 -> Offset(a.x + (b.x - a.x) * (0f - a.y) / (b.y - a.y), 0f)
    2 -> Offset(1f, a.y + (b.y - a.y) * (1f - a.x) / (b.x - a.x))
    else -> Offset(a.x + (b.x - a.x) * (1f - a.y) / (b.y - a.y), 1f)
}

private fun area(p: List<Offset>): Float {
    var a = 0f
    for (i in p.indices) {
        val j = (i + 1) % p.size
        a += p[i].x * p[j].y - p[j].x * p[i].y
    }
    return abs(a) / 2f
}

private fun contains(poly: List<Offset>, pt: Offset): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.y > pt.y) != (b.y > pt.y) && pt.x < (b.x - a.x) * (pt.y - a.y) / (b.y - a.y) + a.x) inside = !inside
        j = i
    }
    return inside
}

// ---------- game state ----------

private class Game(val level: PuzzleLevel, val board: Board, val rotate: Boolean) {
    /** slot -> piece sitting in it */
    val at = mutableStateListOf<Int>().apply { addAll(board.pieces.indices) }
    /** piece -> rotation step */
    val rot = mutableStateListOf<Int>().apply { addAll(List(board.pieces.size) { 0 }) }
    var moves by mutableIntStateOf(0)
    var seconds by mutableIntStateOf(0)
    var solved by mutableStateOf(false)
    val canRotate: Boolean get() = rotate && level.rotates && board.steps > 1

    fun locked(slot: Int): Boolean = board.pieces[slot].fixed || (at[slot] == slot && rot[slot] == 0)

    fun checkSolved() {
        solved = board.pieces.indices.all { locked(it) }
    }

    /** Mixes every piece that isn't locked, within its own shape, so none starts in its right place. */
    fun shuffle() {
        val groups = board.pieces.indices.filter { !locked(it) }.groupBy { board.pieces[it].group }
        for ((_, slots) in groups) {
            if (slots.size < 2) continue
            val pieces = slots.map { at[it] }
            var perm = pieces.shuffled()
            var tries = 0
            while (tries++ < 60 && perm.indices.any { perm[it] == slots[it] }) perm = pieces.shuffled()
            if (perm.indices.any { perm[it] == slots[it] }) perm = pieces.drop(1) + pieces.first()
            slots.forEachIndexed { i, s -> at[s] = perm[i] }
        }
        if (canRotate) {
            for (s in board.pieces.indices) {
                if (!board.pieces[s].fixed && !locked(s)) rot[at[s]] = Random.nextInt(board.steps)
            }
        }
    }

    fun restart() {
        for (i in board.pieces.indices) {
            at[i] = i
            rot[i] = 0
        }
        moves = 0
        seconds = 0
        solved = false
        shuffle()
    }
}

private fun formatTime(s: Int) = "${s / 60}:${"%02d".format(s % 60)}"

private fun starsFor(game: Game): Int {
    val par = game.board.movable * (if (game.canRotate) 8 else 5)
    return when {
        game.seconds <= par -> 3
        game.seconds <= par * 2 -> 2
        else -> 1
    }
}

private fun puzzlePrefs(context: Context) = context.getSharedPreferences("puzzle", Context.MODE_PRIVATE)
private fun scoreKey(level: PuzzleLevel, rotate: Boolean) = level.name + if (rotate && level.rotates) "_rot" else ""

// ---------- screens ----------

/** The whole puzzle: level list, the game, and the result. [onExit] goes back to About. */
@Composable
fun PuzzleScreen(onExit: () -> Unit) {
    val c = LocalDialerColors.current
    val image = ImageBitmap.imageResource(R.drawable.about_photo)
    var level by rememberSaveable { mutableStateOf<PuzzleLevel?>(null) }
    var rotate by rememberSaveable { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }   // re-read best times after a win

    Column(
        Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding().navigationBarsPadding(),
    ) {
        val current = level
        if (current == null) {
            BackHandler(onBack = onExit)
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExit) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
                Text("Jigsaw puzzle", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            }
            LevelList(image, rotate, onRotate = { rotate = it }, refresh = refresh, onPick = { level = it })
        } else {
            GameView(
                current, rotate, image,
                onLevels = { level = null; refresh++ },
                onNext = { level = PuzzleLevel.entries.getOrNull(current.ordinal + 1); refresh++ },
                onWin = { refresh++ },
            )
        }
    }
}

@Composable
private fun LevelList(image: ImageBitmap, rotate: Boolean, onRotate: (Boolean) -> Unit, refresh: Int, onPick: (PuzzleLevel) -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val sp = remember(refresh) { puzzlePrefs(context) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
        Text("Put the picture back together.", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        PuzzleLevel.entries.forEach { lv ->
            val count = remember(lv) { lv.board().movable }
            val best = sp.getInt("best_" + scoreKey(lv, rotate), -1)
            val stars = sp.getInt("stars_" + scoreKey(lv, rotate), 0)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                    .background(c.inkMuted.copy(alpha = 0.10f)).clickable { onPick(lv) }.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${lv.ordinal + 1} \u00B7 ${lv.title}", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text("$count ${lv.shape}" + if (rotate && !lv.rotates) " (no rotation)" else "", color = c.inkMuted, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    if (best >= 0) {
                        Text("\u2605".repeat(stars) + "\u2606".repeat(3 - stars), color = Color(0xFFFFB300), fontSize = 13.sp)
                        Text("Best ${formatTime(best)}", color = c.inkMuted, fontSize = 12.sp)
                    } else {
                        Text("Not played", color = c.inkMuted, fontSize = 12.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Rotated pieces", color = c.ink, fontSize = 15.sp)
                Text("Extra challenge: tap a piece to turn it", color = c.inkMuted, fontSize = 12.sp)
            }
            Switch(checked = rotate, onCheckedChange = onRotate)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun GameView(level: PuzzleLevel, rotate: Boolean, image: ImageBitmap, onLevels: () -> Unit, onNext: () -> Unit, onWin: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val game = remember(level, rotate) { Game(level, level.board(), rotate).also { it.shuffle() } }
    var peek by remember { mutableStateOf(false) }
    var dragFrom by remember(game) { mutableStateOf<Int?>(null) }
    var dragOffset by remember(game) { mutableStateOf(Offset.Zero) }
    var hover by remember(game) { mutableStateOf<Int?>(null) }
    var newBest by remember(game) { mutableStateOf(false) }

    BackHandler(onBack = onLevels)
    LaunchedEffect(game, game.solved) {
        while (!game.solved) {
            delay(1_000)
            if (!game.solved) game.seconds++
        }
    }
    LaunchedEffect(peek) {
        if (peek) {
            delay(3_000)
            peek = false
        }
    }
    LaunchedEffect(game, game.solved) {
        if (game.solved && game.moves > 0) {
            val sp = puzzlePrefs(context)
            val k = scoreKey(level, rotate)
            val best = sp.getInt("best_$k", -1)
            val stars = starsFor(game)
            newBest = best < 0 || game.seconds < best
            if (newBest) sp.edit().putInt("best_$k", game.seconds).apply()
            if (stars > sp.getInt("stars_$k", 0)) sp.edit().putInt("stars_$k", stars).apply()
            onWin()
        }
    }

    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onLevels) { Icon(Icons.Filled.Close, contentDescription = "Back to levels", tint = c.ink) }
        Text("${level.title} \u00B7 ${game.board.movable}", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text("${formatTime(game.seconds)} \u00B7 ${game.moves} moves", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(end = 12.dp))
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val side = min(maxWidth.value - 24f, maxHeight.value - 150f).coerceAtLeast(200f).dp
        val sidePx = with(density) { side.toPx() }
        val paths = remember(game, sidePx) { game.board.pieces.map { p -> pathOf(p.poly, sidePx) } }

        fun slotAt(pos: Offset): Int? {
            val u = Offset(pos.x / sidePx, pos.y / sidePx)
            return game.board.pieces.indices.firstOrNull { !game.board.pieces[it].fixed && contains(game.board.pieces[it].poly, u) }
        }
        fun canSwap(a: Int, b: Int) = a != b && !game.locked(a) && !game.locked(b) &&
            game.board.pieces[a].group == game.board.pieces[b].group

        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(side)) {
                Canvas(
                    Modifier.size(side)
                        .pointerInput(game, sidePx) {
                            detectTapGestures(onTap = { pos ->
                                if (!game.solved && game.canRotate) {
                                    val s = slotAt(pos)
                                    if (s != null && !game.locked(s)) {
                                        val p = game.at[s]
                                        game.rot[p] = (game.rot[p] + 1) % game.board.steps
                                        game.moves++
                                        if (game.locked(s)) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        game.checkSolved()
                                    }
                                }
                            })
                        }
                        .pointerInput(game, sidePx) {
                            detectDragGestures(
                                onDragStart = { pos ->
                                    val s = slotAt(pos)
                                    if (!game.solved && s != null && !game.locked(s)) {
                                        dragFrom = s
                                        dragOffset = Offset.Zero
                                        hover = null
                                    }
                                },
                                onDrag = { change, amount ->
                                    val from = dragFrom
                                    if (from != null) {
                                        change.consume()
                                        dragOffset += amount
                                        hover = slotAt(change.position)?.takeIf { canSwap(from, it) }
                                    }
                                },
                                onDragEnd = {
                                    val from = dragFrom
                                    val to = hover
                                    if (from != null && to != null) {
                                        val tmp = game.at[from]
                                        game.at[from] = game.at[to]
                                        game.at[to] = tmp
                                        game.moves++
                                        if (game.locked(from) || game.locked(to)) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        dragFrom = null
                                        dragOffset = Offset.Zero
                                        hover = null
                                        game.checkSolved()
                                    } else if (from != null) {
                                        // Wrong place: spring back with a little wobble
                                        val start = dragOffset
                                        hover = null
                                        scope.launch {
                                            animate(
                                                Offset.VectorConverter, start, Offset.Zero,
                                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                                            ) { v, _ -> dragOffset = v }
                                            dragFrom = null
                                        }
                                    }
                                },
                                onDragCancel = {
                                    dragFrom = null
                                    dragOffset = Offset.Zero
                                    hover = null
                                },
                            )
                        },
                ) {
                    drawRect(Color(0xFF12161D))
                    val board = game.board
                    val dragging = dragFrom
                    for (s in board.pieces.indices) {
                        if (s == dragging) continue
                        val p = game.at[s]
                        drawPiece(image, board, s, p, game.rot[p], paths[s], Offset.Zero, sidePx)
                        val locked = game.locked(s)
                        drawPath(paths[s], if (locked) Color.White.copy(alpha = 0.10f) else Color(0xE60A0C10), style = Stroke(if (locked) 1f else 2.5f))
                    }
                    val h = hover
                    if (h != null) {
                        drawPath(paths[h], Color(0xFF9DB2FF), style = Stroke(3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))))
                    }
                    if (dragging != null) {
                        val moved = Path().apply { addPath(paths[dragging], dragOffset) }
                        drawPath(Path().apply { addPath(paths[dragging], dragOffset + Offset(6f, 8f)) }, Color.Black.copy(alpha = 0.45f))
                        val p = game.at[dragging]
                        drawPiece(image, board, dragging, p, game.rot[p], moved, dragOffset, sidePx)
                        drawPath(moved, Color(0xFF9DB2FF), style = Stroke(3f))
                    }
                    if (peek) {
                        drawImage(
                            image, srcOffset = photoSrcOffset(image), srcSize = photoSrcSize(image),
                            dstSize = IntSize(sidePx.toInt(), sidePx.toInt()), alpha = 0.96f,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            if (!game.solved) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton(Icons.Filled.Visibility, "Peek", enabled = !peek) { peek = true }
                    ToolButton(Icons.Filled.Shuffle, "Shuffle", enabled = true) { game.shuffle() }
                    ToolButton(Icons.Filled.Refresh, "Restart", enabled = true) {
                        game.restart()
                        newBest = false
                    }
                }
                Text(
                    if (game.canRotate) "Drag a piece onto another to swap them. Tap a piece to turn it."
                    else "Drag a piece onto another to swap them.",
                    color = c.inkMuted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 10.dp, start = 20.dp, end = 20.dp),
                )
            } else {
                val stars = starsFor(game)
                Text("\uD83C\uDF89 Solved!", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("\u2605".repeat(stars) + "\u2606".repeat(3 - stars), color = Color(0xFFFFB300), fontSize = 22.sp)
                Text("${formatTime(game.seconds)} \u00B7 ${game.moves} moves", color = c.ink, fontSize = 15.sp)
                if (newBest) Text("New best time for ${level.title}", color = c.call, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (level != PuzzleLevel.EXPERT) {
                        Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)) {
                            Text("Next: ${PuzzleLevel.entries[level.ordinal + 1].title}")
                        }
                    }
                    TextButton(onClick = {
                        game.restart()
                        newBest = false
                    }) { Text("Play again") }
                    TextButton(onClick = onLevels) { Text("Levels") }
                }
            }
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    TextButton(onClick = onClick, enabled = enabled) {
        Icon(icon, contentDescription = null, tint = if (enabled) c.accent else c.inkMuted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = if (enabled) c.accent else c.inkMuted)
    }
}

// ---------- drawing ----------

private fun pathOf(poly: List<Offset>, scale: Float) = Path().apply {
    moveTo(poly[0].x * scale, poly[0].y * scale)
    for (i in 1 until poly.size) lineTo(poly[i].x * scale, poly[i].y * scale)
    close()
}

/** Square crop from the top of the photo (it is very slightly taller than wide). */
private fun photoSrcSize(img: ImageBitmap): IntSize {
    val side = min(img.width, img.height)
    return IntSize(side, side)
}

private fun photoSrcOffset(img: ImageBitmap): IntOffset = IntOffset((img.width - min(img.width, img.height)) / 2, 0)

/**
 * Draws [piece] inside slot [slot]'s shape (offset by [offset] while dragging): the photo is moved so the
 * piece's home lands on the slot, then turned by its rotation around the slot's centre.
 */
private fun DrawScope.drawPiece(image: ImageBitmap, board: Board, slot: Int, piece: Int, rotStep: Int, clip: Path, offset: Offset, side: Float) {
    val slotC = board.pieces[slot].center * side + offset
    val homeC = board.pieces[piece].center * side
    val degrees = if (board.steps > 1) rotStep * 360f / board.steps else 0f
    clipPath(clip) {
        withTransform({
            rotate(degrees, pivot = slotC)
            translate(slotC.x - homeC.x, slotC.y - homeC.y)
        }) {
            drawImage(
                image, srcOffset = photoSrcOffset(image), srcSize = photoSrcSize(image),
                dstSize = IntSize(side.toInt(), side.toInt()),
            )
        }
    }
}
