package com.t9dialer.app.ui

/** Notes for every version, newest first. Lines starting with two spaces are sub-points. */
internal val RELEASE_NOTES: List<Pair<String, List<String>>> = listOf(
    "5.3" to listOf(
        "Feeling bored? A jigsaw puzzle of the About photo, from the new \"I am feeling bored\" button on About.",
        "  Five levels: Easy (9 squares), Normal (16 squares), Tricky (32 triangles), Hard (25 diamonds), Expert (hexagons).",
        "  Pieces start shuffled in the grid; drag one onto another to swap. Pieces in the right place lock.",
        "  Peek, Shuffle and Restart; a Rotated pieces option; best times and stars for every level.",
        "In Settings > Appearance, Settings & menus style now comes first, then Main screen style.",
        "The Apple-like style has been removed. If you were using it, that part of the app is back to Classic.",
    ),
    "5.2.4" to listOf(
        "About shows the blue app logo beside the name and version, below the animated video.",
        "New in About: What's new (these notes), Privacy center, Terms of service and Open source licenses.",
    ),
    "5.2.3" to listOf(
        "Classic style, Dark theme (the default): the main screen background is black (top bar, lists, search results, quick actions). The keypad keeps its own colours and outline.",
    ),
    "5.2.2" to listOf(
        "Keys are silent by default: they only vibrate. A new Key tones option (Settings > Search and keypad) turns tones on; it then also follows the phone's dial-pad tone setting.",
    ),
    "5.2" to listOf(
        "Build fix for 5.1 (two missing icons and two menu colours). Includes everything from 5.0 and 5.1.",
    ),
    "5.1" to listOf(
        "Help & guide: a searchable, offline guide in Settings (card at the top) and the ☰ menu, with 10 topics: Getting started, Dialling and the number bar, Finding people (T9), Call log and lists, Quick actions and WhatsApp, Ready messages, Speed dial, Emergency message, Styles and appearance, Troubleshooting. Steps use your own settings (for example your emergency code).",
        "Clear log in the ⋮ menu deletes the whole call log after a confirmation (contacts aren't affected).",
        "The Help guide follows the Settings & menus style.",
    ),
    "5.0" to listOf(
        "Styles: Settings > Appearance has two separate choices, each Classic, Neumorphic, Flat or Glassmorphic, picked from miniature previews:",
        "  Main screen style: top bar and tabs, lists, search results, quick actions, keypad, number bar, collapsed keypad bar.",
        "  Settings & menus style (or Same as main screen): Settings, the ☰ and ⋮ menus, pop-ups, Speed dial, About and Permissions screens.",
        "Styles change colours, fills, borders and shadows only. Sizes, spacing and what is shown stay exactly as in Classic.",
        "Call log rows never shorten the phone number: if the line is full, the time shrinks slightly, then moves to the end of the name line (with the duration if needed).",
        "Status bar icons stay readable over the Glassmorphic background and the Flat blue top bar.",
    ),
    "4.7" to listOf(
        "Ready messages: 5 SMS and 5 WhatsApp messages, editable in Settings > Ready messages.",
        "  Long-press SMS in quick actions (or Ready SMS… in the long-press menu): tap one and it sends after a 3-second Undo bar.",
        "  Long-press WA chat (or Ready WhatsApp…): tap one and WhatsApp opens that chat with the text typed; tap Send there.",
    ),
    "4.6" to listOf(
        "Names sit closer to the photo (6dp gap); call log time and date sit further right and slightly smaller, so full numbers show before Missed, Declined or No answer.",
        "Keypad handle row: Log (opens the call log) and Add contact on the right, mirroring Search and Favourites on the left.",
        "New 4-second looping About video.",
        "Removing an emergency contact asks for confirmation first.",
    ),
    "4.5" to listOf(
        "Call log rows show how long the most recent call lasted (45s, 2m 15s, 1h 04m) before the time; missed, declined and blocked calls say so in red, and unanswered outgoing calls say No answer.",
    ),
    "4.4" to listOf(
        "About shows a short silent looping video (with the still photo as a fallback until it plays, or if it can't). It pauses when you leave the app.",
        "The collapsed keypad bar shows a thumbs-up picture at the far right.",
    ),
    "4.3" to listOf(
        "Tapping delete vibrates like the keys (follows Vibrate on tap and Vibrate duration; no dial tone).",
    ),
    "4.2" to listOf(
        "Number bar fixed: long numbers no longer slide under the delete button. The size is now worked out with the exact text style shown (including letter spacing), with a small gap kept before the delete button.",
        "Slimmer delete button (44dp) with a smaller, solid backspace icon.",
    ),
    "4.1" to listOf(
        "Quick actions are compact and part of the row: two slim lines of pill buttons (Call, SMS, Info; then WA call, WA chat, WA video), the same tint as the tapped row, no line in between. Tap the name again or any empty space to close.",
        "First-launch permissions screen: every permission with a tick, Allow all, and an Unlock in Settings button with steps for any Android blocks as restricted. Also in Settings > General > Permissions.",
    ),
    "4.0" to listOf(
        "The number bar fits 22+ digits: the number shrinks just enough to fit between the call and delete buttons and never slides under them.",
        "List photos sit at the far left (1dp from the edge), are a little bigger, and touch the divider line above.",
    ),
    "3.9" to listOf(
        "Emergency message (Settings > Emergency): write a message and pick up to 4 emergency contacts. Typing the emergency code followed by ##, or the code and the call button, texts them all. Optional 5-second countdown to cancel, optional Google Maps location link, and an optional follow-up call to the first contact (speaker off).",
    ),
    "3.8" to listOf(
        "Quick actions: tapping a name opens a box under it with the number, Call, Message and Info (opens the full contact). If the person uses WhatsApp, a green WhatsApp row adds Voice call, Chat and Video call. Unsaved numbers get Add contact and WhatsApp Chat.",
        "New setting, Search and keypad > Tapping a name: Show quick actions (default) or Open full contact. One touch dialing, if ticked, still calls.",
    ),
    "3.7" to listOf(
        "The app is no longer debuggable, so computer developer tools can't read its files or drive it.",
    ),
    "3.6" to listOf(
        "Small improvements and fixes.",
    ),
    "3.5" to listOf(
        "About photo is bigger and shows the laptop.",
    ),
    "3.4" to listOf(
        "Renamed to Dialer NEXT.",
        "Slimmer list rows: less space above and below each photo, so more rows fit.",
        "New photo on the About screen (same size).",
        "The collapsed keypad bar shows the same photo, small and round, at the far right instead of the thumbs-up.",
        "A Favourites star next to the search button above the number bar; both moved a little to the right.",
    ),
    "3.3" to listOf(
        "Speed dial page restyled to match the phone's own: \"Assign contacts\", key numbers at the top left, large round photos or initials, round + buttons with \"Add\" underneath, and names below each key.",
    ),
    "3.2" to listOf(
        "New Speed dial page (⋮ menu > Speed dial, or Settings > Speed dial > Edit speed dial): a 3 x 3 grid for keys 1 to 9. Key 1 stays voicemail. Tap the round + on an empty key to pick a contact; their photo then shows on the key. Tap a photo to call, change the contact or remove it. Speed dials 10 to 99 are listed underneath. Long-press dialling on the keypad is unchanged.",
    ),
    "3.1" to listOf(
        "Delete calls: long-press a call log row and choose Delete from call log (asks to confirm). Only the call history entry is removed, never the contact. Grouped rows like \"Mum (3)\" delete all calls in that group. Needs the Call logs permission to write, asked once.",
    ),
    "3.0" to listOf(
        "About now reads: \"This app was created by Sanjay Sachdeva.\"",
    ),
    "2.9" to listOf(
        "Vibrate duration now defaults to 20 ms (applied once when upgrading; your later choice is kept).",
    ),
    "2.8" to listOf(
        "The keypad's handle row is only 5dp taller than before (not 14dp); the search button above the call button is a little smaller to fit.",
        "A small amber thumbs-up at the far right of the collapsed \"Show keypad\" bar.",
    ),
    "2.7" to listOf(
        "A search button on the keypad, in the handle row just above the call button. It opens keyboard search, same as the one in the top bar.",
    ),
    "2.6" to listOf(
        "A star (Favourites) button in the top bar, after Add contact. It fills in while Favourites is showing. Everything still fits on one line.",
    ),
    "2.5" to listOf(
        "The top bar fits everything on one line without scrolling: ☰, app icon, Call log, Contacts, Add contact, search and ⋮. Tab labels keep a fixed size so a large phone font can't push Contacts out of view.",
    ),
    "2.4" to listOf(
        "Colourful icons in the ☰ and ⋮ menus, one colour per item.",
        "Coloured Add contact (teal) and search (bright blue) icons in the top bar.",
    ),
    "2.3" to listOf(
        "Every build is now signed with the same key (app/signing/san-dialer.jks), so new versions install as updates. Builds before 2.3 each had a different random key; uninstall the old app once before installing 2.3.",
        "The email on the About screen is plain text, not a link.",
        "Top bar spacing: Add contact sits right after the tabs, with search and ⋮ pushed to the far right.",
    ),
    "2.2" to listOf(
        "An Add contact icon sits right beside the Contacts tab at the top.",
    ),
    "2.1" to listOf(
        "A thin blue outline runs around the keypad, from the slide handle down, and stays on the slim bar when the keypad is collapsed.",
    ),
    "2.0" to listOf(
        "Select part of the number in the number bar: long-press a digit and drag across. Letting go opens Cut, Copy, Paste over selection and Select all. Typing, delete or paste replace the selection.",
    ),
    "1.9" to listOf(
        "Renamed to San Dialer NEXT.",
        "Settings sections (General, Appearance, Calling, Search and keypad, Speed dial, Shortcuts, About) start collapsed; tap a title to open it. Settings > About shows the same details as the About screen.",
        "New defaults: Dark theme, Large dialpad, font size 15, Multiline mode on, Show company and job on. Applied once when upgrading; your later choices are kept.",
        "Speed dial in the ⋮ menu: see everyone on speed dial, tap to call, remove with the cross.",
    ),
    "1.8" to listOf(
        "0 works as a space in name search, to tell apart people with the same first name: 5646 0 36 finds John Doe, and 5646 0 7 finds John Smith. Phone-number search still treats 0 as a digit.",
    ),
    "1.7" to listOf(
        "About screen in the ☰ menu: app name, version, maker, email and photo.",
        "The collapsed keypad bar no longer shows the typed number; it appears again when the keypad is expanded.",
    ),
    "1.6" to listOf(
        "The number bar is editable: a blinking cursor shows where the next digit goes. Tap the number to put the cursor there, or swipe left or right to slide it one digit at a time. Keys, delete and paste all work at the cursor.",
        "Paste adds at the cursor, so you can paste several times to build a longer number.",
    ),
    "1.5" to listOf(
        "Outgoing-call arrows are bright blue.",
        "Brighter lines under the key letters.",
        "A ⋮ menu at the top right, beside search: Favourites, Frequently called, Add contact, Settings.",
        "The top tabs are now just Call log and Contacts.",
    ),
    "1.4" to listOf(
        "Call log arrows are coloured: incoming green, outgoing blue, missed red.",
        "The call time moved to the number line, so names get the full width (30+ characters before wrapping).",
        "Smaller number line, slimmer rows and a slightly shorter keypad: 6 to 7 rows fit above the keypad.",
        "Square contact photos.",
        "Thicker line under the letters on the keys.",
    ),
    "1.3" to listOf(
        "One touch dialing (Settings, off by default). Off: tapping a name opens the contact; unsaved numbers open their options. On: tapping a name calls.",
        "Call log rows show the time and date (\"11:05 am 22/09\") instead of \"10 mins ago\".",
        "A thin line separates every row.",
        "A thin line under the letters on each key.",
        "Long-press \\* now just types \\*; switch keypad letters in Settings instead.",
        "New top bar: ☰ menu, small blue app icon, and Call log / Contacts / Favourites tabs. The menu holds all four lists (including Frequently called), Add contact and Settings.",
        "The number bar fits at least 16 digits; the call and delete buttons are slimmer.",
        "Long-press the number bar to paste a number (or copy the typed one).",
        "Search matches are highlighted with a tinted marker, in both the Call log and Contacts sections.",
    ),
    "1.2" to listOf(
        "Build fixes: pinned build machine and a vibration fix.",
    ),
    "1.1" to listOf(
        "Version numbering starts.",
        "Themes (Dark, Light, System), vibration options, default view, font size, dialpad size, Multiline mode, and job title and company in lists.",
    ),
)
