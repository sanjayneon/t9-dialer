package com.t9dialer.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Sos
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.t9dialer.app.data.Prefs

/** One help topic: a summary, sections of numbered steps, a tip and links to related topics. */
private class HelpTopic(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val summary: String,
    val sections: List<Pair<String, List<String>>>,
    val tip: String? = null,
    val related: List<String> = emptyList(),
) {
    /** Everything searchable, without the [key] markers. */
    val searchText: String =
        (listOf(title, subtitle, summary, tip.orEmpty()) + sections.flatMap { listOf(it.first) + it.second })
            .joinToString(" ").replace("[", "").replace("]", "").lowercase()
}

/**
 * The guide's content. Text in [square brackets] is shown as a key or button label.
 * Uses the person's own settings where it matters (the emergency code). Hidden notes are left out on purpose.
 */
private fun helpTopics(prefs: Prefs): List<HelpTopic> {
    val code = prefs.emergencyCode
    return listOf(
        HelpTopic(
            "start", "Getting started", "Permissions, installing updates", Icons.Filled.PlayCircle, Color(0xFF2E7D5B),
            "Dialer NEXT searches your contacts and call history as you type, and calls with one tap.",
            listOf(
                "First launch" to listOf(
                    "On the welcome screen, tap [Allow all] to give Contacts, Call history, Phone, SMS and Location.",
                    "If one shows Blocked by Android, tap [Unlock in Settings], then [⋮ › Allow restricted settings], allow it, and come back.",
                    "Reopen that screen any time from [Settings › General › Permissions].",
                ),
                "Installing an update" to listOf(
                    "Pause Google Play Protect scanning while you install.",
                    "Tap the new file and choose [Update]. Your settings and speed dials are kept.",
                    "Don't uninstall first: uninstalling erases the app's data.",
                ),
            ),
            tip = "See which version you have in [Settings › About].",
            related = listOf("trouble"),
        ),
        HelpTopic(
            "dial", "Dialling and the number bar", "Call, paste, edit, prefixes", Icons.Filled.Call, Color(0xFF2DB872),
            "Type the number on the keypad and press the green call button.",
            listOf(
                "Making a call" to listOf(
                    "Type the number, then tap the green call button on the left of the number.",
                    "Long-press [0] for [+].",
                    "On an empty keypad, long-press [1] for voicemail.",
                    "Long-press the call button to dial with your long-press prefix (for example +91).",
                ),
                "Editing the number" to listOf(
                    "Tap the number to place the blue cursor, or swipe left and right on it to move the cursor.",
                    "Keys, delete and paste all work at the cursor. Long-press delete to clear everything.",
                    "Long-press and drag across digits to select them, then choose Cut, Copy or Paste.",
                    "Long-press without dragging to Paste a copied number or Select all.",
                ),
                "The keypad" to listOf(
                    "Swipe the keypad down, or drag the list, to hide it. Tap the slim bar or swipe up to bring it back.",
                    "Above the number: Search and Favourites on the left, [Log] and Add contact on the right.",
                ),
            ),
            tip = "Set call prefixes in [Settings › Calling].",
            related = listOf("find", "speed"),
        ),
        HelpTopic(
            "find", "Finding people (T9)", "Names, initials, 0 as space", Icons.Filled.Search, Color(0xFF2547C9),
            "Press the keys that carry the letters of a name. Matches appear as you type.",
            listOf(
                "Searching" to listOf(
                    "For John, press [5] [6] [4] [6] (J, O, H, N).",
                    "Initials work too: [5] [3] finds John Doe.",
                    "Press [0] as a space between names: [5646] [0] [36] finds John Doe, not John Smith.",
                    "Type part of a phone number to find it, with or without the country code.",
                    "Use [*] for any letters: [5*3] finds J… D….",
                ),
                "Results" to listOf(
                    "Matching calls appear first under Call log, then matching contacts.",
                    "The letters and digits that matched are highlighted.",
                    "No match? Add the number to contacts or send a message straight from the list.",
                ),
                "Keyboard search" to listOf(
                    "Tap the blue search icon, in the top bar or above the number, to type with the phone keyboard.",
                ),
            ),
            tip = "English and Russian names both work, and accents are ignored.",
            related = listOf("lists", "quick"),
        ),
        HelpTopic(
            "lists", "Call log and lists", "Tabs, durations, deleting calls", Icons.Filled.History, Color(0xFF1E90FF),
            "Switch between Call log, Contacts, Favourites and Frequently called.",
            listOf(
                "Switching lists" to listOf(
                    "Tap [Call log] or [Contacts] at the top, or the amber star for Favourites.",
                    "Tap [Log] above the number to jump back to the call log.",
                    "The ☰ menu has all four lists, including Frequently called.",
                    "Choose which list opens first in [Settings › General › Default view].",
                ),
                "Reading the call log" to listOf(
                    "Arrows: green for incoming, blue for outgoing, red for missed.",
                    "Each row shows the full number, how long the last call lasted (or Missed, Declined, No answer), and the time and date.",
                    "(3) after a name means three calls in a row with that person.",
                ),
                "Deleting calls" to listOf(
                    "Long-press a call, choose [Delete from call log], and confirm. Only the call is removed, never the contact.",
                ),
            ),
            tip = "Favourites are the contacts you star in your phone's Contacts app.",
            related = listOf("quick"),
        ),
        HelpTopic(
            "quick", "Quick actions and WhatsApp", "Tap, long-press, swipe", Icons.Filled.TouchApp, Color(0xFF0F8F8A),
            "Tap a name to get call, SMS, info and WhatsApp buttons right under it.",
            listOf(
                "Tapping a name" to listOf(
                    "Two lines of buttons open: Call, SMS and Info, then WA call, WA chat and WA video if the person uses WhatsApp.",
                    "Tap the name again, or any empty space, to close them.",
                    "To go straight to the contact instead: [Settings › Search and keypad › Tapping a name › Open full contact].",
                    "Tick [One touch dialing] to call with a single tap.",
                ),
                "Swiping" to listOf("Swipe a row right to call, or left to send a message."),
                "Long-press menu" to listOf(
                    "Long-press any row for: call, message, edit number before calling, speed dial, ready messages, copy, open or add contact, look up online, and delete from call log.",
                ),
            ),
            tip = "WhatsApp buttons need WhatsApp's contact sync to be turned on.",
            related = listOf("ready"),
        ),
        HelpTopic(
            "ready", "Ready messages", "SMS and WhatsApp", Icons.Filled.Sms, Color(0xFF1FA855),
            "Send a saved message in two taps.",
            listOf(
                "Sending" to listOf(
                    "Tap a name, then long-press [SMS] or [WA chat].",
                    "Pick a message from the list.",
                    "SMS: it sends after a 3-second bar. Tap [UNDO] to stop it.",
                    "WhatsApp: the chat opens with the text already typed. Tap Send in WhatsApp.",
                    "You'll also find [Ready SMS…] and [Ready WhatsApp…] in any row's long-press menu.",
                ),
                "Editing" to listOf("Open [Settings › Ready messages]. Tap a line to change it, or leave it empty to hide it."),
            ),
            tip = "WhatsApp never sends by itself; you always tap Send there.",
            related = listOf("quick"),
        ),
        HelpTopic(
            "speed", "Speed dial", "One long-press to call", Icons.Filled.Speed, Color(0xFFE07A1E),
            "Call your most important people with a single long-press.",
            listOf(
                "Setting up" to listOf(
                    "Open [⋮ › Speed dial] and tap a [+] to pick a contact for keys 2 to 9.",
                    "Or long-press any row and choose [Set speed dial] for any slot from 2 to 99.",
                    "On the speed dial page, tap a photo to call, change or remove it.",
                ),
                "Calling" to listOf(
                    "On an empty keypad, long-press [2] to [9].",
                    "For 10 to 99, tap the first digit, then long-press the second.",
                    "Key [1] is always voicemail.",
                ),
            ),
            related = listOf("dial"),
        ),
        HelpTopic(
            "emergency", "Emergency message", "Alert up to 4 people", Icons.Filled.Sos, Color(0xFFC0392B),
            "Texts your saved message to up to 4 people, and can then call the first one.",
            listOf(
                "Set it up" to listOf(
                    "Open [Settings › Emergency].",
                    "Write your message and add up to 4 contacts.",
                    "Choose the countdown, the location link and the follow-up call.",
                    "Allow SMS when the app asks.",
                ),
                "In an emergency" to listOf(
                    if (code.isEmpty()) "Set an emergency code first." else "Type [$code##], or [$code] and press call.",
                    "A 5-second countdown appears: tap Cancel if it was a mistake, or Send now.",
                    "Each contact gets a text. With location on, a map link to where you are is added.",
                    "If you chose it, your first contact is then called.",
                ),
                "Good to know" to listOf(
                    "It needs mobile signal, and normal SMS charges apply.",
                    "Without SMS permission, Messages opens with everything filled in, ready to send.",
                    "Removing an emergency contact asks you to confirm first.",
                ),
            ),
            tip = "Send a test to yourself first, so you know it works on your network.",
            related = listOf("start", "trouble"),
        ),
        HelpTopic(
            "styles", "Styles and appearance", "Looks, theme, sizes", Icons.Filled.Palette, Color(0xFF7B3FBF),
            "Change how the app looks without changing how it works.",
            listOf(
                "Styles" to listOf(
                    "Open [Settings › Appearance].",
                    "[Main screen style] changes the lists, keypad and top bar.",
                    "[Settings & menus style] changes Settings, the menus and pop-ups, or can follow the main screen.",
                    "Pick Classic, Neumorphic, Flat or Glassmorphic from the previews. Only the look changes; everything stays the same size.",
                ),
                "More options" to listOf(
                    "Theme: Dark, Light, or the phone's setting.",
                    "Dialpad size and Font size.",
                    "Multiline mode lets long names use two lines.",
                    "Show company and job adds a line under names.",
                    "Vibrate on tap, Vibrate duration and Key tones (off by default, so keys are silent) are in Search and keypad.",
                ),
            ),
            related = listOf("lists"),
        ),
        HelpTopic(
            "trouble", "Troubleshooting", "When something doesn't work", Icons.Filled.Build, Color(0xFF5D6B7E),
            "Quick fixes for the most common problems.",
            listOf(
                "The app won't install" to listOf(
                    "Pause Play Protect scanning, then install again.",
                    "If Android asks you to uninstall first, stop: uninstalling erases the app's data.",
                ),
                "SMS or call history is blocked" to listOf(
                    "Go to [Settings › General › Permissions] and tap [Unlock in Settings].",
                    "Tap [⋮ › Allow restricted settings], then allow the blocked permission.",
                ),
                "WhatsApp buttons are missing" to listOf(
                    "Install WhatsApp and turn on its contact sync. Unsaved numbers only get WA chat.",
                ),
                "No vibration" to listOf("Check [Vibrate on tap] in Search and keypad, and your phone's touch vibration."),
                "Keys make a sound" to listOf("Untick [Key tones] in Search and keypad. Keys then only vibrate."),
                "Something looks wrong" to listOf("Take a screenshot, note which style you use, and send it to the developer (details in About)."),
            ),
            related = listOf("start"),
        ),
    )
}

/** Renders [key] markers as small key or button labels. */
private fun keyed(text: String, chip: Color, ink: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        val open = text.indexOf('[', i)
        if (open < 0) { append(text.substring(i)); break }
        val close = text.indexOf(']', open)
        if (close < 0) { append(text.substring(i)); break }
        append(text.substring(i, open))
        val start = length
        append("\u2009${text.substring(open + 1, close)}\u2009")
        addStyle(SpanStyle(background = chip, color = ink, fontWeight = FontWeight.Medium), start, length)
        i = close + 1
    }
}

/** Help & guide: a searchable list of topics; each topic has numbered steps, a tip and related links. */
@Composable
fun HelpScreen(prefs: Prefs, onBack: () -> Unit) {
    val c = LocalDialerColors.current
    val topics = helpTopics(prefs)
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    val open = topics.firstOrNull { it.id == openId }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    BackHandler { if (open != null) openId = null else onBack() }

    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (open != null) openId = null else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink)
            }
            Text(open?.title ?: "Help & guide", color = c.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }

        if (open == null) {
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search the guide", color = c.inkMuted) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = c.inkMuted) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Clear", tint = c.inkMuted) }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.inkMuted.copy(alpha = 0.12f), unfocusedContainerColor = c.inkMuted.copy(alpha = 0.12f),
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = c.accent,
                    focusedTextColor = c.ink, unfocusedTextColor = c.ink,
                ),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
            )
            val q = query.trim().lowercase()
            val shown = if (q.isEmpty()) topics else topics.filter { t -> q.split(" ").filter { it.isNotBlank() }.all { it in t.searchText } }
            LazyColumn(contentPadding = PaddingValues(top = 6.dp, bottom = navBottom + 24.dp)) {
                if (shown.isEmpty()) {
                    item { Text("Nothing found for “${query.trim()}”.", color = c.inkMuted, fontSize = 15.sp, modifier = Modifier.padding(20.dp)) }
                }
                items(shown, key = { it.id }) { t ->
                    Row(
                        Modifier.fillMaxWidth().clickable { openId = t.id }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(t.color), contentAlignment = Alignment.Center) {
                            Icon(t.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.title, color = c.ink, fontSize = 16.sp)
                            Text(t.subtitle, color = c.inkMuted, fontSize = 13.sp)
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = c.inkMuted)
                    }
                }
            }
        } else {
            val chip = c.inkMuted.copy(alpha = 0.22f)
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = navBottom + 24.dp)) {
                item {
                    Text(
                        open.summary, color = c.ink, fontSize = 15.sp, lineHeight = 21.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp).clip(RoundedCornerShape(12.dp))
                            .background(open.color.copy(alpha = 0.18f)).padding(14.dp),
                    )
                }
                open.sections.forEach { (heading, steps) ->
                    item {
                        Text(heading.uppercase(), color = c.inkMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
                    }
                    items(steps.size) { n ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Box(Modifier.size(22.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                                Text("${n + 1}", color = c.onAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(keyed(steps[n], chip, c.ink), color = c.ink, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
                open.tip?.let { tip ->
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(12.dp))
                                .background(c.inkMuted.copy(alpha = 0.12f)).padding(12.dp),
                        ) {
                            Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(keyed(tip, chip, c.ink), color = c.ink, fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }
                val related = open.related.mapNotNull { id -> topics.firstOrNull { it.id == id } }
                if (related.isNotEmpty()) {
                    item {
                        Text("RELATED", color = c.inkMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
                    }
                    items(related, key = { "rel-" + it.id }) { t ->
                        Text(t.title, color = c.accent, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { openId = t.id }.padding(vertical = 8.dp))
                    }
                }
            }
        }
    }
}
