package com.t9dialer.app.ui

import android.content.Context
import android.text.format.DateFormat as AndroidDateFormat
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.res.painterResource
import com.t9dialer.app.R
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.Manifest
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.foundation.layout.BoxWithConstraints
import com.t9dialer.app.data.UiStyle
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.interaction.MutableInteractionSource
import kotlinx.coroutines.delay
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material.icons.filled.Warning
import com.t9dialer.app.data.Emergency
import com.t9dialer.app.data.TapAction
import com.t9dialer.app.data.PhoneState
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.provider.CallLog
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import com.t9dialer.app.data.HomeView
import com.t9dialer.app.data.VaultSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.t9dialer.app.Actions
import com.t9dialer.app.data.PhoneEntry
import com.t9dialer.app.data.Prefs
import com.t9dialer.app.data.RecentGroup
import com.t9dialer.app.data.numberKey
import com.t9dialer.app.data.withDialPrefix
import com.t9dialer.app.data.withLongPressPrefix

/** Which ready-message list to show, and for whom. [digits] is the WhatsApp number (international, no +). */
private class ReadyRequest(val whatsapp: Boolean, val name: String, val number: String, val digits: String?)

/** A ready SMS waiting out its 3-second Undo window. */
private class PendingSms(val name: String, val number: String, val text: String)

/** What the long-press sheet and speed-dial dialog act on. */
private class SheetTarget(
    val title: String,
    val number: String,
    val contactId: Long?,
    val lookupKey: String?,
    /** Set for call log rows: the calls that "Delete from call log" removes. */
    val callIds: List<Long> = emptyList(),
)

private val PERMISSIONS = arrayOf(
    Manifest.permission.READ_CONTACTS,
    Manifest.permission.READ_CALL_LOG,
    Manifest.permission.CALL_PHONE,
    Manifest.permission.WRITE_CALL_LOG,
)

@Composable
fun DialerApp(vm: DialerViewModel) {
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var aboutPage by rememberSaveable { mutableStateOf(AboutPage.MAIN) }
    var showSpeedDial by rememberSaveable { mutableStateOf(false) }
    var showSetup by rememberSaveable { mutableStateOf(false) }
    var showHelp by rememberSaveable { mutableStateOf(false) }
    // Which set of hidden notes is open. Not saved: notes always start locked.
    var openVault by remember { mutableStateOf<VaultSession?>(null) }
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    // With Vibrate on tap unticked, nothing in the app vibrates: key taps, long-presses, swipes
    val haptics = if (prefs.vibrateOnTap) LocalHapticFeedback.current else NoHaptics
    // Two independent styles: one for the main screen, one for Settings, menus and pop-ups
    val dark = isDark(prefs.theme)
    val menuStyle = prefs.menuStyle ?: prefs.mainStyle
    val mainColors = styleColors(prefs.mainStyle, dark)
    val menuColors = styleColors(menuStyle, dark)
    val onMain = openVault == null && prefs.setupDone && !showSetup && !showAbout && !showSpeedDial && !showSettings && !showHelp
    CompositionLocalProvider(
        LocalHapticFeedback provides haptics,
        LocalMultilineNames provides prefs.multilineNames,
        LocalShowOrg provides prefs.showOrg,
        LocalMainLook provides mainLook(prefs.mainStyle, dark),
        LocalMenuLook provides menuLook(menuStyle, dark),
        LocalMenuColors provides menuColors,
        LocalDialerColors provides if (onMain) mainColors else menuColors,
    ) {
        when {
            openVault != null -> SecretNotesScreen(openVault!!, onLock = { openVault = null })
            // First launch, or Settings > General > Permissions
            !prefs.setupDone || showSetup -> SetupScreen(onDone = {
                showSetup = false
                if (!prefs.setupDone) vm.updatePrefs { it.copy(setupDone = true) }
                vm.refresh()
            })
            showAbout -> AboutScreen(
                onBack = { showAbout = false; aboutPage = AboutPage.MAIN },
                start = aboutPage,
                onOpenPermissions = { showSetup = true },
            )
            showHelp -> HelpScreen(prefs, onBack = { showHelp = false })
            // Opened from the ⋮ menu or from Settings; back returns to wherever it was opened from
            showSpeedDial -> SpeedDialScreen(vm, onBack = { showSpeedDial = false })
            showSettings -> SettingsScreen(
                vm,
                onBack = { showSettings = false },
                onOpenSpeedDial = { showSpeedDial = true },
                onOpenSetup = { showSetup = true },
                onOpenHelp = { showHelp = true },
                onOpenAbout = { page -> aboutPage = page; showAbout = true },
            )
            else -> MainScreen(
                vm,
                openSettings = { showSettings = true },
                openAbout = { showAbout = true },
                openSpeedDial = { showSpeedDial = true },
                openHelp = { showHelp = true },
                openVault = { openVault = it },
            )
        }
    }
}

@Composable
private fun MainScreen(
    vm: DialerViewModel,
    openSettings: () -> Unit,
    openAbout: () -> Unit,
    openSpeedDial: () -> Unit,
    openHelp: () -> Unit,
    openVault: (VaultSession) -> Unit,
) {
    val context = LocalContext.current
    val c = LocalDialerColors.current
    val query by vm.query.collectAsStateWithLifecycle()
    val cursor by vm.cursor.collectAsStateWithLifecycle()
    val selection by vm.selection.collectAsStateWithLifecycle()
    val text by vm.text.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val feedback = rememberKeyFeedback(prefs.vibrateOnTap, prefs.vibrateMs, prefs.keyTones)

    var dialpadOpen by rememberSaveable { mutableStateOf(true) }
    // Every launch starts on the view chosen in Settings > General
    var view by rememberSaveable { mutableStateOf(prefs.defaultView) }
    var sheet by remember { mutableStateOf<SheetTarget?>(null) }
    var speedDialFor by remember { mutableStateOf<SheetTarget?>(null) }
    var showSpeedDials by remember { mutableStateOf(false) }
    var deleteFor by remember { mutableStateOf<SheetTarget?>(null) }
    var readyFor by remember { mutableStateOf<ReadyRequest?>(null) }
    var pendingSms by remember { mutableStateOf<PendingSms?>(null) }
    var smsCountdown by remember { mutableIntStateOf(0) }
    val openReady: (ReadyRequest) -> Unit = { readyFor = it }
    var pendingDelete by remember { mutableStateOf<List<Long>>(emptyList()) }
    var confirmClearLog by remember { mutableStateOf(false) }
    var pendingClear by remember { mutableStateOf(false) }
    var askedForAccess by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val textMode = text != null
    val searching = if (textMode) !text.isNullOrBlank() else query.isNotEmpty()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.refresh() }

    val requestAccess: () -> Unit = {
        if (askedForAccess) Actions.openAppSettings(context)
        else { askedForAccess = true; permissionLauncher.launch(PERMISSIONS) }
    }

    // Ask once on first launch; after that the card offers a way to settings.
    LaunchedEffect(state.loaded) {
        if (state.loaded && !state.hasContacts && !askedForAccess) requestAccess()
    }

    // Secret codes: typing one (always ending in ##) opens its hidden notes and clears the keypad.
    // Nothing is dialled, searched or recorded.
    LaunchedEffect(query, text) {
        listState.scrollToItem(0)
        if (query.isNotEmpty() && !textMode) dialpadOpen = true
    }

    BackHandler(enabled = !textMode && !dialpadOpen) { dialpadOpen = true }
    BackHandler(enabled = !textMode && dialpadOpen && query.isNotEmpty()) { vm.clear() }
    BackHandler(enabled = textMode) { vm.closeTextSearch() }

    // Dragging the results list up tucks the keypad away so you can see more.
    val collapseOnDrag = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput && available.y < -6f) dialpadOpen = false
                return Offset.Zero
            }
        }
    }

    val call: (String) -> Unit = { number -> Actions.call(context, withDialPrefix(number, prefs.dialPrefix)) }
    val toast: (String) -> Unit = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
    val message: (String) -> Unit = { number -> Actions.message(context, number) }

    // Tapping a row: with One touch dialing it calls; otherwise it opens the saved contact,
    // or the options sheet for numbers that aren't saved.
    // ---------- ready SMS: 3 seconds to undo, then sends ----------
    LaunchedEffect(pendingSms) {
        val p = pendingSms ?: return@LaunchedEffect
        smsCountdown = 3
        while (smsCountdown > 0) { delay(1_000); smsCountdown-- }
        pendingSms = null
        if (!Emergency.canSendSms(context)) {
            Actions.messageWithText(context, p.number, p.text)   // no SMS permission: open Messages with it typed
        } else {
            val sent = withContext(Dispatchers.IO) { Emergency.send(context, listOf(p.number), p.text) }
            toast(if (sent == 1) "Message sent to ${p.name}" else "Couldn't send the message. Check your signal.")
        }
    }

    // ---------- emergency message ----------
    var emergencyCountdown by remember { mutableStateOf(false) }
    val emergencyScope = rememberCoroutineScope()

    /** Texts the emergency message (with location if set) to every emergency contact, then calls the first one if set. */
    val sendEmergency: () -> Unit = {
        val p = prefs
        val numbers = p.emergencyContacts.map { it.number }
        emergencyScope.launch {
            if (!Emergency.canSendSms(context)) {
                // No permission to send texts: open Messages with everything filled in, ready to send
                Actions.composeToMany(context, numbers, p.emergencyMessage.trim())
                return@launch
            }
            toast("Sending emergency message\u2026")
            val link = if (p.emergencyLocation) Emergency.locationLink(context) else null
            val text = p.emergencyMessage.trim() + if (link != null) "\nMy location: $link" else ""
            val sent = withContext(Dispatchers.IO) { Emergency.send(context, numbers, text) }
            toast(
                when {
                    sent == numbers.size -> "Emergency message sent to $sent ${if (sent == 1) "contact" else "contacts"}"
                    sent == 0 -> "Couldn't send the emergency message. Check your signal."
                    else -> "Emergency message sent to $sent of ${numbers.size} contacts"
                }
            )
            if (p.emergencyCall && numbers.isNotEmpty()) call(numbers.first())
        }
    }
    val triggerEmergency: () -> Unit = {
        vm.clear()
        if (prefs.emergencyCountdown) emergencyCountdown = true else sendEmergency()
    }

    // Secret codes on the keypad: the emergency code, or a notes code. Nothing is dialled or searched.
    LaunchedEffect(query) {
        if (prefs.emergencyCode.isNotEmpty() && query == "${prefs.emergencyCode}##") {
            if (prefs.emergencyReady) triggerEmergency()
            else { vm.clear(); toast("Set up the emergency message in Settings first") }
            return@LaunchedEffect
        }
        if (query.length > 2 && query.endsWith("##")) {
            // Checking a notes code is slow on purpose (it makes the decryption key), so it runs off the main thread
            val session = withContext(Dispatchers.Default) { vm.vault.open(query) }
            if (session != null) { vm.clear(); openVault(session) }
        }
    }

    // Which row's quick actions are open (only one at a time); closes when the list changes
    var expandedKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(query, text, view) { expandedKey = null }

    // Tapping a row: One touch dialing calls; otherwise quick actions open under it,
    // or the full contact opens, depending on Settings > Tapping a name.
    val tapEntry: (PhoneEntry, String) -> Unit = { e, key ->
        when {
            prefs.oneTouchDial -> call(e.number)
            prefs.tapAction == TapAction.CONTACT -> Actions.openContact(context, e.contactId, e.lookupKey)
            else -> { expandedKey = if (expandedKey == key) null else key }
        }
    }
    val tapRecent: (RecentGroup, String) -> Unit = { r, key ->
        val contact = r.contact
        when {
            r.number.isBlank() -> { sheet = r.toTarget() }
            prefs.oneTouchDial -> call(r.number)
            prefs.tapAction == TapAction.CONTACT && contact != null -> Actions.openContact(context, contact.contactId, contact.lookupKey)
            prefs.tapAction == TapAction.CONTACT -> { sheet = r.toTarget() }
            else -> { expandedKey = if (expandedKey == key) null else key }
        }
    }

    val deleteCalls: (List<Long>) -> Unit = { ids ->
        vm.deleteCalls(ids) { n ->
            toast(
                when {
                    n < 0 -> "Allow Call logs permission to delete calls"
                    n == 1 -> "Call deleted from call log"
                    else -> "$n calls deleted from call log"
                }
            )
        }
    }
    // Asked the first time you delete, if it wasn't granted at start-up
    val clearLog: () -> Unit = {
        vm.clearCallLog { n ->
            toast(
                when {
                    n < 0 -> "Allow Call logs permission to clear the call log"
                    n == 0 -> "The call log is already empty"
                    else -> "Call log cleared ($n ${if (n == 1) "call" else "calls"})"
                }
            )
        }
    }
    val writeLogPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        when {
            !ok -> toast("Allow Call logs permission to delete calls")
            pendingClear -> clearLog()
            else -> deleteCalls(pendingDelete)
        }
        pendingDelete = emptyList()
        pendingClear = false
    }

    fun speedDial(slot: Int) {
        val d = prefs.speedDials[slot]
        if (d == null) {
            toast("Nothing on speed dial $slot. Long-press a contact to set it.")
        } else {
            vm.clear()
            call(d.number)
        }
    }

    val onLongKey: (Char) -> Unit = { k ->
        when {
            k == '0' -> { feedback(k); vm.press('+') }
            k == '#' -> openSettings()
            k == '1' && query.isEmpty() -> Actions.voicemail(context)
            k in '2'..'9' && query.isEmpty() -> speedDial(k - '0')
            k.isDigit() && query.length == 1 && query[0] in '1'..'9' -> speedDial((query[0] - '0') * 10 + (k - '0'))
            else -> { feedback(k); vm.press(k) }
        }
    }

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    // Picking a view shows it straight away, clearing any search in progress
    val selectView: (HomeView) -> Unit = { v -> view = v; vm.clear(); vm.closeTextSearch() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        // Only swipe-to-close; swiping open would clash with swiping rows to call
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            CompositionLocalProvider(LocalDialerColors provides LocalMenuColors.current) {
            AppDrawer(
                current = view,
                onSelect = { v -> selectView(v); scope.launch { drawerState.close() } },
                onAddContact = { scope.launch { drawerState.close() }; Actions.addContact(context, query) },
                onSettings = { scope.launch { drawerState.close() }; openSettings() },
                onAbout = { scope.launch { drawerState.close() }; openAbout() },
                onHelp = { scope.launch { drawerState.close() }; openHelp() },
            )
            }
        },
    ) {
    Column(Modifier.fillMaxSize().background(LocalMainLook.current.background).imePadding()) {
        TopBar(
            textMode = textMode,
            text = text.orEmpty(),
            onText = vm::setText,
            onOpenSearch = { vm.openTextSearch() },
            onCloseSearch = { vm.closeTextSearch() },
            view = view,
            onSelectView = selectView,
            onMenu = { scope.launch { drawerState.open() } },
            onAddContact = { Actions.addContact(context, query) },
            onSettings = openSettings,
            onSpeedDial = openSpeedDial,
            onClearLog = { confirmClearLog = true },
            onHelp = openHelp,
        )

        // Settings > Appearance > Font size scales all text in the list (names, numbers, details)
        val baseDensity = LocalDensity.current
        // Rows are laid out for names at 16; Font size 15 (the default) draws names at 15, and so on
        val listDensity = Density(baseDensity.density, baseDensity.fontScale * prefs.listFontSize / 16f)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            pendingSms?.let { p ->
                // Shown above the list while a ready SMS counts down
                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .zIndex(1f)
                        .padding(12.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(c.panel)
                        .padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Sending to ${p.name} in $smsCountdown\u2026", color = c.ink, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = { pendingSms = null; toast("Message not sent") }) { Text("UNDO", color = c.accent, fontWeight = FontWeight.SemiBold) }
                }
            }
        CompositionLocalProvider(LocalDensity provides listDensity) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().nestedScroll(collapseOnDrag),
                contentPadding = PaddingValues(bottom = if (textMode) navBottom + 12.dp else 12.dp),
            ) {
                if (state.loaded && !state.hasContacts) {
                    item("access") { AccessCard(opensSettings = askedForAccess, onAllow = requestAccess) }
                }

                if (!searching) {
                    when (view) {
                        HomeView.CALL_LOG -> {
                            if (state.recents.isEmpty()) {
                                item("e-log") { EmptyNote(if (state.hasCallLog) "No calls yet." else "Allow call history access to see your calls here.") }
                            }
                            itemsIndexed(state.recents, key = { i, r -> "r$i-${r.key}" }) { i, r ->
                                val rowKey = "r$i-${r.key}"
                                Column {
                                    SwipeActions(prefs.swipeActions && r.number.isNotBlank(), { call(r.number) }, { message(r.number) }) {
                                        RecentRow(
                                            r, AnnotatedString(r.title()), AnnotatedString(r.number),
                                            onClick = { tapRecent(r, rowKey) },
                                            onLongClick = { sheet = r.toTarget() },
                                            expanded = expandedKey == rowKey,
                                        )
                                    }
                                    QuickActions(expandedKey == rowKey, { expandedKey = null }, r.number, r.contact?.label, r.contact, state, vm, call, openReady)
                                }
                            }
                        }
                        HomeView.CONTACTS, HomeView.FAVOURITES -> {
                            val list = if (view == HomeView.FAVOURITES) state.favourites else state.contacts
                            if (list.isEmpty() && state.hasContacts) {
                                item("e-contacts") {
                                    EmptyNote(
                                        if (view == HomeView.FAVOURITES) "No favourites yet. Star someone in your Contacts app and they'll show here."
                                        else "No contacts with phone numbers yet."
                                    )
                                }
                            }
                            items(list, key = { "a${it.contactId}" }) { e ->
                                val rowKey = "a${e.contactId}"
                                Column {
                                    SwipeActions(prefs.swipeActions, { call(e.number) }, { message(e.number) }) {
                                        ContactRow(
                                            e, AnnotatedString(e.name), AnnotatedString(e.number),
                                            onClick = { tapEntry(e, rowKey) },
                                            onLongClick = { sheet = e.toTarget() },
                                            expanded = expandedKey == rowKey,
                                        )
                                    }
                                    QuickActions(expandedKey == rowKey, { expandedKey = null }, e.number, e.label, e, state, vm, call, openReady)
                                }
                            }
                        }
                        HomeView.FREQUENT -> {
                            if (state.frequent.isEmpty()) {
                                item("e-freq") {
                                    EmptyNote(
                                        if (state.hasCallLog) "People you call often will show here once you've called them a couple of times."
                                        else "Allow call history access to see who you call most."
                                    )
                                }
                            }
                            items(state.frequent, key = { "f${it.recent.key}" }) { f ->
                                val r = f.recent
                                val rowKey = "f${r.key}"
                                Column {
                                SwipeActions(prefs.swipeActions, { call(r.number) }, { message(r.number) }) {
                                    PersonRow(
                                        AnnotatedString(r.title()), r.name, r.contact?.photoUri,
                                        onClick = { tapRecent(r, rowKey) },
                                        onLongClick = { sheet = r.toTarget() },
                                        org = r.contact?.org,
                                        expanded = expandedKey == rowKey,
                                        trailing = {
                                            Text("${f.count} calls", color = c.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                                        },
                                    ) {
                                        Text(if (r.name != null) r.number else "Not in contacts", color = c.inkMuted, fontSize = 13.sp)
                                    }
                                }
                                QuickActions(expandedKey == rowKey, { expandedKey = null }, r.number, r.contact?.label, r.contact, state, vm, call, openReady)
                                }
                            }
                        }
                    }
                } else {
                    if (results.calls.isNotEmpty()) {
                        item("h-calls") { SectionHeader("Call log") }
                        items(results.calls, key = { "l${it.recent.key}" }) { h ->
                            val rowKey = "l${h.recent.key}"
                            Column {
                            SwipeActions(prefs.swipeActions, { call(h.recent.number) }, { message(h.recent.number) }) {
                                val numberText = highlight(h.recent.number, h.numberHighlights, c.accent)
                                RecentRow(
                                    h.recent,
                                    // Unsaved numbers show the number as the title, so highlight it there
                                    if (h.recent.name != null) highlight(h.recent.title(), h.nameHighlights, c.accent) else numberText,
                                    numberText,
                                    onClick = { tapRecent(h.recent, rowKey) },
                                    onLongClick = { sheet = h.recent.toTarget() },
                                    expanded = expandedKey == rowKey,
                                )
                            }
                            QuickActions(expandedKey == rowKey, { expandedKey = null }, h.recent.number, h.recent.contact?.label, h.recent.contact, state, vm, call, openReady)
                            }
                        }
                    }
                    if (results.contacts.isNotEmpty()) {
                        item("h-phones") { SectionHeader("Contacts") }
                        items(results.contacts, key = { "c${it.entry.contactId}:${it.entry.number}" }) { h ->
                            val rowKey = "c${h.entry.contactId}:${h.entry.number}"
                            Column {
                            SwipeActions(prefs.swipeActions, { call(h.entry.number) }, { message(h.entry.number) }) {
                                ContactRow(
                                    h.entry,
                                    highlight(h.entry.name, h.nameHighlights, c.accent),
                                    highlight(h.entry.number, h.numberHighlights, c.accent),
                                    onClick = { tapEntry(h.entry, rowKey) },
                                    onLongClick = { sheet = h.entry.toTarget() },
                                    expanded = expandedKey == rowKey,
                                )
                            }
                            QuickActions(expandedKey == rowKey, { expandedKey = null }, h.entry.number, h.entry.label, h.entry, state, vm, call, openReady)
                            }
                        }
                    }
                    if (results.isEmpty && !textMode) {
                        item("no-match") {
                            Column(Modifier.padding(top = 8.dp)) {
                                ActionRow(Icons.Filled.PersonAdd, "Add ${vm.format(query).ifEmpty { query }} to contacts") {
                                    Actions.addContact(context, query)
                                }
                                ActionRow(Icons.AutoMirrored.Filled.Message, "Send a message") { message(query) }
                            }
                        }
                    }
                    if (results.isEmpty && textMode) {
                        item("no-text-match") {
                            Text(
                                "No one matches \u201c${text.orEmpty().trim()}\u201d.",
                                color = c.inkMuted, fontSize = 15.sp,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                            )
                        }
                    }
                }
            }
        }
        }

        if (!textMode) {
            val display = vm.format(query).ifEmpty { query }
            AnimatedVisibility(
                visible = dialpadOpen,
                enter = expandVertically(expandFrom = Alignment.Top) + fadeIn(),
                exit = shrinkVertically(shrinkTowards = Alignment.Top) + fadeOut(),
            ) {
                DialpadPanel(
                    query = query,
                    display = display,
                    cyrillic = prefs.cyrillicKeys,
                    scale = prefs.dialpadSize.scale,
                    onKey = { k -> feedback(k); vm.press(k) },
                    onLongKey = onLongKey,
                    // Delete vibrates like the keys (same Vibrate on tap and Vibrate duration settings), without a tone
                    onBackspace = { feedback(DELETE_KEY); vm.backspace() },
                    onClear = vm::clear,
                    // With nothing typed, the call button does nothing
                    onCall = {
                        // The emergency code followed by the call button sends the emergency message
                        if (prefs.emergencyReady && query == prefs.emergencyCode) triggerEmergency()
                        else if (query.isNotEmpty()) call(query)
                    },
                    onCallLong = {
                        if (query.isNotEmpty()) Actions.call(context, withLongPressPrefix(query, prefs.longPressPrefix))
                    },
                    // Pasting adds at the cursor, so you can paste more than once
                    onPaste = { pasted ->
                        if (pasted.none { it.isDigit() || it in "+*#" }) toast("No phone number on the clipboard") else vm.insert(pasted)
                    },
                    cursor = cursor,
                    onMoveCursor = vm::moveCursor,
                    edit = NumberEditing(
                        selection = selection,
                        onSelect = vm::select,
                        onSelectAll = vm::selectAll,
                        // Copies just the digits (no spaces), so they paste cleanly anywhere
                        onCut = { Actions.copy(context, vm.selectedText()); vm.deleteSelection() },
                        onCopy = { Actions.copy(context, vm.selectedText().ifEmpty { query }) },
                    ),
                    onSearch = { vm.openTextSearch() },
                    onFavourites = { selectView(HomeView.FAVOURITES) },
                    onAddContact = { Actions.addContact(context, query) },
                    onLog = { selectView(HomeView.CALL_LOG) },
                    onHide = { dialpadOpen = false },
                )
            }
            AnimatedVisibility(visible = !dialpadOpen, enter = fadeIn(), exit = fadeOut()) {
                CollapsedDialpad(query, display, onShow = { dialpadOpen = true })
            }
        }
    }
    }

    // Pop-ups (long-press menu, ready messages, dialogs) follow the Settings & menus style
    CompositionLocalProvider(LocalDialerColors provides LocalMenuColors.current) {
    sheet?.let { target ->
        ActionsSheet(
            target,
            prefs = prefs,
            onEdit = { vm.closeTextSearch(); vm.setQuery(target.number); dialpadOpen = true },
            onSpeedDial = { speedDialFor = target },
            onRemoveSpeedDial = { slot -> vm.removeSpeedDial(slot) },
            onDelete = { deleteFor = target },
            onReadySms = { readyFor = ReadyRequest(false, target.title, target.number, null) },
            onReadyWa = run {
                val digits = state.whatsapp[numberKey(target.number)]?.digits ?: vm.internationalDigits(target.number)
                if (state.hasWhatsApp && digits != null) ({ readyFor = ReadyRequest(true, target.title, target.number, digits) }) else null
            },
            onDismiss = { sheet = null },
        )
    }

    readyFor?.let { req ->
        ReadyMessagesSheet(
            req,
            messages = if (req.whatsapp) prefs.readyWa else prefs.readySms,
            onPick = { text ->
                readyFor = null
                if (req.whatsapp) req.digits?.let { Actions.whatsappChat(context, it, text) }
                else pendingSms = PendingSms(req.name, req.number, text)
            },
            onDismiss = { readyFor = null },
        )
    }

    if (emergencyCountdown) {
        EmergencyCountdown(
            contacts = prefs.emergencyContacts.size,
            onSend = { emergencyCountdown = false; sendEmergency() },
            onCancel = { emergencyCountdown = false; toast("Emergency message cancelled") },
        )
    }

    if (confirmClearLog) {
        AlertDialog(
            onDismissRequest = { confirmClearLog = false },
            icon = { Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = c.missed) },
            title = { Text("Clear call log?") },
            text = {
                Text(
                    "This deletes all ${state.recents.sumOf { it.count }.takeIf { it > 0 }?.let { "$it " } ?: ""}calls from your phone's call history. " +
                        "Contacts aren't affected. This can't be undone.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmClearLog = false
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALL_LOG) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) clearLog() else { pendingClear = true; writeLogPermission.launch(Manifest.permission.WRITE_CALL_LOG) }
                }) { Text("Clear", color = c.missed) }
            },
            dismissButton = { TextButton(onClick = { confirmClearLog = false }) { Text("Cancel") } },
        )
    }

    deleteFor?.let { target ->
        val calls = target.callIds.size
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Delete from call log?") },
            text = {
                Text(
                    (if (calls == 1) "This call with ${target.title} is removed from your call history."
                     else "These $calls calls with ${target.title} are removed from your call history.") +
                        " The contact itself isn't deleted.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleteFor = null
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALL_LOG) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) deleteCalls(target.callIds)
                    else { pendingDelete = target.callIds; writeLogPermission.launch(Manifest.permission.WRITE_CALL_LOG) }
                }) { Text("Delete", color = c.missed) }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Cancel") } },
        )
    }

    if (showSpeedDials) {
        SpeedDialListDialog(
            prefs = prefs,
            onCall = { number -> showSpeedDials = false; call(number) },
            onRemove = { slot -> vm.removeSpeedDial(slot) },
            onDismiss = { showSpeedDials = false },
        )
    }

    speedDialFor?.let { target ->
        SpeedDialDialog(
            target, prefs,
            onSave = { slot ->
                vm.setSpeedDial(slot, target.title, target.number)
                toast(if (slot < 10) "Long-press $slot to call ${target.title}" else "Tap ${slot / 10}, then long-press ${slot % 10} to call ${target.title}")
                speedDialFor = null
            },
            onDismiss = { speedDialFor = null },
        )
    }
    }
}

// ---------- ready messages ----------

/** The 5 ready SMS (send after an Undo window) or 5 ready WhatsApp messages (open with the text typed). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReadyMessagesSheet(req: ReadyRequest, messages: List<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val accent = if (req.whatsapp) WaGreen else OutgoingBlue
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = LocalMenuLook.current.cardFill) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (req.whatsapp) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Filled.Message,
                    contentDescription = null, tint = accent, modifier = Modifier.size(20.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    (if (req.whatsapp) "Ready WhatsApp to " else "Ready SMS to ") + req.name,
                    color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                if (req.whatsapp) "Opens WhatsApp with it typed; tap Send there" else "Sends from your phone after 3 seconds (you can undo)",
                color = c.inkMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp),
            )
            val usable = messages.filter { it.isNotBlank() }
            if (usable.isEmpty()) {
                Text("No ready messages. Add some in Settings > Ready messages.", color = c.inkMuted, fontSize = 15.sp)
            }
            usable.forEach { text ->
                Text(
                    text,
                    color = c.ink,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.10f))
                        .clickable { onPick(text) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                )
            }
        }
    }
}

// ---------- emergency countdown ----------

/** 5-second countdown with Cancel and Send now; sends by itself when it reaches 0. */
@Composable
private fun EmergencyCountdown(contacts: Int, onSend: () -> Unit, onCancel: () -> Unit) {
    val c = LocalDialerColors.current
    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) {
        while (left > 0) { delay(1_000); left-- }
        onSend()
    }
    AlertDialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(dismissOnClickOutside = false),
        icon = { Icon(Icons.Filled.Warning, contentDescription = null, tint = c.missed) },
        title = { Text("Emergency message") },
        text = {
            Text(
                "Sending to your $contacts emergency ${if (contacts == 1) "contact" else "contacts"} in $left\u2026",
                fontSize = 16.sp,
            )
        },
        confirmButton = { TextButton(onClick = onSend) { Text("Send now", color = c.missed) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

// ---------- quick actions ----------


/**
 * Opens under a tapped row and reads as part of it: same tint, no line in between.
 * First line: Call, SMS, Info (Add contact for unsaved numbers).
 * Second line, only when the person uses WhatsApp: WA call, WA chat, WA video (unsaved numbers: chat only).
 * Tapping any empty space here closes it, like tapping the name again.
 */
@Composable
private fun QuickActions(
    visible: Boolean,
    onClose: () -> Unit,
    number: String,
    label: String?,
    contact: PhoneEntry?,
    state: PhoneState,
    vm: DialerViewModel,
    call: (String) -> Unit,
    onReady: (ReadyRequest) -> Unit,
) {
    AnimatedVisibility(visible = visible, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
        val c = LocalDialerColors.current
        val context = LocalContext.current
        val wa = state.whatsapp[numberKey(number)]
        val chatDigits = remember(number, wa) { wa?.digits ?: vm.internationalDigits(number) }
        val showWa = state.hasWhatsApp && if (contact != null) wa != null else chatDigits != null
        Column {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(c.accent.copy(alpha = RowTintAlpha))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
                    .padding(start = 12.dp, end = 10.dp, top = 4.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickPill(Icons.Filled.Call, "Call", c.call, c.call.copy(alpha = 0.16f)) { call(number) }
                    // Tap: empty SMS. Long-press: ready SMS list.
                    QuickPill(
                        Icons.AutoMirrored.Filled.Message, "SMS", OutgoingBlue, OutgoingBlue.copy(alpha = 0.16f),
                        onLongClick = { onReady(ReadyRequest(false, contact?.name ?: number, number, chatDigits)) },
                    ) { Actions.message(context, number) }
                    if (contact != null) {
                        QuickPill(Icons.Filled.Info, "Info", c.ink, c.inkMuted.copy(alpha = 0.16f)) {
                            Actions.openContact(context, contact.contactId, contact.lookupKey)
                        }
                    } else {
                        QuickPill(Icons.Filled.PersonAdd, "Add", c.ink, c.inkMuted.copy(alpha = 0.16f)) {
                            Actions.addContact(context, number)
                        }
                    }
                }
                if (showWa) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        wa?.voiceId?.let { id ->
                            QuickPill(Icons.Filled.Call, "WA call", Color.White, WaGreen) { Actions.whatsappCall(context, id, video = false) }
                        }
                        chatDigits?.let { digits ->
                            // Tap: empty chat. Long-press: ready WhatsApp list.
                            QuickPill(
                                Icons.AutoMirrored.Filled.Chat, "WA chat", Color.White, WaGreen,
                                onLongClick = { onReady(ReadyRequest(true, contact?.name ?: number, number, digits)) },
                            ) { Actions.whatsappChat(context, digits) }
                        }
                        wa?.videoId?.let { id ->
                            QuickPill(Icons.Filled.Videocam, "WA video", Color.White, WaGreen) { Actions.whatsappCall(context, id, video = true) }
                        }
                    }
                }
            }
            RowDivider()
        }
    }
}

/** A slim pill button: icon and label side by side, 32dp tall, sharing the line equally. */
@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun RowScope.QuickPill(
    icon: ImageVector,
    label: String,
    tint: Color,
    background: Color,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .weight(1f)
            .height(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick, onLongClickLabel = onLongClick?.let { "Ready messages" }),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = tint, fontSize = 12.sp, maxLines = 1)
    }
}

// ---------- top bar ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ViewChips(current: HomeView, onSelect: (HomeView) -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (v in HomeView.entries) {
            FilterChip(
                selected = v == current,
                onClick = { onSelect(v) },
                label = { Text(v.label) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = c.accent,
                    selectedLabelColor = c.onAccent,
                    labelColor = c.inkMuted,
                ),
            )
        }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(
        text,
        color = LocalDialerColors.current.inkMuted,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
    )
}

@Composable
private fun TopBar(
    textMode: Boolean,
    text: String,
    onText: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onCloseSearch: () -> Unit,
    view: HomeView,
    onSelectView: (HomeView) -> Unit,
    onMenu: () -> Unit,
    onAddContact: () -> Unit,
    onSettings: () -> Unit,
    onSpeedDial: () -> Unit,
    onClearLog: () -> Unit,
    onHelp: () -> Unit,
) {
    val look = LocalMainLook.current
    val base = LocalDialerColors.current
    // On a solid coloured bar (Flat), the bar's text and icons turn white
    val c = if (look.topBarMono) base.copy(ink = Color.White, inkMuted = Color.White.copy(alpha = 0.85f), accent = Color.White) else base
    CompositionLocalProvider(LocalDialerColors provides c) {
    Row(
        Modifier.fillMaxWidth().background(look.topBarBg).statusBarsPadding().height(56.dp).padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (textMode) {
            val focus = remember { FocusRequester() }
            LaunchedEffect(Unit) { focus.requestFocus() }
            IconButton(onClick = onCloseSearch) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search", tint = c.ink) }
            TextField(
                value = text,
                onValueChange = onText,
                placeholder = { Text("Search by name or number", color = c.inkMuted) },
                singleLine = true,
                modifier = Modifier.weight(1f).focusRequester(focus),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = c.accent,
                ),
            )
            if (text.isNotEmpty()) {
                IconButton(onClick = { onText("") }) { Icon(Icons.Filled.Close, contentDescription = "Clear", tint = c.inkMuted) }
            }
        } else {
            // Everything on one line, nothing scrolls or hides:
            // ☰ · app icon · Call log · Contacts · Add contact · Favourites ····· search · ⋮
            IconButton(onClick = onMenu, modifier = Modifier.size(TopIcon)) {
                Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = c.ink)
            }
            AppIcon(24.dp)
            Spacer(Modifier.width(4.dp))
            TopTab(HomeView.CALL_LOG.label, selected = view == HomeView.CALL_LOG) { onSelectView(HomeView.CALL_LOG) }
            TopTab(HomeView.CONTACTS.label, selected = view == HomeView.CONTACTS) { onSelectView(HomeView.CONTACTS) }
            IconButton(onClick = onAddContact, modifier = Modifier.size(TopIcon)) {
                Icon(Icons.Filled.PersonAdd, contentDescription = "Add contact", tint = if (look.topBarMono) c.ink else MenuColors.AddContact)
            }
            // Favourites: a filled star while that list is showing, an outline otherwise
            IconButton(onClick = { onSelectView(HomeView.FAVOURITES) }, modifier = Modifier.size(TopIcon)) {
                Icon(
                    if (view == HomeView.FAVOURITES) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favourites",
                    tint = if (look.topBarMono) c.ink else MenuColors.Favourites,
                )
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onOpenSearch, modifier = Modifier.size(TopIcon)) {
                Icon(Icons.Filled.Search, contentDescription = "Search with keyboard", tint = if (look.topBarMono) c.ink else MenuColors.Search)
            }
            Box {
                var moreOpen by remember { mutableStateOf(false) }
                IconButton(onClick = { moreOpen = true }, modifier = Modifier.size(TopIcon)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = c.inkMuted)
                }
                val menuLook = LocalMenuLook.current
                CompositionLocalProvider(LocalDialerColors provides LocalMenuColors.current) {
                DropdownMenu(
                    expanded = moreOpen,
                    onDismissRequest = { moreOpen = false },
                    shape = RoundedCornerShape(menuLook.corner),
                    containerColor = menuLook.cardFill,
                ) {
                    DropdownMenuItem(
                        text = { Text("Favourites") },
                        leadingIcon = { MenuIcon(Icons.Filled.Star, MenuColors.Favourites) },
                        onClick = { moreOpen = false; onSelectView(HomeView.FAVOURITES) },
                    )
                    DropdownMenuItem(
                        text = { Text("Frequently called") },
                        leadingIcon = { MenuIcon(Icons.Filled.Repeat, MenuColors.Frequent) },
                        onClick = { moreOpen = false; onSelectView(HomeView.FREQUENT) },
                    )
                    DropdownMenuItem(
                        text = { Text("Speed dial") },
                        leadingIcon = { MenuIcon(Icons.Filled.Speed, MenuColors.SpeedDial) },
                        onClick = { moreOpen = false; onSpeedDial() },
                    )
                    DropdownMenuItem(
                        text = { Text("Add contact") },
                        leadingIcon = { MenuIcon(Icons.Filled.PersonAdd, MenuColors.AddContact) },
                        onClick = { moreOpen = false; onAddContact() },
                    )
                    DropdownMenuItem(
                        text = { Text("Clear log") },
                        leadingIcon = { MenuIcon(Icons.Filled.DeleteSweep, MenuColors.ClearLog) },
                        onClick = { moreOpen = false; onClearLog() },
                    )
                    DropdownMenuItem(
                        text = { Text("Settings") },
                        leadingIcon = { MenuIcon(Icons.Filled.Settings, MenuColors.Settings) },
                        onClick = { moreOpen = false; onSettings() },
                    )
                    DropdownMenuItem(
                        text = { Text("Help & guide") },
                        leadingIcon = { MenuIcon(Icons.Filled.Book, MenuColors.Help) },
                        onClick = { moreOpen = false; onHelp() },
                    )
                }
                }
            }
        }
    }
    }
}

/** Size of each icon button in the top bar; small enough that all of them fit on a 360dp-wide phone. */
private val TopIcon = 34.dp

@Composable
private fun TopTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    val look = LocalMainLook.current
    val pill = if (selected) look.tabPill else null
    Column(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(pill ?: Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            label,
            color = when {
                pill != null && look.topBarMono -> Color(0xFF2547C9)   // blue text on the white pill (Flat)
                pill != null -> c.ink
                selected -> c.accent
                else -> c.inkMuted
            },
            fontSize = with(LocalDensity.current) { 14.dp.toSp() },
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
        )
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .size(width = 24.dp, height = 2.dp)
                .clip(CircleShape)
                .background(if (selected && pill == null) c.accent else Color.Transparent)
        )
    }
}

/** The small blue app icon: the launcher keypad drawn inside a rounded square. */
@Composable
internal fun AppIcon(size: Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(Color(0xFF2547C9)),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painterResource(R.drawable.ic_launcher_foreground),
            contentDescription = APP_NAME,
            modifier = Modifier.requiredSize(size * (108f / 58f)),
        )
    }
}

/** Slide-out menu from the \u2630 button. */
@Composable
private fun AppDrawer(
    current: HomeView,
    onSelect: (HomeView) -> Unit,
    onAddContact: () -> Unit,
    onSettings: () -> Unit,
    onAbout: () -> Unit,
    onHelp: () -> Unit,
) {
    val c = LocalDialerColors.current
    val look = LocalMenuLook.current
    val solidSelect = look.style == UiStyle.FLAT
    val itemColors = NavigationDrawerItemDefaults.colors(
        selectedContainerColor = look.selectedFill,
        selectedTextColor = if (solidSelect) Color.White else c.accent,
        selectedIconColor = if (solidSelect) Color.White else c.accent,
        unselectedContainerColor = Color.Transparent,
        unselectedTextColor = c.ink,
        unselectedIconColor = c.inkMuted,
    )
    ModalDrawerSheet(drawerContainerColor = if (look.style == UiStyle.GLASS) Color.Transparent else c.panel) {
        Column(
            Modifier
                .then(if (look.style == UiStyle.GLASS) Modifier.background(look.background).background(Color(0x33000000)) else Modifier)
                .verticalScroll(rememberScrollState()).padding(bottom = 16.dp),
        ) {
            Row(Modifier.padding(horizontal = 24.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(36.dp)
                Spacer(Modifier.width(12.dp))
                Text(APP_NAME, color = c.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            SectionHeader("Lists")
            for (v in HomeView.entries) {
                NavigationDrawerItem(
                    label = { Text(v.label) },
                    icon = { MenuIcon(drawerIcon(v), drawerTint(v)) },
                    selected = v == current,
                    onClick = { onSelect(v) },
                    colors = itemColors,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }
            HorizontalDivider(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), color = c.inkMuted.copy(alpha = 0.2f))
            NavigationDrawerItem(
                label = { Text("Add contact") },
                icon = { MenuIcon(Icons.Filled.PersonAdd, MenuColors.AddContact) },
                selected = false, onClick = onAddContact, colors = itemColors,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
            NavigationDrawerItem(
                label = { Text("Settings") },
                icon = { MenuIcon(Icons.Filled.Settings, MenuColors.Settings) },
                selected = false, onClick = onSettings, colors = itemColors,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
            NavigationDrawerItem(
                label = { Text("Help & guide") },
                icon = { MenuIcon(Icons.Filled.Lightbulb, Color(0xFF2547C9)) },
                selected = false, onClick = onHelp, colors = itemColors,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
            NavigationDrawerItem(
                label = { Text("About") },
                icon = { MenuIcon(Icons.Filled.Info, MenuColors.About) },
                selected = false, onClick = onAbout, colors = itemColors,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
    }
}

/** One colour per menu item, the same in the ☰ and ⋮ menus. */
private object MenuColors {
    val CallLog = Color(0xFF2196F3)     // blue
    val Contacts = Color(0xFF43A047)    // green
    val Favourites = Color(0xFFFFB300)  // amber
    val Frequent = Color(0xFF8E24AA)    // purple
    val SpeedDial = Color(0xFFF4511E)   // orange
    val AddContact = Color(0xFF00ACC1)  // teal
    val Settings = Color(0xFF5C6BC0)    // indigo
    val About = Color(0xFFEC407A)       // pink
    val Search = Color(0xFF1E90FF)      // bright blue
    val ClearLog = Color(0xFFE53935)    // red
    val Help = Color(0xFF2547C9)        // deep blue
}

private fun drawerTint(v: HomeView): Color = when (v) {
    HomeView.CALL_LOG -> MenuColors.CallLog
    HomeView.CONTACTS -> MenuColors.Contacts
    HomeView.FAVOURITES -> MenuColors.Favourites
    HomeView.FREQUENT -> MenuColors.Frequent
}

/** A menu icon in the Settings & menus style: plain, on a coloured tile, or on a raised circle. */
@Composable
private fun MenuIcon(icon: ImageVector, tint: Color) {
    val look = LocalMenuLook.current
    when {
        look.iconTile -> Box(Modifier.size(28.dp).clip(RoundedCornerShape(7.dp)).background(tint), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        look.iconRaised -> Box(
            Modifier.size(30.dp).softRaised(LocalDialerColors.current.bg, look.shadowLight, look.shadowDark, 15.dp, 4.dp, 2.dp),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp)) }
        look.style == UiStyle.GLASS -> Icon(icon, contentDescription = null, tint = Color.White)
        else -> Icon(icon, contentDescription = null, tint = tint)
    }
}

private fun drawerIcon(v: HomeView): ImageVector = when (v) {
    HomeView.CALL_LOG -> Icons.Filled.History
    HomeView.CONTACTS -> Icons.Filled.Contacts
    HomeView.FAVOURITES -> Icons.Filled.Star
    HomeView.FREQUENT -> Icons.Filled.Repeat
}

// ---------- rows ----------

/** Swipe right to call, left to message. The row springs back after the action. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SwipeActions(enabled: Boolean, onCall: () -> Unit, onMessage: () -> Unit, content: @Composable () -> Unit) {
    if (!enabled) { content(); return }
    val c = LocalDialerColors.current
    val callNow by rememberUpdatedState(onCall)
    val messageNow by rememberUpdatedState(onMessage)
    val state = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            when (value) {
                SwipeToDismissBoxValue.StartToEnd -> callNow()
                SwipeToDismissBoxValue.EndToStart -> messageNow()
                SwipeToDismissBoxValue.Settled -> Unit
            }
            false
        },
        positionalThreshold = { distance -> distance * 0.35f },
    )
    SwipeToDismissBox(
        state = state,
        backgroundContent = {
            val (bg, icon, align) = when (state.dismissDirection) {
                SwipeToDismissBoxValue.StartToEnd -> Triple(c.call, Icons.Filled.Call, Alignment.CenterStart)
                SwipeToDismissBoxValue.EndToStart -> Triple(c.accent, Icons.AutoMirrored.Filled.Message, Alignment.CenterEnd)
                SwipeToDismissBoxValue.Settled -> Triple(Color.Transparent, null, Alignment.CenterStart)
            }
            Box(Modifier.fillMaxSize().background(bg).padding(horizontal = 28.dp), contentAlignment = align) {
                if (icon != null) Icon(icon, contentDescription = null, tint = Color.White)
            }
        },
    ) {
        Box(Modifier.background(LocalMainLook.current.swipeContentBg)) { content() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PersonRow(
    title: AnnotatedString,
    avatarName: String?,
    photoUri: String?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    titleSuffix: String? = null,
    org: String? = null,
    expanded: Boolean = false,
    titleEnd: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    subtitle: @Composable () -> Unit,
) {
    val c = LocalDialerColors.current
    Column(Modifier.background(LocalMainLook.current.rowBg)) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (expanded) c.accent.copy(alpha = RowTintAlpha) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick, onLongClickLabel = "More options")
            // Photo sits 1dp from the left edge and flush with the divider above it
            .padding(start = 1.dp, end = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Avatar(avatarName, photoUri)
        Spacer(Modifier.width(6.dp))
        Column(
            Modifier.weight(1f).heightIn(min = AvatarSize).padding(vertical = 2.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                    maxLines = if (LocalMultilineNames.current) 2 else 1,
                    overflow = TextOverflow.Ellipsis,
                    // With a time on this line, the name fills the space so the time sits at the right edge
                    modifier = Modifier.weight(1f, fill = titleEnd != null),
                )
                if (titleSuffix != null) Text("  $titleSuffix", color = c.inkMuted, fontSize = 13.sp, maxLines = 1)
                // Used only when the number line is too full: the time moves here instead of being cut
                titleEnd?.invoke()
            }
            if (org != null && LocalShowOrg.current) {
                Text(
                    org, color = c.inkMuted, fontSize = 12.sp, fontStyle = FontStyle.Italic,
                    maxLines = if (LocalMultilineNames.current) 2 else 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(1.dp))
            subtitle()
        }
        trailing?.let { Box(Modifier.heightIn(min = AvatarSize), contentAlignment = Alignment.Center) { it() } }
    }
        // Thin line between rows (hidden while quick actions are open under this row)
        if (!expanded) RowDivider()
    }
}

@Composable
private fun ContactRow(
    entry: PhoneEntry,
    name: AnnotatedString,
    number: AnnotatedString,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    expanded: Boolean = false,
) {
    val c = LocalDialerColors.current
    PersonRow(name, entry.name, entry.photoUri, onClick, onLongClick, org = entry.org, expanded = expanded) {
        // Just the number, in full: no "Mobile"/"Home" label, wraps rather than cutting off
        Text(number, color = c.inkMuted, fontSize = 13.sp)
    }
}

@Composable
private fun RecentRow(r: RecentGroup, title: AnnotatedString, number: AnnotatedString, onClick: () -> Unit, onLongClick: () -> Unit, expanded: Boolean = false) {
    val context = LocalContext.current
    val c = LocalDialerColors.current
    val time = callTime(context, r.date)
    val lineText = if (r.name != null) number else AnnotatedString(if (r.number.isBlank()) callTypeName(r.type) else "Not in contacts")
    val measurer = rememberTextMeasurer()
    val base = LocalTextStyle.current
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        // Room for the number line: row width minus the 1dp edge, 46dp photo, 6dp gap and 6dp right padding
        val avail = constraints.maxWidth - with(density) { 59.dp.roundToPx() }
        val fit = remember(lineText, time, r.duration, r.type, avail, base, density) {
            fun w(text: AnnotatedString, sp: Int) = measurer.measure(text, base.copy(fontSize = sp.sp), maxLines = 1, softWrap = false).size.width
            fun w(text: String, sp: Int) = w(AnnotatedString(text), sp)
            val px = { d: Int -> with(density) { d.dp.roundToPx() } }
            val label = durationLabel(r)
            val arrow = px(21)
            val num = w(lineText, 13)
            val dur = label?.let { px(4) + w(it.first, 12) + if (it.second) px(14) else 0 } ?: 0
            when {
                arrow + num + dur + px(4) + w(time, 11) <= avail -> LineFit.NORMAL
                arrow + num + dur + px(4) + w(time, 10) <= avail -> LineFit.SMALL
                arrow + num + dur <= avail -> LineFit.TIME_UP
                else -> LineFit.BOTH_UP
            }
        }
        val timeText: @Composable () -> Unit = {
            Text(time, color = c.inkMuted, fontSize = if (fit == LineFit.SMALL) 10.sp else 11.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 4.dp))
        }
        PersonRow(
            title, r.name, r.contact?.photoUri, onClick, onLongClick,
            titleSuffix = if (r.count > 1) "(${r.count})" else null,
            org = r.contact?.org,
            expanded = expanded,
            titleEnd = when (fit) {
                LineFit.TIME_UP -> timeText
                LineFit.BOTH_UP -> ({ Row(verticalAlignment = Alignment.CenterVertically) { CallDuration(r); timeText() } })
                else -> null
            },
        ) {
            // Arrow, full number (never shortened), then duration and time on the right
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CallTypeIcon(r.type)
                Spacer(Modifier.width(5.dp))
                Text(lineText, color = c.inkMuted, fontSize = 13.sp, maxLines = 2)
                Spacer(Modifier.weight(1f))
                if (fit != LineFit.BOTH_UP) CallDuration(r)
                if (fit == LineFit.NORMAL || fit == LineFit.SMALL) timeText()
            }
        }
    }
}

/** How the call log number line fits: as is, with a smaller time, or with the time (and duration) moved up. */
private enum class LineFit { NORMAL, SMALL, TIME_UP, BOTH_UP }

/** The text CallDuration shows, and whether it has a clock icon (for measuring the line). */
private fun durationLabel(r: RecentGroup): Pair<String, Boolean>? = when {
    r.number.isBlank() && r.duration == 0L -> null
    r.type == CallLog.Calls.MISSED_TYPE -> "Missed" to false
    r.type == CallLog.Calls.REJECTED_TYPE -> "Declined" to false
    r.type == CallLog.Calls.BLOCKED_TYPE -> "Blocked" to false
    r.duration <= 0L && r.type == CallLog.Calls.OUTGOING_TYPE -> "No answer" to false
    r.duration > 0L -> formatDuration(r.duration) to true
    else -> null
}

private val AvatarSize = 46.dp

/** The thin line under each row, in the main screen style (Neumorphic draws a soft groove). Same 0.5dp height. */
@Composable
private fun RowDivider() {
    val look = LocalMainLook.current
    Box(
        Modifier.fillMaxWidth().height(0.5.dp).background(look.divider)
            .drawBehind { look.dividerHighlight?.let { drawLine(it, Offset(0f, size.height), Offset(size.width, size.height), 0.5.dp.toPx()) } },
    )
}

private val WaGreen = Color(0xFF1FA855)

/** Passed to the key feedback for the delete button: vibrates, plays no dial tone. */
private const val DELETE_KEY = '\b'

/** Faint tint on a row whose quick actions are open, so the row and its buttons read as one. */
private const val RowTintAlpha = 0.07f

@Composable
private fun Avatar(name: String?, photoUri: String?, size: Dp = AvatarSize) {
    val c = LocalDialerColors.current
    val initial = name?.firstOrNull { it.isLetter() }?.uppercaseChar()
    val (bg, fg) = if (initial == null) c.panel to c.inkMuted
                   else c.avatars[Math.floorMod(name.hashCode(), c.avatars.size)]
    // Square photos and initials
    Box(Modifier.size(size).clip(RectangleShape).background(bg), contentAlignment = Alignment.Center) {
        if (initial != null) Text(initial.toString(), color = fg, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        else Icon(Icons.Filled.Person, contentDescription = null, tint = fg)
        if (photoUri != null) {
            AsyncImage(model = photoUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        }
    }
}

@Composable
private fun CallTypeIcon(type: Int) {
    val c = LocalDialerColors.current
    val (icon, tint) = when (type) {
        // Outgoing blue, incoming green, missed red
        CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade to OutgoingBlue
        CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.AutoMirrored.Filled.CallMissed to c.missed
        CallLog.Calls.BLOCKED_TYPE -> Icons.Filled.Block to c.missed
        else -> Icons.AutoMirrored.Filled.CallReceived to c.call
    }
    Icon(icon, contentDescription = callTypeName(type), tint = tint, modifier = Modifier.size(16.dp))
}

/** Bright blue for outgoing-call arrows, the same in light and dark themes. */
private val OutgoingBlue = Color(0xFF1E90FF)

/**
 * Length of the most recent call, before the time: "45s", "2m 15s", "1h 04m".
 * Missed, declined and blocked calls say so in red; outgoing calls nobody answered say "No answer".
 */
@Composable
private fun CallDuration(r: RecentGroup) {
    val c = LocalDialerColors.current
    if (r.number.isBlank() && r.duration == 0L) return
    when {
        r.type == CallLog.Calls.MISSED_TYPE -> Text("Missed", color = c.missed, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
        r.type == CallLog.Calls.REJECTED_TYPE -> Text("Declined", color = c.missed, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
        r.type == CallLog.Calls.BLOCKED_TYPE -> Text("Blocked", color = c.missed, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
        r.duration <= 0L && r.type == CallLog.Calls.OUTGOING_TYPE ->
            Text("No answer", color = c.inkMuted, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
        r.duration > 0L -> Row(Modifier.padding(start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Schedule, contentDescription = "Duration", tint = c.inkMuted, modifier = Modifier.size(11.dp))
            Spacer(Modifier.width(3.dp))
            Text(formatDuration(r.duration), color = c.ink.copy(alpha = 0.8f), fontSize = 12.sp, maxLines = 1)
        }
    }
}

private fun formatDuration(seconds: Long): String = when {
    seconds < 60 -> "${seconds}s"
    seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
    else -> "${seconds / 3600}h ${"%02d".format((seconds % 3600) / 60)}m"
}

private fun callTypeName(type: Int) = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
    CallLog.Calls.MISSED_TYPE -> "Missed"
    CallLog.Calls.REJECTED_TYPE -> "Declined"
    CallLog.Calls.BLOCKED_TYPE -> "Blocked"
    else -> "Incoming"
}

@Composable
internal fun SectionHeader(text: String) {
    Text(
        text,
        color = LocalDialerColors.current.inkMuted,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 2.dp),
    )
}

@Composable
private fun ActionRow(icon: ImageVector, text: String, tint: Color? = null, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = tint ?: c.accent) }
        Spacer(Modifier.width(14.dp))
        Text(text, color = c.ink, fontSize = 16.sp)
    }
}

@Composable
private fun AccessCard(opensSettings: Boolean, onAllow: () -> Unit) {
    val c = LocalDialerColors.current
    Surface(
        color = c.panel,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Search contacts with the keypad", color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                if (opensSettings)
                    "Turn on Contacts, Call logs and Phone in this app's permissions, then come back."
                else
                    "Allow access to your contacts and call history to find people by name and see recent calls.",
                color = c.inkMuted, fontSize = 14.sp, lineHeight = 20.sp,
            )
            Spacer(Modifier.height(14.dp))
            Button(onClick = onAllow) { Text(if (opensSettings) "Open settings" else "Allow access") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActionsSheet(
    target: SheetTarget,
    prefs: Prefs,
    onEdit: () -> Unit,
    onSpeedDial: () -> Unit,
    onRemoveSpeedDial: (Int) -> Unit,
    onDelete: () -> Unit,
    onReadySms: () -> Unit,
    onReadyWa: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val c = LocalDialerColors.current
    val dial = prefs.speedDialFor(target.number)
    // Shown for call log rows only. Removes the call history entry, never the contact.
    @Composable
    fun DeleteRow() {
        if (target.callIds.isNotEmpty()) {
            val label = if (target.callIds.size == 1) "Delete from call log" else "Delete ${target.callIds.size} calls from call log"
            ActionRow(Icons.Filled.Delete, label, tint = c.missed) { onDismiss(); onDelete() }
        }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = LocalMenuLook.current.cardFill) {
        Column(Modifier.padding(bottom = 12.dp)) {
            Text(target.title, color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 24.dp))
            if (target.title != target.number && target.number.isNotBlank()) {
                Text(target.number, color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
            }
            Spacer(Modifier.height(8.dp))
            if (target.number.isBlank()) {
                Text("This caller hid their number.", color = c.inkMuted, fontSize = 15.sp, modifier = Modifier.padding(24.dp))
                DeleteRow()
                return@Column
            }
            ActionRow(Icons.Filled.Call, "Call") { Actions.call(context, withDialPrefix(target.number, prefs.dialPrefix)); onDismiss() }
            ActionRow(Icons.AutoMirrored.Filled.Message, "Send a message") { Actions.message(context, target.number); onDismiss() }
            ActionRow(Icons.Filled.Dialpad, "Edit number before calling") { onEdit(); onDismiss() }
            if (dial == null) {
                ActionRow(Icons.Filled.Speed, "Set speed dial") { onSpeedDial(); onDismiss() }
            } else {
                ActionRow(Icons.Filled.Speed, "Remove from speed dial ${dial.slot}") { onRemoveSpeedDial(dial.slot); onDismiss() }
            }
            ActionRow(Icons.AutoMirrored.Filled.Message, "Ready SMS\u2026") { onDismiss(); onReadySms() }
            if (onReadyWa != null) {
                ActionRow(Icons.AutoMirrored.Filled.Chat, "Ready WhatsApp\u2026", tint = WaGreen) { onDismiss(); onReadyWa() }
            }
            ActionRow(Icons.Filled.ContentCopy, "Copy number") { Actions.copy(context, target.number); onDismiss() }
            if (target.contactId != null) {
                ActionRow(Icons.Filled.Person, "Open contact") { Actions.openContact(context, target.contactId, target.lookupKey); onDismiss() }
            } else {
                ActionRow(Icons.Filled.PersonAdd, "Add to contacts") { Actions.addContact(context, target.number); onDismiss() }
                ActionRow(Icons.Filled.Public, "Look up number online") { Actions.lookUp(context, target.number, prefs.lookupUrl); onDismiss() }
            }
            DeleteRow()
        }
    }
}

/** Everyone on speed dial: tap a row to call, the cross to remove. */
@Composable
private fun SpeedDialListDialog(prefs: Prefs, onCall: (String) -> Unit, onRemove: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val dials = prefs.speedDials.values.sortedBy { it.slot }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Speed dial") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (dials.isEmpty()) {
                    Text(
                        "Nothing set yet. Long-press a contact and choose Set speed dial.",
                        color = c.inkMuted, fontSize = 15.sp, lineHeight = 21.sp,
                    )
                }
                for (d in dials) {
                    Row(
                        Modifier.fillMaxWidth().clickable { onCall(d.number) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${d.slot}", color = c.accent, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(40.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color = c.ink, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(d.number, color = c.inkMuted, fontSize = 13.sp, maxLines = 1)
                        }
                        IconButton(onClick = { onRemove(d.slot) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Remove ${d.name} from speed dial", tint = c.inkMuted)
                        }
                    }
                }
                if (dials.isNotEmpty()) {
                    Text(
                        "Long-press a key (2 to 9) to call. For 10 to 99, tap the first digit, then long-press the second.",
                        color = c.inkMuted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun SpeedDialDialog(target: SheetTarget, prefs: Prefs, onSave: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var input by rememberSaveable { mutableStateOf((2..99).firstOrNull { it !in prefs.speedDials }?.toString().orEmpty()) }
    val slot = input.toIntOrNull()
    val valid = slot != null && slot in 2..99
    val taken = slot?.let { prefs.speedDials[it] }?.takeIf { numberKey(it.number) != numberKey(target.number) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Speed dial for ${target.title}") },
        text = {
            Column {
                OutlinedTextField(
                    value = input,
                    onValueChange = { v -> input = v.filter { it.isDigit() }.take(2) },
                    label = { Text("Number from 2 to 99") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    when {
                        !valid -> "Choose a number from 2 to 99. 1 is kept for voicemail."
                        taken != null -> "This replaces ${taken.name} on $slot."
                        slot!! < 10 -> "To call, long-press $slot on the keypad."
                        else -> "To call, tap ${slot / 10}, then long-press ${slot % 10}."
                    },
                    color = if (taken != null) c.missed else c.inkMuted,
                    fontSize = 14.sp,
                )
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { slot?.let(onSave) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------- helpers ----------

private fun RecentGroup.title() = name ?: number.ifBlank { "Private number" }

private fun PhoneEntry.toTarget() = SheetTarget(name, number, contactId, lookupKey)

private fun RecentGroup.toTarget() = SheetTarget(title(), number, contact?.contactId, contact?.lookupKey, callIds)

private fun highlight(text: String, indices: IntArray, color: Color): AnnotatedString {
    if (indices.isEmpty()) return AnnotatedString(text)
    return buildAnnotatedString {
        append(text)
        // Marker-style: tinted background behind matched characters, bold accent text.
        // Spaces or dashes between two matched digits are filled in so the marker is one solid block.
        val style = SpanStyle(color = color, fontWeight = FontWeight.Bold, background = color.copy(alpha = 0.22f))
        val marked = indices.filter { it in text.indices }.sorted()
        for ((n, i) in marked.withIndex()) {
            addStyle(style, i, i + 1)
            val next = marked.getOrNull(n + 1) ?: continue
            if (next > i + 1 && text.substring(i + 1, next).none { it.isLetterOrDigit() }) addStyle(style, i + 1, next)
        }
    }
}

/** "11:05 am 22/09": the phone's time format (12 or 24 hour) and day/month; the year is added for older calls. */
private fun callTime(context: Context, time: Long): String {
    val date = Date(time)
    // "11:05am": no space before am/pm (Android may use a normal or a narrow space there)
    val timeText = AndroidDateFormat.getTimeFormat(context).format(date)
        .replace(Regex("[\\s\\u202F\\u00A0]+(?=[AaPp]\\.?[Mm])"), "")
    val then = Calendar.getInstance().apply { timeInMillis = time }
    val sameYear = then.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)
    val locale = Locale.getDefault()
    val pattern = AndroidDateFormat.getBestDateTimePattern(locale, if (sameYear) "ddMM" else "ddMMyy")
    return "$timeText ${SimpleDateFormat(pattern, locale).format(date)}"
}
