package com.t9dialer.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Extension
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.TextButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.AutoAwesome
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.Lifecycle
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.draw.alpha
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.layout.Box
import android.view.TextureView
import android.view.Surface
import android.media.MediaPlayer
import android.graphics.SurfaceTexture
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.t9dialer.app.R

const val APP_NAME = "Dialer NEXT"
private const val AUTHOR = "Sanjay Sachdeva"
private const val EMAIL = "san222@gmail.com"

@Composable
fun AboutScreen(onBack: () -> Unit, start: AboutPage = AboutPage.MAIN, onOpenPermissions: () -> Unit = {}) {
    val c = LocalDialerColors.current
    var page by rememberSaveable { mutableStateOf(start) }
    // Back from a page returns to About, unless the page was opened directly (from Settings)
    val goBack: () -> Unit = {
        if (page != AboutPage.MAIN && start == AboutPage.MAIN) { page = AboutPage.MAIN } else { onBack() }
    }
    BackHandler(onBack = goBack)
    val title = when (page) {
        AboutPage.MAIN -> "About"
        AboutPage.WHATS_NEW -> "What's new"
        AboutPage.PRIVACY -> "Privacy center"
        AboutPage.TERMS -> "Terms of service"
        AboutPage.LICENSES -> "Open source licenses"
        AboutPage.PUZZLE -> "Jigsaw puzzle"
    }
    // The puzzle has its own full screen (title bar, back handling)
    if (page == AboutPage.PUZZLE) {
        PuzzleScreen(onExit = goBack)
        return
    }
    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = goBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text(title, color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding()) {
            when (page) {
                AboutPage.MAIN -> AboutContent(onOpen = { page = it })
                AboutPage.WHATS_NEW -> WhatsNewPage()
                AboutPage.PRIVACY -> PrivacyPage(onOpenPermissions)
                AboutPage.TERMS -> TermsPage()
                AboutPage.LICENSES -> LicensesPage()
                AboutPage.PUZZLE -> Unit
            }
        }
    }
}

// ---------- What's new ----------

@Composable
private fun WhatsNewPage() {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val installed = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() }
    var showAll by rememberSaveable { mutableStateOf(false) }
    val shown = if (showAll) RELEASE_NOTES else RELEASE_NOTES.take(5)
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        shown.forEach { (ver, notes) ->
            Row(Modifier.padding(top = 14.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Version $ver", color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (ver == installed) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Installed", color = c.call, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.call.copy(alpha = 0.18f)).padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
            }
            notes.forEach { line ->
                val sub = line.startsWith("  ")
                Row(Modifier.padding(start = if (sub) 18.dp else 2.dp, top = 3.dp, bottom = 3.dp)) {
                    Text(if (sub) "\u2013" else "\u2022", color = c.accent, fontSize = 14.sp, modifier = Modifier.width(14.dp))
                    Text(line.trim(), color = c.ink.copy(alpha = 0.88f), fontSize = 14.sp, lineHeight = 20.sp)
                }
            }
        }
        if (!showAll && RELEASE_NOTES.size > 5) {
            TextButton(onClick = { showAll = true }, modifier = Modifier.padding(top = 10.dp)) {
                Text("Show earlier versions (${RELEASE_NOTES.size - 5})")
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Privacy center ----------

@Composable
private fun PrivacyPage(onOpenPermissions: () -> Unit) {
    val c = LocalDialerColors.current
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.call.copy(alpha = 0.15f)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = c.call, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Text("Your data stays on your phone. No accounts, ads, analytics or tracking.", color = c.ink, fontSize = 15.sp, lineHeight = 21.sp)
        }
        PrivacyCard(Icons.Filled.Visibility, "What the app reads",
            "Your contacts and call history, on your phone only, to search, show your calls and count how often you call people. Nothing is copied anywhere else.")
        PrivacyCard(Icons.AutoMirrored.Filled.Send, "What leaves your phone",
            "Only what you start: calls, text messages, WhatsApp chats and calls, your emergency message (and its location link, if turned on), and web pages you open with Look up number online.")
        PrivacyCard(Icons.Filled.Storage, "What the app saves",
            "Your settings, speed dials, ready messages and emergency set-up, in the app's private storage on this phone.")
        PrivacyCard(Icons.Filled.Key, "Permissions", "See and change what the app is allowed to do.", action = "Open permissions" to onOpenPermissions)
        PrivacyCard(Icons.Filled.DeleteForever, "Removing your data",
            "Uninstalling the app, or clearing its storage in Android settings, deletes everything it saved. Your contacts and call history belong to the phone and are not affected.")
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PrivacyCard(icon: ImageVector, title: String, body: String, action: Pair<String, () -> Unit>? = null) {
    val c = LocalDialerColors.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.inkMuted.copy(alpha = 0.10f)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(body, color = c.ink.copy(alpha = 0.85f), fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp))
        action?.let { (label, go) ->
            Text("$label \u203A", color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(6.dp)).clickable(onClick = go).padding(vertical = 2.dp))
        }
    }
}

// ---------- Terms of service ----------

private val TERMS = listOf(
    "Personal use" to "$APP_NAME is made for personal use. You may install and use it on your own devices.",
    "Provided as is" to "The app is provided as is, without warranties of any kind. The author is not liable for any loss or damage from using it, including missed, delayed or failed calls and messages.",
    "Emergencies" to "The emergency message is a convenience, not an emergency service. It depends on signal, permissions and your phone. If you are in danger, call your local emergency number (112 in India and Europe).",
    "Charges" to "Calls and text messages, including emergency and ready messages, are sent through your mobile network and may cost money under your plan.",
    "Other services" to "WhatsApp, Google Maps and your phone's Contacts and Phone apps are separate services with their own terms. $APP_NAME only opens them.",
    "Your responsibility" to "You are responsible for who you call or message and for the content of your messages.",
    "Changes" to "These terms may change with new versions of the app. The current version is always shown here.",
)

@Composable
private fun TermsPage() {
    val c = LocalDialerColors.current
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        TERMS.forEachIndexed { i, (heading, body) ->
            Text("${i + 1}. $heading", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
            Text(body, color = c.ink.copy(alpha = 0.85f), fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Text("Questions: $EMAIL", color = c.inkMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 20.dp, bottom = 20.dp))
    }
}

// ---------- Open source licenses ----------

private class OssLib(val name: String, val by: String, val url: String)

private val LIBS = listOf(
    OssLib("Kotlin standard library", "JetBrains", "https://github.com/JetBrains/kotlin"),
    OssLib("Kotlin coroutines", "JetBrains", "https://github.com/Kotlin/kotlinx.coroutines"),
    OssLib("Jetpack Compose", "Google (Android Open Source Project)", "https://developer.android.com/jetpack/compose"),
    OssLib("AndroidX Core, Activity and Lifecycle", "Google (Android Open Source Project)", "https://developer.android.com/jetpack/androidx"),
    OssLib("Material 3 and Material icons", "Google", "https://github.com/google/material-design-icons"),
    OssLib("Coil image loading", "Coil contributors", "https://github.com/coil-kt/coil"),
)

private const val APACHE_NOTICE =
    "Licensed under the Apache License, Version 2.0 (the \"License\"); you may not use this file except in compliance " +
        "with the License. You may obtain a copy of the License at\n\nhttps://www.apache.org/licenses/LICENSE-2.0\n\n" +
        "Unless required by applicable law or agreed to in writing, software distributed under the License is distributed " +
        "on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License " +
        "for the specific language governing permissions and limitations under the License."

@Composable
private fun LicensesPage() {
    val c = LocalDialerColors.current
    var open by remember { mutableStateOf<OssLib?>(null) }
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(
            "$APP_NAME is built with these open source components. Tap one to read its licence.",
            color = c.inkMuted, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        )
        LIBS.forEach { lib ->
            HorizontalDivider(thickness = 0.5.dp, color = c.inkMuted.copy(alpha = 0.2f))
            Row(
                Modifier.fillMaxWidth().clickable { open = lib }.padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(lib.name, color = c.ink, fontSize = 15.sp)
                    Text("${lib.by} \u00B7 Apache License 2.0", color = c.inkMuted, fontSize = 12.sp)
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = c.inkMuted)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    open?.let { lib ->
        AlertDialog(
            onDismissRequest = { open = null },
            title = { Text(lib.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Copyright ${lib.by}", fontSize = 13.sp)
                    Text(lib.url, fontSize = 13.sp, color = c.accent, modifier = Modifier.padding(vertical = 6.dp))
                    Text(APACHE_NOTICE, fontSize = 13.sp, lineHeight = 18.sp)
                }
            },
            confirmButton = { TextButton(onClick = { open = null }) { Text("Close") } },
        )
    }
}

/** Pages reachable from About. */
enum class AboutPage { MAIN, WHATS_NEW, PRIVACY, TERMS, LICENSES, PUZZLE }

/**
 * Video, app logo with name and version, credit and email; then (when [onOpen] is given)
 * What's new, Privacy center, Terms of service and Open source licenses. Shown on About and in Settings > About.
 */
@Composable
fun AboutContent(onOpen: ((AboutPage) -> Unit)? = null) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "Unknown"
    }
    Column(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        // Short looping video, with the still photo underneath until it starts (and if it can't play)
        AboutVideo(Modifier.width(230.dp).aspectRatio(480f / 586f).clip(RoundedCornerShape(18.dp)))
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(40.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(APP_NAME, color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Text("Version $version", color = c.inkMuted, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("This app was created by $AUTHOR.", color = c.ink, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
        // Shown as plain text (not a link)
        Text(EMAIL, color = c.ink, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
        if (onOpen != null) {
            Spacer(Modifier.height(14.dp))
            // Starts the jigsaw puzzle of the photo
            Row(
                Modifier.padding(horizontal = 32.dp).fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF7B3FBF), Color(0xFFE0457B))))
                    .clickable { onOpen(AboutPage.PUZZLE) },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                Icon(Icons.Filled.Extension, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("I am feeling bored", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            AboutLink(Icons.Filled.AutoAwesome, Color(0xFF2E7D5B), "What's new") { onOpen(AboutPage.WHATS_NEW) }
            AboutLink(Icons.Filled.Shield, Color(0xFF2547C9), "Privacy center") { onOpen(AboutPage.PRIVACY) }
            AboutLink(Icons.Filled.Description, Color(0xFF7B3FBF), "Terms of service") { onOpen(AboutPage.TERMS) }
            AboutLink(Icons.Filled.Code, Color(0xFF5D6B7E), "Open source licenses") { onOpen(AboutPage.LICENSES) }
        }
    }
}

/** A compact link row: small coloured icon tile, label, arrow. */
@Composable
private fun AboutLink(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    HorizontalDivider(thickness = 0.5.dp, color = c.inkMuted.copy(alpha = 0.2f))
    Row(
        // Slim rows so all four links fit comfortably under the video
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(tint), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(label, color = c.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = c.inkMuted, modifier = Modifier.size(20.dp))
    }
}

/** Holds the player so the screen's lifecycle can pause and resume it. */
private class LoopingPlayer {
    var player: MediaPlayer? = null
    var resumed = true
}

/**
 * Plays res/raw/about_video.mp4 silently on a loop. The still photo sits underneath and stays
 * visible until the first video frame is drawn, so it shows while loading or if the video can't play.
 * Pauses when the app goes to the background and stops when you leave About.
 * A TextureView (not a SurfaceView) is used so the rounded corners clip the video too.
 */
@Composable
private fun AboutVideo(modifier: Modifier) {
    var playing by remember { mutableStateOf(false) }
    val holder = remember { LoopingPlayer() }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { holder.resumed = false; runCatching { holder.player?.pause() } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { holder.resumed = true; runCatching { holder.player?.start() } }
    DisposableEffect(Unit) {
        onDispose { holder.player?.release(); holder.player = null }
    }

    Box(modifier) {
        Image(
            painterResource(R.drawable.about_photo),
            contentDescription = "Photo of $AUTHOR",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        AndroidView(
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                            val mp = MediaPlayer()
                            holder.player = mp
                            try {
                                mp.setDataSource(ctx, Uri.parse("android.resource://${ctx.packageName}/${R.raw.about_video}"))
                                mp.setSurface(Surface(texture))
                                mp.isLooping = true
                                mp.setVolume(0f, 0f)
                                mp.setOnInfoListener { _, what, _ ->
                                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) playing = true
                                    false
                                }
                                mp.setOnErrorListener { _, _, _ -> playing = false; true }
                                mp.setOnPreparedListener { if (holder.resumed) it.start() }
                                mp.prepareAsync()
                            } catch (_: Exception) {
                                playing = false
                            }
                        }

                        override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                            holder.player?.release()
                            holder.player = null
                            playing = false
                            return true
                        }

                        override fun onSurfaceTextureUpdated(texture: SurfaceTexture) {}
                    }
                }
            },
            modifier = Modifier.fillMaxSize().alpha(if (playing) 1f else 0f),
        )
    }
}
