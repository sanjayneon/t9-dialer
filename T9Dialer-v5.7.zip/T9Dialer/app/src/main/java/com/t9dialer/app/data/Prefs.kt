package com.t9dialer.app.data

import android.content.Context
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Choices offered under Vibrate duration. 0 means the phone's own tick. */
val VIBRATE_DURATIONS = listOf(0, 10, 20, 30, 40, 50, 75, 100, 150, 200)

fun vibrateLabel(ms: Int) = if (ms <= 0) "System default" else "$ms ms"

class SpeedDial(val slot: Int, val name: String, val number: String)

class EmergencyContact(val name: String, val number: String)

/** Visual style; changes looks only, never sizes or spacing. (A saved "APPLE" from 5.x loads as Classic.) */
enum class UiStyle(val label: String) {
    CLASSIC("Classic"),
    NEUMORPHIC("Neumorphic"),
    FLAT("Flat"),
    GLASS("Glassmorphic"),
}

/** What tapping a name in a list does (when One touch dialing is off). */
enum class TapAction(val label: String, val summary: String) {
    QUICK("Show quick actions", "Call, message, info and WhatsApp open under the name"),
    CONTACT("Open full contact", "Goes straight to the contact in your Contacts app"),
}

/** What the app shows when it opens, before you type anything. */
enum class HomeView(val label: String) {
    CALL_LOG("Call log"),
    CONTACTS("Contacts"),
    FAVOURITES("Favourites"),
    FREQUENT("Frequently called"),
}

const val DEFAULT_FONT_SIZE = 15

const val READY_COUNT = 5

/** Settings key read directly by the call guard in Actions. */
const val FORWARDING_CODES_KEY = "forwarding_codes"
val DEFAULT_READY_SMS = listOf(
    "I'm driving, will call you back.",
    "In a meeting, will call later.",
    "Reached safely.",
    "On my way, see you soon.",
    "Please call me when free.",
)
val DEFAULT_READY_WA = listOf(
    "Hi, how are you?",
    "I'm driving, will call you back.",
    "Can we talk later today?",
    "Reached safely.",
    "Please send me your location.",
)
val FONT_SIZE_RANGE = 12..28

/** How big the keypad's keys are drawn. */
enum class DialpadSize(val label: String, val scale: Float) {
    SMALL("Small", 0.85f),
    NORMAL("Normal", 1f),
    LARGE("Large", 1.15f),
    HUGE("Huge", 1.3f),
}

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
}

data class Prefs(
    /** Added in front of every number you call (left off numbers starting with + and codes like *123#). */
    val dialPrefix: String = "",
    /** Added in front of the number when you long-press the call button, e.g. +91. */
    val longPressPrefix: String = "",
    /** Web page for looking up an unknown number; {number} is replaced with it. */
    val lookupUrl: String = DEFAULT_LOOKUP_URL,
    val swipeActions: Boolean = true,
    /** Vibrate when keys are pressed. Off means no vibration anywhere in the app. */
    val vibrateOnTap: Boolean = true,
    /** Key tones when dialling. Off by default: keys only vibrate. When on, follows the phone's dial-pad tone setting. */
    val keyTones: Boolean = false,
    /** Key vibration length in milliseconds; 0 uses the phone's own short tick. */
    val vibrateMs: Int = 20,
    /** One touch dialing: tapping a name calls. Off (default) means tapping opens the contact. */
    val oneTouchDial: Boolean = false,
    /**
     * Allow the two safe call forwarding codes (*#21# check, ##002# stop all). Off by default: the user must
     * turn it on in Settings > Calling. Every other forwarding code is always blocked.
     */
    val forwardingCodes: Boolean = false,
    /** The first-launch permissions screen has been seen. */
    val setupDone: Boolean = false,
    val tapAction: TapAction = TapAction.QUICK,
    val cyrillicKeys: Boolean = false,
    val theme: ThemeMode = ThemeMode.DARK,
    /** Style of the main screen: top bar, lists, quick actions, keypad. */
    val mainStyle: UiStyle = UiStyle.CLASSIC,
    /** Style of Settings, menus and pop-ups; null means the same as the main screen. */
    val menuStyle: UiStyle? = UiStyle.CLASSIC,
    /** Let long names wrap onto a second line instead of being cut off with "…". */
    val multilineNames: Boolean = true,
    /** Show job title and company under names in lists. */
    val showOrg: Boolean = true,
    val dialpadSize: DialpadSize = DialpadSize.LARGE,
    /** Size of names in lists and search results, in sp; numbers and details scale with it. */
    val listFontSize: Int = DEFAULT_FONT_SIZE,
    val defaultView: HomeView = HomeView.CALL_LOG,
    val speedDials: Map<Int, SpeedDial> = emptyMap(),
    /** Digits typed before ## (or before pressing call) to send the emergency message. */
    val emergencyCode: String = "258",
    val emergencyMessage: String = "",
    val emergencyContacts: List<EmergencyContact> = emptyList(),
    /** 5 seconds to cancel before the message goes. */
    val emergencyCountdown: Boolean = true,
    val emergencyLocation: Boolean = false,
    /** Call the first emergency contact after the texts are sent. */
    val emergencyCall: Boolean = true,
    /** Ready messages: 5 sent instantly by SMS, 5 opened in WhatsApp with the text typed. */
    val readySms: List<String> = DEFAULT_READY_SMS,
    val readyWa: List<String> = DEFAULT_READY_WA,
) {
    val emergencyReady: Boolean
        get() = emergencyCode.isNotEmpty() && emergencyMessage.isNotBlank() && emergencyContacts.isNotEmpty()

    fun speedDialFor(number: String): SpeedDial? {
        val key = numberKey(number)
        return speedDials.values.firstOrNull { numberKey(it.number) == key }
    }

    companion object {
        const val DEFAULT_LOOKUP_URL = "https://www.google.com/search?q={number}"
    }
}

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    init {
        // Version 1.9 changed the defaults. Apply them once to phones upgrading from an older version;
        // after that, whatever the user picks is kept.
        if (sp.getInt("defaults_version", 0) < 2) {
            sp.edit {
                putString("theme", ThemeMode.DARK.name)
                putString("dialpad_size", DialpadSize.LARGE.name)
                putInt("list_font_size", DEFAULT_FONT_SIZE)
                putBoolean("multiline_names", true)
                putBoolean("show_org", true)
                putInt("defaults_version", 2)
            }
        }
        // Version 2.9 made 20 ms the default key vibration; applied once on upgrade
        if (sp.getInt("defaults_version", 0) < 3) {
            sp.edit {
                putInt("vibrate_ms", 20)
                putInt("defaults_version", 3)
            }
        }
    }

    private val _prefs = MutableStateFlow(read())
    val prefs: StateFlow<Prefs> = _prefs.asStateFlow()

    fun update(change: (Prefs) -> Prefs) {
        val next = change(_prefs.value)
        write(next)
        _prefs.value = next
    }

    private fun read(): Prefs {
        // 5.4 saved this as on; turn it off once for everyone, so forwarding codes need an explicit opt-in
        if (!sp.getBoolean("forwarding_off_by_default", false)) {
            sp.edit().putBoolean(FORWARDING_CODES_KEY, false).putBoolean("forwarding_off_by_default", true).apply()
        }
        val dials = HashMap<Int, SpeedDial>()
        for ((k, v) in sp.all) {
            if (!k.startsWith(SPEED_PREFIX) || v !is String) continue
            val slot = k.removePrefix(SPEED_PREFIX).toIntOrNull() ?: continue
            val parts = v.split('\n', limit = 2)
            if (parts.size == 2) dials[slot] = SpeedDial(slot, parts[0], parts[1])
        }
        val emergencyContacts = (0 until MAX_EMERGENCY).mapNotNull { i ->
            sp.getString("em_contact_$i", null)?.split('\n', limit = 2)?.takeIf { it.size == 2 }?.let { EmergencyContact(it[0], it[1]) }
        }
        return Prefs(
            dialPrefix = sp.getString("dial_prefix", "").orEmpty(),
            longPressPrefix = sp.getString("long_press_prefix", "").orEmpty(),
            lookupUrl = sp.getString("lookup_url", null) ?: Prefs.DEFAULT_LOOKUP_URL,
            swipeActions = sp.getBoolean("swipe_actions", true),
            vibrateOnTap = sp.getBoolean("vibrate_on_tap", true),
            keyTones = sp.getBoolean("key_tones", false),
            vibrateMs = sp.getInt("vibrate_ms", 20),
            oneTouchDial = sp.getBoolean("one_touch_dial", false),
            forwardingCodes = sp.getBoolean(FORWARDING_CODES_KEY, false),
            setupDone = sp.getBoolean("setup_done", false),
            tapAction = TapAction.entries.firstOrNull { it.name == sp.getString("tap_action", null) } ?: TapAction.QUICK,
            cyrillicKeys = sp.getBoolean("cyrillic_keys", false),
            theme = ThemeMode.entries.firstOrNull { it.name == sp.getString("theme", null) } ?: ThemeMode.DARK,
            mainStyle = UiStyle.entries.firstOrNull { it.name == sp.getString("main_style", null) } ?: UiStyle.CLASSIC,
            menuStyle = when (val v = sp.getString("menu_style", null)) {
                "SAME" -> null
                null -> UiStyle.CLASSIC
                else -> UiStyle.entries.firstOrNull { it.name == v } ?: UiStyle.CLASSIC
            },
            multilineNames = sp.getBoolean("multiline_names", true),
            showOrg = sp.getBoolean("show_org", true),
            listFontSize = sp.getInt("list_font_size", DEFAULT_FONT_SIZE).coerceIn(FONT_SIZE_RANGE),
            dialpadSize = DialpadSize.entries.firstOrNull { it.name == sp.getString("dialpad_size", null) } ?: DialpadSize.LARGE,
            defaultView = HomeView.entries.firstOrNull { it.name == sp.getString("default_view", null) } ?: HomeView.CALL_LOG,
            speedDials = dials,
            emergencyCode = sp.getString("em_code", null) ?: "258",
            emergencyMessage = sp.getString("em_message", "").orEmpty(),
            emergencyContacts = emergencyContacts,
            emergencyCountdown = sp.getBoolean("em_countdown", true),
            emergencyLocation = sp.getBoolean("em_location", false),
            emergencyCall = sp.getBoolean("em_call", true),
            readySms = List(READY_COUNT) { i -> sp.getString("ready_sms_$i", null) ?: DEFAULT_READY_SMS[i] },
            readyWa = List(READY_COUNT) { i -> sp.getString("ready_wa_$i", null) ?: DEFAULT_READY_WA[i] },
        )
    }

    private fun write(p: Prefs) {
        sp.edit {
            putString("dial_prefix", p.dialPrefix)
            putString("long_press_prefix", p.longPressPrefix)
            putString("lookup_url", p.lookupUrl)
            putBoolean("swipe_actions", p.swipeActions)
            putBoolean("vibrate_on_tap", p.vibrateOnTap)
            putBoolean("key_tones", p.keyTones)
            putInt("vibrate_ms", p.vibrateMs)
            putBoolean("one_touch_dial", p.oneTouchDial)
            putBoolean(FORWARDING_CODES_KEY, p.forwardingCodes)
            putBoolean("setup_done", p.setupDone)
            putString("tap_action", p.tapAction.name)
            putBoolean("cyrillic_keys", p.cyrillicKeys)
            putString("theme", p.theme.name)
            putString("main_style", p.mainStyle.name)
            putString("menu_style", p.menuStyle?.name ?: "SAME")
            putString("default_view", p.defaultView.name)
            putBoolean("multiline_names", p.multilineNames)
            putBoolean("show_org", p.showOrg)
            putString("dialpad_size", p.dialpadSize.name)
            putInt("list_font_size", p.listFontSize)
            for (k in sp.all.keys) if (k.startsWith(SPEED_PREFIX)) remove(k)
            for (d in p.speedDials.values) putString("$SPEED_PREFIX${d.slot}", "${d.name}\n${d.number}")
            putString("em_code", p.emergencyCode)
            putString("em_message", p.emergencyMessage)
            putBoolean("em_countdown", p.emergencyCountdown)
            putBoolean("em_location", p.emergencyLocation)
            putBoolean("em_call", p.emergencyCall)
            p.readySms.take(READY_COUNT).forEachIndexed { i, t -> putString("ready_sms_$i", t) }
            p.readyWa.take(READY_COUNT).forEachIndexed { i, t -> putString("ready_wa_$i", t) }
            for (i in 0 until MAX_EMERGENCY) remove("em_contact_$i")
            p.emergencyContacts.take(MAX_EMERGENCY).forEachIndexed { i, e -> putString("em_contact_$i", "${e.name}\n${e.number}") }
        }
    }

    companion object {
        private const val SPEED_PREFIX = "speed_"
        const val MAX_EMERGENCY = 4
    }
}

/** The number actually dialled for a normal tap. */
fun withDialPrefix(number: String, prefix: String): String {
    val n = number.trim()
    if (prefix.isBlank() || n.startsWith("+") || n.startsWith(prefix) || n.any { it == '*' || it == '#' }) return n
    return prefix + n
}

/** The number dialled when the call button is long-pressed: +91 and 098100 83013 give +9198100 83013. */
fun withLongPressPrefix(number: String, prefix: String): String {
    val n = number.trim()
    if (prefix.isBlank() || n.startsWith(prefix)) return n
    return if (prefix.startsWith("+") && n.startsWith("0")) prefix + n.drop(1) else prefix + n
}
