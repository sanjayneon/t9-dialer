package com.t9dialer.app.ui

import androidx.activity.compose.BackHandler
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import com.t9dialer.app.data.numberKey
import com.t9dialer.app.data.EmergencyContact
import com.t9dialer.app.data.AppPrefs
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.content.pm.PackageManager
import android.content.Intent
import android.content.ActivityNotFoundException
import android.app.Activity
import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.t9dialer.app.data.Prefs
import com.t9dialer.app.data.ThemeMode
import com.t9dialer.app.data.TapAction
import com.t9dialer.app.data.HomeView
import com.t9dialer.app.data.DialpadSize
import com.t9dialer.app.data.DEFAULT_FONT_SIZE
import com.t9dialer.app.data.FONT_SIZE_RANGE
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.input.KeyboardType
import kotlin.math.roundToInt
import com.t9dialer.app.data.VIBRATE_DURATIONS
import com.t9dialer.app.data.vibrateLabel
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView

private enum class TextSetting(val title: String, val help: String) {
    DialPrefix("Prefix for every call", "Added in front of each number you call. Left off numbers that start with + and codes like *123#."),
    LongPressPrefix("Prefix when you long-press call", "For example +91. If it starts with +, a leading 0 in the number is dropped."),
    Lookup("Look up unknown numbers", "Web address to open from an unknown number's menu. {number} is replaced with the number."),
    EmergencyMessage("Emergency message", "Sent as a text to your emergency contacts when you type the emergency code."),
}

private val SHORTCUTS = listOf(
    "Swipe the keypad down to hide it, up to show it.",
    "Swipe a row right to call, left to send a message.",
    "Tap a name for quick actions (call, message, info, WhatsApp), or set it to open the full contact. Tick One touch dialing to call instead.",
    "Tap \u2630 at the top left for Call log, Contacts, Favourites, Frequently called, Add contact and Settings.",
    "Number bar: tap or swipe to move the cursor. Long-press and drag across digits to select them, then Cut, Copy or Paste. Long-press without dragging to Paste or Select all.",
    "Long-press a row for more: speed dial, copy, edit before calling, delete from call log.",
    "Long-press 1 for voicemail, 0 for +.",
    "Long-press 2 to 9 to call a speed dial. For 10 to 99, tap the first digit, then long-press the second.",
    "Long-press # to open settings.",
    "Press 0 for a space between first and last name: 5646 0 36 finds John Doe, not John Smith.",
    "Type * in a search to stand for any letters: 5*3 finds J... D...",
    "Long-press call to dial with your long-press prefix.",
)

@Composable
fun SettingsScreen(vm: DialerViewModel, onBack: () -> Unit, onOpenSpeedDial: () -> Unit, onOpenSetup: () -> Unit) {
    val c = LocalDialerColors.current
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    var editing by rememberSaveable { mutableStateOf<TextSetting?>(null) }
    var choosingTheme by rememberSaveable { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    var choosingView by rememberSaveable { mutableStateOf(false) }
    var choosingSize by rememberSaveable { mutableStateOf(false) }
    var choosingTap by rememberSaveable { mutableStateOf(false) }
    var choosingFont by rememberSaveable { mutableStateOf(false) }
    var choosingDuration by rememberSaveable { mutableStateOf(false) }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val context = LocalContext.current
    val appVersion = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "Unknown"
    }
    var editingEmergencyCode by rememberSaveable { mutableStateOf(false) }
    val smsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    // Asks once for permission to send texts, when the emergency message is being set up
    val askSms: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            smsPermission.launch(Manifest.permission.SEND_SMS)
        }
    }
    val emergencyPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val picked = runCatching {
            context.contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) (cur.getString(0) ?: cur.getString(1)) to cur.getString(1) else null
            }
        }.getOrNull()
        val number = picked?.second
        if (picked != null && !number.isNullOrBlank()) {
            vm.updatePrefs { p ->
                if (p.emergencyContacts.any { numberKey(it.number) == numberKey(number) } || p.emergencyContacts.size >= AppPrefs.MAX_EMERGENCY) p
                else p.copy(emergencyContacts = p.emergencyContacts + EmergencyContact(picked.first, number))
            }
        }
    }

    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text("Settings", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(contentPadding = PaddingValues(bottom = navBottom + 24.dp)) {
            // Each section starts collapsed; tap its title to open it
            item(key = "h-General") { ExpandHeader("General", "General" in expanded) { expanded = expanded.toggle("General") } }
            if ("General" in expanded) {
                item { ValueRow("Permissions", "See what the app is allowed to do, and unlock blocked ones") { onOpenSetup() } }
                item { ValueRow("Default view", prefs.defaultView.label) { choosingView = true } }
            }

            item(key = "h-Appearance") { ExpandHeader("Appearance", "Appearance" in expanded) { expanded = expanded.toggle("Appearance") } }
            if ("Appearance" in expanded) {
                item { ValueRow("Theme", prefs.theme.label) { choosingTheme = true } }
                item { ValueRow("Dialpad size", prefs.dialpadSize.label) { choosingSize = true } }
                item {
                    ValueRow(
                        "Font size",
                        if (prefs.listFontSize == DEFAULT_FONT_SIZE) "$DEFAULT_FONT_SIZE (default)" else "${prefs.listFontSize} (default $DEFAULT_FONT_SIZE)",
                    ) { choosingFont = true }
                }
                item {
                    CheckboxRow(
                        "Multiline mode",
                        if (prefs.multilineNames) "Long names wrap onto a second line" else "Long names are cut off with \u2026",
                        prefs.multilineNames,
                    ) { on -> vm.updatePrefs { it.copy(multilineNames = on) } }
                }
                item {
                    CheckboxRow(
                        "Show company and job",
                        if (prefs.showOrg) "Job title and company show under each name" else "Only names and numbers are shown",
                        prefs.showOrg,
                    ) { on -> vm.updatePrefs { it.copy(showOrg = on) } }
                }
            }

            item(key = "h-Calling") { ExpandHeader("Calling", "Calling" in expanded) { expanded = expanded.toggle("Calling") } }
            if ("Calling" in expanded) {
                item { ValueRow(TextSetting.DialPrefix.title, prefs.dialPrefix.ifBlank { "None" }) { editing = TextSetting.DialPrefix } }
                item { ValueRow(TextSetting.LongPressPrefix.title, prefs.longPressPrefix.ifBlank { "None" }) { editing = TextSetting.LongPressPrefix } }
                item { ValueRow(TextSetting.Lookup.title, prefs.lookupUrl) { editing = TextSetting.Lookup } }
            }

            item(key = "h-Emergency") { ExpandHeader("Emergency", "Emergency" in expanded) { expanded = expanded.toggle("Emergency") } }
            if ("Emergency" in expanded) {
                item {
                    Note(
                        if (prefs.emergencyReady) "Type ${prefs.emergencyCode}## on the keypad, or ${prefs.emergencyCode} and the call button, to text your emergency contacts."
                        else "Set a message and at least one contact to turn this on."
                    )
                }
                item {
                    ValueRow(
                        "Emergency code",
                        if (prefs.emergencyCode.isEmpty()) "Off" else "${prefs.emergencyCode}##, or ${prefs.emergencyCode} and the call button",
                    ) { editingEmergencyCode = true }
                }
                item {
                    ValueRow("Emergency message", prefs.emergencyMessage.ifBlank { "Not set yet" }) {
                        askSms()
                        editing = TextSetting.EmergencyMessage
                    }
                }
                items(prefs.emergencyContacts.withIndex().toList(), key = { "em${it.index}" }) { (i, e) ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, color = c.ink, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(e.number, color = c.inkMuted, fontSize = 13.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            vm.updatePrefs { it.copy(emergencyContacts = it.emergencyContacts.filterIndexed { j, _ -> j != i }) }
                        }) { Icon(Icons.Filled.Close, contentDescription = "Remove ${e.name}", tint = c.inkMuted) }
                    }
                }
                if (prefs.emergencyContacts.size < AppPrefs.MAX_EMERGENCY) {
                    item {
                        ValueRow(
                            "Add emergency contact",
                            "${prefs.emergencyContacts.size} of ${AppPrefs.MAX_EMERGENCY} added",
                        ) {
                            askSms()
                            try { emergencyPicker.launch(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI)) } catch (_: ActivityNotFoundException) {}
                        }
                    }
                }
                item {
                    CheckboxRow("Countdown before sending", "5 seconds to cancel, in case it was typed by accident", prefs.emergencyCountdown) { on ->
                        vm.updatePrefs { it.copy(emergencyCountdown = on) }
                    }
                }
                item {
                    CheckboxRow("Add my location", "Adds a Google Maps link to where you are", prefs.emergencyLocation) { on ->
                        vm.updatePrefs { it.copy(emergencyLocation = on) }
                        if (on) locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }
                item {
                    CheckboxRow(
                        "Call first contact afterwards",
                        "Calls ${prefs.emergencyContacts.firstOrNull()?.name ?: "your first emergency contact"} once the texts are sent",
                        prefs.emergencyCall,
                    ) { on -> vm.updatePrefs { it.copy(emergencyCall = on) } }
                }
            }

            item(key = "h-Search and keypad") { ExpandHeader("Search and keypad", "Search and keypad" in expanded) { expanded = expanded.toggle("Search and keypad") } }
            if ("Search and keypad" in expanded) {
                item {
                    CheckboxRow(
                        "Vibrate on tap",
                        if (prefs.vibrateOnTap) "Keys vibrate when you press them" else "Silent: no vibration",
                        prefs.vibrateOnTap,
                    ) { on -> vm.updatePrefs { it.copy(vibrateOnTap = on) } }
                }
                item {
                    ValueRow(
                        "Vibrate duration",
                        if (prefs.vibrateOnTap) vibrateLabel(prefs.vibrateMs) else "Tick Vibrate on tap to choose",
                        enabled = prefs.vibrateOnTap,
                    ) { choosingDuration = true }
                }
                item {
                    ValueRow("Tapping a name", prefs.tapAction.label) { choosingTap = true }
                }
                item {
                    CheckboxRow(
                        "One touch dialing",
                        if (prefs.oneTouchDial) "Tap a name to call straight away"
                        else "Off: tapping a name does what's set in Tapping a name",
                        prefs.oneTouchDial,
                    ) { on -> vm.updatePrefs { it.copy(oneTouchDial = on) } }
                }
                item {
                    SwitchRow("Swipe rows to call or message", "Right to call, left to message", prefs.swipeActions) { on ->
                        vm.updatePrefs { it.copy(swipeActions = on) }
                    }
                }
                item {
                    SwitchRow("Russian letters on the keys", "Search finds English and Russian names either way", prefs.cyrillicKeys) { on ->
                        vm.updatePrefs { it.copy(cyrillicKeys = on) }
                    }
                }
            }

            item(key = "h-Speed dial") { ExpandHeader("Speed dial", "Speed dial" in expanded) { expanded = expanded.toggle("Speed dial") } }
            if ("Speed dial" in expanded) {
                item {
                    val set = prefs.speedDials.size
                    ValueRow(
                        "Edit speed dial",
                        if (set == 0) "Nothing set yet: tap to choose contacts for keys 2 to 9"
                        else "$set set: tap to add, change or remove",
                    ) { onOpenSpeedDial() }
                }
            }

            item(key = "h-Shortcuts") { ExpandHeader("Shortcuts", "Shortcuts" in expanded) { expanded = expanded.toggle("Shortcuts") } }
            if ("Shortcuts" in expanded) {
                items(SHORTCUTS) { Note(it) }
            }

            item(key = "h-About") { ExpandHeader("About", "About" in expanded) { expanded = expanded.toggle("About") } }
            if ("About" in expanded) {
                item { AboutContent() }
            }
        }
    }

    if (choosingDuration) {
        DurationDialog(
            current = prefs.vibrateMs,
            onPick = { ms -> vm.updatePrefs { it.copy(vibrateMs = ms) } },
            onDismiss = { choosingDuration = false },
        )
    }

    if (choosingFont) {
        FontSizeDialog(
            current = prefs.listFontSize,
            onSave = { size -> vm.updatePrefs { it.copy(listFontSize = size) }; choosingFont = false },
            onDismiss = { choosingFont = false },
        )
    }

    if (editingEmergencyCode) {
        EmergencyCodeDialog(
            current = prefs.emergencyCode,
            vm = vm,
            onSaved = { code -> vm.updatePrefs { it.copy(emergencyCode = code) }; editingEmergencyCode = false },
            onDismiss = { editingEmergencyCode = false },
        )
    }

    if (choosingTap) {
        AlertDialog(
            onDismissRequest = { choosingTap = false },
            title = { Text("Tapping a name") },
            text = {
                Column(Modifier.selectableGroup()) {
                    for (a in TapAction.entries) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .selectable(selected = a == prefs.tapAction, role = Role.RadioButton, onClick = {
                                    vm.updatePrefs { it.copy(tapAction = a) }
                                    choosingTap = false
                                })
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = a == prefs.tapAction, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(a.label, color = LocalDialerColors.current.ink, fontSize = 16.sp)
                                Text(a.summary, color = LocalDialerColors.current.inkMuted, fontSize = 13.sp)
                            }
                        }
                    }
                    Text(
                        "If One touch dialing is ticked, tapping a name calls instead.",
                        color = LocalDialerColors.current.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { choosingTap = false }) { Text("Cancel") } },
        )
    }

    if (choosingSize) {
        SizeDialog(
            current = prefs.dialpadSize,
            onPick = { size -> vm.updatePrefs { it.copy(dialpadSize = size) }; choosingSize = false },
            onDismiss = { choosingSize = false },
        )
    }

    if (choosingView) {
        ViewDialog(
            current = prefs.defaultView,
            onPick = { v -> vm.updatePrefs { it.copy(defaultView = v) }; choosingView = false },
            onDismiss = { choosingView = false },
        )
    }

    if (choosingTheme) {
        ThemeDialog(
            current = prefs.theme,
            onPick = { mode -> vm.updatePrefs { it.copy(theme = mode) }; choosingTheme = false },
            onDismiss = { choosingTheme = false },
        )
    }

    editing?.let { setting ->
        TextSettingDialog(setting, prefs, onSave = { value ->
            vm.updatePrefs {
                when (setting) {
                    TextSetting.DialPrefix -> it.copy(dialPrefix = value.trim())
                    TextSetting.LongPressPrefix -> it.copy(longPressPrefix = value.trim())
                    TextSetting.Lookup -> it.copy(lookupUrl = value.trim().ifBlank { Prefs.DEFAULT_LOOKUP_URL })
                    TextSetting.EmergencyMessage -> it.copy(emergencyMessage = value.trim())
                }
            }
            editing = null
        }, onDismiss = { editing = null })
    }
}

/** Type a size or drag the slider; the default is always shown, with a button to go back to it. */
@Composable
private fun FontSizeDialog(current: Int, onSave: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var size by remember { mutableIntStateOf(current) }
    var input by remember { mutableStateOf(current.toString()) }
    val typed = input.toIntOrNull()
    val valid = typed != null && typed in FONT_SIZE_RANGE
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Font size") },
        text = {
            Column {
                Text("Default size: $DEFAULT_FONT_SIZE", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Text size for names in Call log, Contacts and search results. Numbers and details grow or shrink with it.",
                    color = c.inkMuted, fontSize = 13.sp, lineHeight = 18.sp,
                )
                Spacer(Modifier.height(12.dp))
                // Live preview at the chosen size
                Surface(color = c.bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text("Shubham Mittal", color = c.ink, fontSize = size.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text("+91 99 58 959820", color = c.inkMuted, fontSize = (size * 13f / 16f).sp, maxLines = 1)
                    }
                }
                Slider(
                    value = size.toFloat(),
                    onValueChange = { v -> size = v.roundToInt(); input = size.toString() },
                    valueRange = FONT_SIZE_RANGE.first.toFloat()..FONT_SIZE_RANGE.last.toFloat(),
                    steps = FONT_SIZE_RANGE.last - FONT_SIZE_RANGE.first - 1,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { v ->
                            input = v.filter { it.isDigit() }.take(2)
                            input.toIntOrNull()?.takeIf { it in FONT_SIZE_RANGE }?.let { size = it }
                        },
                        label = { Text("Size") },
                        singleLine = true,
                        isError = !valid,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(110.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    TextButton(
                        enabled = size != DEFAULT_FONT_SIZE,
                        onClick = { size = DEFAULT_FONT_SIZE; input = DEFAULT_FONT_SIZE.toString() },
                    ) { Text("Use default ($DEFAULT_FONT_SIZE)") }
                }
                if (!valid) {
                    Text(
                        "Enter a size from ${FONT_SIZE_RANGE.first} to ${FONT_SIZE_RANGE.last}.",
                        color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onSave(size) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SizeDialog(current: DialpadSize, onPick: (DialpadSize) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dialpad size") },
        text = {
            Column(Modifier.selectableGroup()) {
                for (size in DialpadSize.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .selectable(selected = size == current, role = Role.RadioButton, onClick = { onPick(size) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = size == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        // Each option is written at roughly the size its digits will be
                        Text("5", color = c.ink, fontSize = 22.sp * size.scale, modifier = Modifier.width(30.dp))
                        Text(size.label, color = c.ink, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ViewDialog(current: HomeView, onPick: (HomeView) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Default view") },
        text = {
            Column(Modifier.selectableGroup()) {
                Text("What the app shows when it opens.", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                for (v in HomeView.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .selectable(selected = v == current, role = Role.RadioButton, onClick = { onPick(v) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = v == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(v.label, color = c.ink, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ThemeDialog(current: ThemeMode, onPick: (ThemeMode) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Theme") },
        text = {
            Column(Modifier.selectableGroup()) {
                for (mode in ThemeMode.entries) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .selectable(selected = mode == current, role = Role.RadioButton, onClick = { onPick(mode) }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = mode == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(mode.label, color = c.ink, fontSize = 16.sp)
                            if (mode == ThemeMode.SYSTEM) {
                                Text("Follows your phone's dark mode", color = c.inkMuted, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

/** Picking an option vibrates once at that length so you can feel it; the dialog stays open to compare. */
@Composable
private fun DurationDialog(current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val view = LocalView.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Vibrate duration") },
        text = {
            Column(Modifier.selectableGroup().verticalScroll(rememberScrollState())) {
                Text("Tap an option to feel it.", color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                for (ms in VIBRATE_DURATIONS) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .selectable(selected = ms == current, role = Role.RadioButton, onClick = {
                                onPick(ms)
                                if (ms <= 0) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                else vibrateFor(context, ms)
                            }),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = ms == current, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(vibrateLabel(ms), color = c.ink, fontSize = 16.sp)
                        if (ms <= 0) Text("  phone's own light tick", color = c.inkMuted, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

private fun Set<String>.toggle(name: String) = if (name in this) this - name else this + name

/** A section title you tap to open or close the settings under it. */
@Composable
private fun ExpandHeader(title: String, open: Boolean, onToggle: () -> Unit) {
    val c = LocalDialerColors.current
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = if (open) c.accent else c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(
                if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = if (open) "Close $title" else "Open $title",
                tint = c.inkMuted,
            )
        }
        HorizontalDivider(thickness = 0.5.dp, color = c.inkMuted.copy(alpha = 0.22f))
    }
}

/** 3 to 6 digits; ## is added when typing it. Must differ from the notes codes. */
@Composable
private fun EmergencyCodeDialog(current: String, vm: DialerViewModel, onSaved: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf(current) }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Emergency code") },
        text = {
            Column {
                Text("3 to 6 digits. Type them followed by ##, or press the call button after them.", color = c.inkMuted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { v -> code = v.filter { it.isDigit() }.take(6); error = null },
                    label = { Text("Code") },
                    suffix = { Text("##") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                error?.let { Text(it, color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(enabled = !checking, onClick = {
                if (code.length !in 3..6) {
                    error = "Use 3 to 6 digits."
                } else {
                    checking = true
                    scope.launch {
                        val clash = withContext(Dispatchers.Default) { vm.vault.isUsed("$code##") }
                        checking = false
                        if (clash) error = "Choose a different code." else onSaved(code)
                    }
                }
            }) { Text(if (checking) "Checking…" else "Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ValueRow(title: String, value: String, enabled: Boolean = true, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(title, color = if (enabled) c.ink else c.inkMuted.copy(alpha = 0.6f), fontSize = 16.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, color = c.inkMuted, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CheckboxRow(title: String, summary: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.ink, fontSize = 16.sp)
            Spacer(Modifier.height(2.dp))
            Text(summary, color = c.inkMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.width(12.dp))
        Checkbox(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SwitchRow(title: String, summary: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.ink, fontSize = 16.sp)
            Spacer(Modifier.height(2.dp))
            Text(summary, color = c.inkMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        color = LocalDialerColors.current.inkMuted,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
    )
}

@Composable
private fun TextSettingDialog(setting: TextSetting, prefs: Prefs, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    val initial = when (setting) {
        TextSetting.DialPrefix -> prefs.dialPrefix
        TextSetting.LongPressPrefix -> prefs.longPressPrefix
        TextSetting.Lookup -> prefs.lookupUrl
        TextSetting.EmergencyMessage -> prefs.emergencyMessage
    }
    var value by remember(setting) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(setting.title) },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    singleLine = setting != TextSetting.EmergencyMessage,
                    minLines = if (setting == TextSetting.EmergencyMessage) 3 else 1,
                )
                Spacer(Modifier.height(10.dp))
                Text(setting.help, color = c.inkMuted, fontSize = 14.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(value) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
