# Dialer NEXT

A fast T9 search dialer for Android, built in Kotlin and Jetpack Compose. Targets Android 16 (API 36), runs on Android 8.0 and newer.

Type on the keypad and it finds contacts by name, by initials, or by any part of their number, with the matched letters highlighted. Tap a result to call.

## What's new in 4.5

- Call log rows show how long the most recent call lasted (45s, 2m 15s, 1h 04m) before the time; missed, declined and blocked calls say so in red, and unanswered outgoing calls say No answer.

## What's new in 4.4

- About shows a short silent looping video (with the still photo as a fallback until it plays, or if it can't). It pauses when you leave the app.
- The collapsed keypad bar shows a thumbs-up picture at the far right.

## What's new in 4.3

- Tapping delete vibrates like the keys (follows Vibrate on tap and Vibrate duration; no dial tone).

## What's new in 4.2

- Number bar fixed: long numbers no longer slide under the delete button. The size is now worked out with the exact text style shown (including letter spacing), with a small gap kept before the delete button.
- Slimmer delete button (44dp) with a smaller, solid backspace icon.

## What's new in 4.1

- Quick actions are compact and part of the row: two slim lines of pill buttons (Call, SMS, Info; then WA call, WA chat, WA video), the same tint as the tapped row, no line in between. Tap the name again or any empty space to close.
- Photos sit inside the note at full width, where the cursor is, between lines of text. Long-press a photo to move or remove it; tap to view full screen.
- First-launch permissions screen: every permission with a tick, Allow all, and an Unlock in Settings button with steps for any Android blocks as restricted. Also in Settings > General > Permissions.

## What's new in 4.0

- Photos in hidden notes: add from the gallery (several at once), take one with the camera, or paste a copied photo. Photos are shrunk to about 2000 px, encrypted with the same two locks as the notes (code + hardware key), and stored one file each in private no-backup storage. Thumbnails show in the note and the list; tap for full screen. Screenshots stay blocked, including the photo viewer. Camera shots never touch the gallery. Originals picked or pasted from elsewhere stay where they were.
- Changing a notes code re-encrypts its photos too.
- The number bar fits 22+ digits: the number shrinks just enough to fit between the call and delete buttons and never slides under them.
- List photos sit at the far left (1dp from the edge), are a little bigger, and touch the divider line above.

## What's new in 3.9

- Emergency message (Settings > Emergency): write a message and pick up to 4 emergency contacts. Typing the emergency code followed by ##, or the code and the call button, texts them all. Optional 5-second countdown to cancel, optional Google Maps location link, and an optional follow-up call to the first contact (speaker off).
- Hidden notes: up to 10 per code (was 5).
- Hidden notes look like bright yellow sticky notes with dark text, much easier to read.

## What's new in 3.8

- Quick actions: tapping a name opens a box under it with the number, Call, Message and Info (opens the full contact). If the person uses WhatsApp, a green WhatsApp row adds Voice call, Chat and Video call. Unsaved numbers get Add contact and WhatsApp Chat.
- New setting, Search and keypad > Tapping a name: Show quick actions (default) or Open full contact. One touch dialing, if ticked, still calls.

## What's new in 3.7

- Hidden notes are much harder to break into:
  - The code is now part of the encryption: notes are encrypted with a key made from the code (PBKDF2, 120,000 rounds) inside a second layer locked to the phone's hardware keystore. Without the right code they can't be decrypted, even by someone in full control of the phone. The code is never stored.
  - The app is no longer debuggable, so computer developer tools can't read its files or drive it.
  - After 5 wrong codes, code checks pause silently: 30 seconds, doubling each time, up to an hour.
  - New codes need at least 8 digits (current codes keep working until changed).
  - Existing notes are re-encrypted automatically the first time each set is opened with its code.
- A forgotten code means those notes can't be recovered.

## What's new in 3.6

- New starting codes for the two sets of hidden notes. A code you've already changed inside the app is kept.

## What's new in 3.5

- About photo is bigger and shows the laptop.
- Hidden notes: typing a secret code on the keypad opens up to 5 private notes. Two separate codes open two separate sets of notes. Save & lock hides them again. Notes are encrypted with a key in Android's hardware keystore, kept in the app's private no-backup storage, and lock automatically when the app goes to the background. Codes (always ending in ##) can be changed from inside the notes and are stored only as salted hashes.

## What's new in 3.4

- Renamed to **Dialer NEXT**.
- Slimmer list rows: less space above and below each photo, so more rows fit.
- New photo on the About screen (same size).
- The collapsed keypad bar shows the same photo, small and round, at the far right instead of the thumbs-up.
- A Favourites star next to the search button above the number bar; both moved a little to the right.

## What's new in 3.3

- Speed dial page restyled to match the phone's own: "Assign contacts", key numbers at the top left, large round photos or initials, round + buttons with "Add" underneath, and names below each key.

## What's new in 3.2

- New Speed dial page (⋮ menu > Speed dial, or Settings > Speed dial > Edit speed dial): a 3 x 3 grid for keys 1 to 9. Key 1 stays voicemail. Tap the round + on an empty key to pick a contact; their photo then shows on the key. Tap a photo to call, change the contact or remove it. Speed dials 10 to 99 are listed underneath. Long-press dialling on the keypad is unchanged.

## What's new in 3.1

- Delete calls: long-press a call log row and choose Delete from call log (asks to confirm). Only the call history entry is removed, never the contact. Grouped rows like "Mum (3)" delete all calls in that group. Needs the Call logs permission to write, asked once.

## What's new in 3.0

- About now reads: "This app was created by Sanjay Sachdeva."

## What's new in 2.9

- Vibrate duration now defaults to 20 ms (applied once when upgrading; your later choice is kept).

## What's new in 2.8

- The keypad's handle row is only 5dp taller than before (not 14dp); the search button above the call button is a little smaller to fit.
- A small amber thumbs-up at the far right of the collapsed "Show keypad" bar.

## What's new in 2.7

- A search button on the keypad, in the handle row just above the call button. It opens keyboard search, same as the one in the top bar.

## What's new in 2.6

- A star (Favourites) button in the top bar, after Add contact. It fills in while Favourites is showing. Everything still fits on one line.

## What's new in 2.5

- The top bar fits everything on one line without scrolling: ☰, app icon, Call log, Contacts, Add contact, search and ⋮. Tab labels keep a fixed size so a large phone font can't push Contacts out of view.

## What's new in 2.4

- Colourful icons in the ☰ and ⋮ menus, one colour per item.
- Coloured Add contact (teal) and search (bright blue) icons in the top bar.

## What's new in 2.3

- Every build is now signed with the same key (app/signing/san-dialer.jks), so new versions install as updates. Builds before 2.3 each had a different random key; uninstall the old app once before installing 2.3.
- The email on the About screen is plain text, not a link.
- Top bar spacing: Add contact sits right after the tabs, with search and ⋮ pushed to the far right.

## What's new in 2.2

- An Add contact icon sits right beside the Contacts tab at the top.

## What's new in 2.1

- A thin blue outline runs around the keypad, from the slide handle down, and stays on the slim bar when the keypad is collapsed.

## What's new in 2.0

- Select part of the number in the number bar: long-press a digit and drag across. Letting go opens Cut, Copy, Paste over selection and Select all. Typing, delete or paste replace the selection.

## What's new in 1.9

- Renamed to **San Dialer NEXT**.
- Settings sections (General, Appearance, Calling, Search and keypad, Speed dial, Shortcuts, About) start collapsed; tap a title to open it. Settings > About shows the same details as the About screen.
- New defaults: Dark theme, Large dialpad, font size 15, Multiline mode on, Show company and job on. Applied once when upgrading; your later choices are kept.
- Speed dial in the ⋮ menu: see everyone on speed dial, tap to call, remove with the cross.

## What's new in 1.8

- 0 works as a space in name search, to tell apart people with the same first name: 5646 0 36 finds John Doe, and 5646 0 7 finds John Smith. Phone-number search still treats 0 as a digit.

## What's new in 1.7

- About screen in the ☰ menu: app name, version, maker, email and photo.
- The collapsed keypad bar no longer shows the typed number; it appears again when the keypad is expanded.

## What's new in 1.6

- The number bar is editable: a blinking cursor shows where the next digit goes. Tap the number to put the cursor there, or swipe left or right to slide it one digit at a time. Keys, delete and paste all work at the cursor.
- Paste adds at the cursor, so you can paste several times to build a longer number.

## What's new in 1.5

- Outgoing-call arrows are bright blue.
- Brighter lines under the key letters.
- A ⋮ menu at the top right, beside search: Favourites, Frequently called, Add contact, Settings.
- The top tabs are now just Call log and Contacts.

## What's new in 1.4

- Call log arrows are coloured: incoming green, outgoing blue, missed red.
- The call time moved to the number line, so names get the full width (30+ characters before wrapping).
- Smaller number line, slimmer rows and a slightly shorter keypad: 6 to 7 rows fit above the keypad.
- Square contact photos.
- Thicker line under the letters on the keys.

## What's new in 1.3

- **One touch dialing** (Settings, off by default). Off: tapping a name opens the contact; unsaved numbers open their options. On: tapping a name calls.
- Call log rows show the **time and date** ("11:05 am 22/09") instead of "10 mins ago".
- A **thin line** separates every row.
- A **thin line under the letters** on each key.
- Long-press **\*** now just types \*; switch keypad letters in Settings instead.
- New top bar: **☰ menu**, small blue app icon, and **Call log / Contacts / Favourites** tabs. The menu holds all four lists (including Frequently called), Add contact and Settings.
- The number bar fits **at least 16 digits**; the call and delete buttons are slimmer.
- **Long-press the number bar to paste** a number (or copy the typed one).
- Search matches are **highlighted with a tinted marker**, in both the Call log and Contacts sections.

## What it does

- **T9 name search.** Matches the start of any word ("363" finds John **Doe**), runs across words ("56463" finds **John D**oe), and matches initials ("53" finds **J**ohn **D**oe). English and Russian names both work, and accented letters match their plain form. Type `*` to stand for any letters: "5*3" finds J… D….
- **Number search.** Any part of a number matches, with or without the country code or a leading 0.
- **Two sections.** Matching call log entries come first, then contacts, ranked by match quality, how often you call them and how recently.
- **Home views.** Switch between Call log, Contacts, Favourites and Frequently called with the chips at the top. The app always opens on the one chosen in Settings > General > Default view (Call log unless you change it). Repeated calls are grouped ("Mum (3)") and missed calls are red.
- **Keyboard search.** The search icon at the top lets you type letters with your phone's keyboard instead.
- **Compact keypad** with the call button beside the number, leaving more room for results. Dial tones follow your phone's setting; key vibration has its own Vibrate on tap tick box and Vibrate duration (system default or 10 to 200 ms) in Settings.
- **Gestures.** Swipe the keypad down to hide it, up to show it. Swipe a row right to call, left to message.
- **Speed dial.** Long-press a contact, choose Set speed dial and pick 2 to 99. Long-press 2 to 9 to call; for 10 to 99, tap the first digit and long-press the second.
- **Key shortcuts.** Long-press 1 for voicemail, 0 for +, * to switch the keypad letters between English and Russian, # for settings. Long-press call to dial with your long-press prefix.
- **Tap a search result** to open the contact's details (or turn this off in Settings to call instead).
- **Long-press any row** to message, copy, edit the number before calling, set speed dial, open the contact, add an unknown number, or look it up online.
- **Settings.** A prefix for every call, a separate prefix on long-press of call (for example +91), the web address used to look up unknown numbers, swipe actions on or off, keypad letters, and your speed dials.
- Light and dark themes, edge-to-edge layout as Android 16 requires. Opens from `tel:` links.

## Install it on your phone

### Option A: Android Studio (recommended)

1. Install [Android Studio](https://developer.android.com/studio), open it, and choose **Open**, then pick this `T9Dialer` folder. Let Gradle sync finish (first time takes a few minutes). If Studio offers to upgrade the Android Gradle Plugin, accept.
2. On your phone, turn on Developer options: **Settings > About phone**, tap **Build number** seven times.
3. In **Settings > System > Developer options**, turn on **USB debugging** (or **Wireless debugging**).
4. Plug the phone in, accept the "Allow USB debugging?" prompt, pick the phone in Studio's device menu, and press **Run**.

### Option B: no Android Studio, build in the cloud

1. Create a new GitHub repository and upload this folder's contents to it.
2. The included workflow (`.github/workflows/build.yml`) runs automatically. Open the **Actions** tab, click the latest run, and download **t9-dialer-debug-apk** when it finishes.
3. Unzip it, copy `app-debug.apk` to your phone, and open it. Allow your file manager or browser to install unknown apps when asked.

### First launch

The app asks for Contacts, Call logs and Phone. Contacts powers name search, Call logs powers Recents, and Phone lets taps place the call immediately (without it, taps open the system dialer pre-filled).

If Android greys out a permission for a sideloaded app, open **App info** for T9 Dialer, tap the **⋮** menu and choose **Allow restricted settings**, then grant it again.

## How it's built

```
app/src/main/java/com/t9dialer/app/
  t9/T9.kt                 T9 key map, name and number matching, scoring (pure Kotlin, unit-tested)
  data/PhoneData.kt        Reads contacts and call log, groups recents, builds the search index
  data/Search.kt           Runs a query against the index and ranks results
  ui/DialerViewModel.kt    Keypad input, search results, refresh on resume
  data/Prefs.kt            Settings and speed dials, call prefixes
  ui/DialerApp.kt          Top bar, results sections, swipe actions, long-press sheet, speed dial dialog
  ui/Dialpad.kt            Keypad sheet and collapsed bar, swipe gestures, tones and haptics
  ui/SettingsScreen.kt     Settings and the list of shortcuts
  ui/Theme.kt              Colours for light and dark
  Actions.kt               Call, message, copy, open or add contact
```

Run the engine tests with `./gradlew testDebugUnitTest`.

## Not in this version

- **It doesn't replace the in-call screen.** Calls are handed to your phone's built-in call screen. Becoming the default phone app needs an `InCallService` implementation; that's the natural next step.
- No business directory or caller ID. The original pulls those from its own maps database, which isn't something to copy.
- No "vibrate when a call ends". An app can only see call state reliably when it is the default phone app; most phones' own Phone app already offers this.
- No "frequently called remover" (Android stopped keeping that list in Android 10) or calendar events for calls.
- No themes, wallpaper backgrounds or home screen widget yet.

## Before you publish it

Rename it, change the package name (`com.t9dialer.app`) and icon to your own, sign the release with your own keystore (it's signed with the debug key now so it installs easily), and read Google Play's policy on apps that request call log permissions: Play only allows them for apps that are the default dialer.
