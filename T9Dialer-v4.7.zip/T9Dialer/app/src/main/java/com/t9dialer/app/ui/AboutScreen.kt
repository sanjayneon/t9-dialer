package com.t9dialer.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.Lifecycle
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.draw.alpha
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.layout.Box
import android.view.TextureView
import android.view.Surface
import android.media.MediaPlayer
import android.graphics.SurfaceTexture
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.t9dialer.app.R

const val APP_NAME = "Dialer NEXT"
private const val AUTHOR = "Sanjay Sachdeva"
private const val EMAIL = "san222@gmail.com"

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text("About", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
        ) {
            AboutContent()
        }
    }
}

/** App name, version, maker, email and photo. Shown on the About screen and in Settings > About. */
@Composable
fun AboutContent() {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "Unknown"
    }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Short looping video, with the still photo underneath until it starts (and if it can't play)
        AboutVideo(Modifier.width(230.dp).aspectRatio(480f / 586f).clip(RoundedCornerShape(18.dp)))
        Spacer(Modifier.height(10.dp))
        Text(APP_NAME, color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Text("Version $version", color = c.inkMuted, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))
        Text(
            "This app was created by $AUTHOR.",
            color = c.ink, fontSize = 17.sp, textAlign = TextAlign.Center,
        )
        // Shown as plain text (not a link)
        Text(EMAIL, color = c.ink, fontSize = 17.sp)
    }
}

/** Holds the player so the screen's lifecycle can pause and resume it. */
private class LoopingPlayer {
    var player: MediaPlayer? = null
    var resumed = true
}

/**
 * Plays res/raw/about_video.mp4 silently on a loop. The still photo sits underneath and stays
 * visible until the first video frame is drawn, so it shows while loading or if the video can't play.
 * Pauses when the app goes to the background and stops when you leave About.
 * A TextureView (not a SurfaceView) is used so the rounded corners clip the video too.
 */
@Composable
private fun AboutVideo(modifier: Modifier) {
    var playing by remember { mutableStateOf(false) }
    val holder = remember { LoopingPlayer() }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { holder.resumed = false; runCatching { holder.player?.pause() } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { holder.resumed = true; runCatching { holder.player?.start() } }
    DisposableEffect(Unit) {
        onDispose { holder.player?.release(); holder.player = null }
    }

    Box(modifier) {
        Image(
            painterResource(R.drawable.about_photo),
            contentDescription = "Photo of $AUTHOR",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        AndroidView(
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                            val mp = MediaPlayer()
                            holder.player = mp
                            try {
                                mp.setDataSource(ctx, Uri.parse("android.resource://${ctx.packageName}/${R.raw.about_video}"))
                                mp.setSurface(Surface(texture))
                                mp.isLooping = true
                                mp.setVolume(0f, 0f)
                                mp.setOnInfoListener { _, what, _ ->
                                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) playing = true
                                    false
                                }
                                mp.setOnErrorListener { _, _, _ -> playing = false; true }
                                mp.setOnPreparedListener { if (holder.resumed) it.start() }
                                mp.prepareAsync()
                            } catch (_: Exception) {
                                playing = false
                            }
                        }

                        override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                            holder.player?.release()
                            holder.player = null
                            playing = false
                            return true
                        }

                        override fun onSurfaceTextureUpdated(texture: SurfaceTexture) {}
                    }
                }
            },
            modifier = Modifier.fillMaxSize().alpha(if (playing) 1f else 0f),
        )
    }
}
