package com.t9dialer.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.t9dialer.app.data.PhoneRepository

object Actions {

    /** Places the call directly if phone permission is granted, otherwise opens the system dialer pre-filled. */
    fun call(context: Context, number: String) {
        if (number.isBlank()) return
        // Call forwarding codes: only *#21# (check) and ##002# (stop all) may run, and only once turned on in Settings (off by default)
        val code = ForwardingCodes.codePart(number)
        if (code != null && ForwardingCodes.isForwarding(code)) {
            val allowed = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .getBoolean(com.t9dialer.app.data.FORWARDING_CODES_KEY, false) && code in ForwardingCodes.SAFE
            if (!allowed) {
                ForwardingCodes.blocked.value = code
                return
            }
        }
        val canCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        val action = if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL
        start(context, Intent(action, Uri.fromParts("tel", number, null)))
    }

    fun voicemail(context: Context) {
        val canCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        if (!canCall) {
            Toast.makeText(context, "Allow Phone permission to call voicemail", Toast.LENGTH_SHORT).show()
            return
        }
        start(context, Intent(Intent.ACTION_CALL, Uri.fromParts("voicemail", "", null)))
    }

    /** Opens the lookup page from settings with the number filled in. */
    fun lookUp(context: Context, number: String, urlTemplate: String) {
        val template = urlTemplate.ifBlank { com.t9dialer.app.data.Prefs.DEFAULT_LOOKUP_URL }
        val url = if ("{number}" in template) template.replace("{number}", Uri.encode(number))
                  else template + Uri.encode(number)
        start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    /** Opens a WhatsApp chat with an international number (digits only, no +). */
    /** Opens a WhatsApp chat; with [text], the message is already typed and only needs Send. */
    fun whatsappChat(context: Context, digits: String, text: String? = null) {
        val url = "https://wa.me/$digits" + if (text.isNullOrBlank()) "" else "?text=" + Uri.encode(text)
        start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(PhoneRepository.WHATSAPP))
    }

    /** Opens Messages to one number with [text] typed (used when SMS permission is off). */
    fun messageWithText(context: Context, number: String, text: String) =
        start(context, Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null)).putExtra("sms_body", text))

    /** Starts a WhatsApp voice or video call using the row WhatsApp added to the contact. */
    fun whatsappCall(context: Context, dataId: Long, video: Boolean) = start(
        context,
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(
                ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, dataId),
                if (video) PhoneRepository.WA_VIDEO else PhoneRepository.WA_VOICE,
            )
            .setPackage(PhoneRepository.WHATSAPP),
    )

    /** Opens the Messages app with several recipients and the text filled in (used if SMS permission is off). */
    fun composeToMany(context: Context, numbers: List<String>, text: String) = start(
        context,
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + numbers.joinToString(";") { Uri.encode(it) })).putExtra("sms_body", text),
    )

    fun message(context: Context, number: String) =
        start(context, Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null)))

    fun addContact(context: Context, number: String) =
        start(context, Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.PHONE, number)
        })

    fun openContact(context: Context, contactId: Long, lookupKey: String?) {
        val uri = if (lookupKey != null) ContactsContract.Contacts.getLookupUri(contactId, lookupKey)
                  else ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId)
        start(context, Intent(Intent.ACTION_VIEW, uri))
    }

    fun copy(context: Context, number: String) {
        val clipboard = context.getSystemService(ClipboardManager::class.java) ?: return
        clipboard.setPrimaryClip(ClipData.newPlainText("Phone number", number))
        // Android 13+ shows its own confirmation
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(context, "Number copied", Toast.LENGTH_SHORT).show()
    }

    fun openAppSettings(context: Context) = start(
        context,
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
    )

    private fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No app on this phone can do that", Toast.LENGTH_SHORT).show()
        } catch (_: SecurityException) {
            Toast.makeText(context, "Permission needed to do that", Toast.LENGTH_SHORT).show()
        }
    }
}

/**
 * Call forwarding (GSM/USSD) codes. Service codes: 21 all calls, 67 busy, 61 no answer, 62 unreachable,
 * 002 all forwarding, 004 all conditional. Prefixes: * activate, ** register, *# check, # deactivate, ## erase.
 */
object ForwardingCodes {
    /** The only two that may run: check all-call forwarding, and stop all forwarding. */
    val SAFE = setOf("*#21#", "##002#")

    private val pattern = Regex("""^(\*\*|\*#|\*|##|#)(21|61|62|67|002|004)(\*[0-9+*]*)*#$""")

    /** Set when a blocked code is dialled; the app shows a red warning screen while it is non-null. */
    val blocked = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    /** The part of a dialled number from its first * or #, without spaces (so a prefix can't hide a code). */
    fun codePart(number: String): String? {
        val clean = number.filterNot { it == ' ' || it == '-' || it == '(' || it == ')' }
        val start = clean.indexOfFirst { it == '*' || it == '#' }
        return if (start < 0) null else clean.substring(start)
    }

    fun isForwarding(code: String): Boolean = pattern.matches(code)
}
