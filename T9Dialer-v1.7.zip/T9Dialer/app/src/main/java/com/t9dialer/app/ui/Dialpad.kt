package com.t9dialer.app.ui

import android.content.Context
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import com.t9dialer.app.Actions
import androidx.compose.ui.unit.TextUnit
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import android.content.ClipboardManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.Settings
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.t9dialer.app.t9.T9Keys

private val ROWS = listOf("123", "456", "789", "*0#")

@Composable
fun DialpadPanel(
    query: String,
    display: String,
    cyrillic: Boolean,
    /** 1 = Normal; Small, Large and Huge scale the keys and their text. */
    scale: Float,
    onKey: (Char) -> Unit,
    onLongKey: (Char) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onCall: () -> Unit,
    onCallLong: () -> Unit,
    onPaste: (String) -> Unit,
    cursor: Int,
    onMoveCursor: (Int) -> Unit,
    onHide: () -> Unit,
) {
    val c = LocalDialerColors.current
    val letters = if (cyrillic) T9Keys.cyrillicLetters else T9Keys.latinLetters
    Surface(
        color = c.panel,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        shadowElevation = 12.dp,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalSwipe(onDown = onHide)
                .navigationBarsPadding()
                .padding(bottom = 10.dp)
        ) {
            Handle(onClickLabel = "Hide keypad", onClick = onHide)
            NumberBar(query, display, cursor, onMoveCursor, onCall, onCallLong, onBackspace, onClear, onPaste)
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                for (row in ROWS) {
                    Row(Modifier.fillMaxWidth()) {
                        for (key in row) DialKey(key, letters[key].orEmpty(), scale, onKey, onLongKey, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/** The keypad tucked away: a slim bar you tap or swipe up to bring it back. */
@Composable
fun CollapsedDialpad(query: String, display: String, onShow: () -> Unit) {
    val c = LocalDialerColors.current
    Surface(
        color = c.panel,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        shadowElevation = 12.dp,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalSwipe(onUp = onShow)
                .clickable(onClickLabel = "Show keypad", onClick = onShow)
                .navigationBarsPadding()
        ) {
            Handle(onClickLabel = null, onClick = null)
            Row(
                Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Dialpad, contentDescription = null, tint = c.accent)
                Spacer(Modifier.width(14.dp))
                // The typed number stays hidden while the keypad is tucked away; it shows again when expanded
                Text("Show keypad", color = c.inkMuted, fontSize = 16.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun Handle(onClickLabel: String?, onClick: (() -> Unit)?) {
    val c = LocalDialerColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(14.dp)
            .then(if (onClick != null) Modifier.clickable(onClickLabel = onClickLabel, onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(width = 36.dp, height = 4.dp).clip(CircleShape).background(c.inkMuted.copy(alpha = 0.35f)))
    }
}

/** Swipe down (or up) anywhere on the keypad sheet, keys included. */
private fun Modifier.verticalSwipe(onUp: (() -> Unit)? = null, onDown: (() -> Unit)? = null): Modifier =
    pointerInput(onUp, onDown) {
        val threshold = 48.dp.toPx()
        var total = 0f
        detectVerticalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = {
                if (total > threshold) onDown?.invoke()
                else if (total < -threshold) onUp?.invoke()
            },
        ) { change, amount ->
            total += amount
            change.consume()
        }
    }

/**
 * Full-width strip: call button flush at the left edge, the number in the middle,
 * delete flush at the right edge. The number shrinks as it grows so at least 16 digits fit.
 * Long-press the number area to paste a number or copy the typed one.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NumberBar(
    query: String,
    display: String,
    cursor: Int,
    onMoveCursor: (Int) -> Unit,
    onCall: () -> Unit,
    onCallLong: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onPaste: (String) -> Unit,
) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().height(56.dp).background(c.bg),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .width(56.dp)
                .combinedClickable(
                    enabled = query.isNotEmpty(),
                    onClickLabel = "Call",
                    onLongClickLabel = "Call with long-press prefix",
                    onLongClick = onCallLong,
                    onClick = onCall,
                ),
            contentAlignment = Alignment.Center,
        ) {
            // Dimmed until a number is typed
            Icon(
                Icons.Filled.Call,
                contentDescription = "Call",
                tint = if (query.isNotEmpty()) c.call else c.inkMuted.copy(alpha = 0.35f),
                modifier = Modifier.size(26.dp),
            )
        }
        BarDivider()
        Box(
            Modifier.weight(1f).fillMaxHeight(),
            contentAlignment = Alignment.Center,
        ) {
            if (query.isEmpty()) {
                Text(
                    "Type a name or number",
                    textAlign = TextAlign.Center, color = c.inkMuted, fontSize = 15.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) { detectTapGestures(onLongPress = { menuOpen = true }) },
                )
            } else {
                EditableNumber(
                    display = display,
                    raw = query,
                    cursor = cursor,
                    onMoveCursor = onMoveCursor,
                    onLongPress = { menuOpen = true },
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                val clip = remember(menuOpen) { clipboardText(context) }
                DropdownMenuItem(
                    // Pastes at the cursor, so it can be used again to add more digits
                    text = { Text("Paste number") },
                    enabled = !clip.isNullOrBlank(),
                    onClick = { menuOpen = false; clip?.let(onPaste) },
                )
                if (query.isNotEmpty()) {
                    DropdownMenuItem(
                        text = { Text("Copy number") },
                        onClick = { menuOpen = false; Actions.copy(context, display) },
                    )
                }
            }
        }
        BarDivider()
        Box(
            Modifier
                .fillMaxHeight()
                .width(56.dp)
                .then(
                    if (query.isNotEmpty())
                        Modifier
                            .combinedClickable(onClick = onBackspace, onLongClick = onClear, onLongClickLabel = "Clear all")
                            .semantics { contentDescription = "Delete" }
                    else Modifier
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.AutoMirrored.Outlined.Backspace,
                contentDescription = null,
                tint = if (query.isNotEmpty()) c.ink else c.inkMuted.copy(alpha = 0.35f),
                modifier = Modifier.size(24.dp),
            )
        }
    }
}

private fun isDialChar(ch: Char) = ch.isDigit() || ch == '+' || ch == '*' || ch == '#'

/** Position in the formatted text that sits after [raw] typed characters. */
private fun displayIndex(display: String, raw: Int): Int {
    if (raw <= 0) return display.indexOfFirst(::isDialChar).coerceAtLeast(0)
    var count = 0
    for ((i, ch) in display.withIndex()) {
        if (isDialChar(ch)) {
            count++
            if (count == raw) return i + 1
        }
    }
    return display.length
}

/** How many typed characters come before a position in the formatted text. */
private fun rawIndex(display: String, offset: Int): Int = display.take(offset).count(::isDialChar)

/**
 * The typed number with a blinking cursor. Tap to put the cursor there, swipe left or right
 * to slide it one digit at a time, long-press for paste and copy. Keys and paste go in at the cursor.
 */
@Composable
private fun EditableNumber(
    display: String,
    raw: String,
    cursor: Int,
    onMoveCursor: (Int) -> Unit,
    onLongPress: () -> Unit,
) {
    val c = LocalDialerColors.current
    // Fall back to the plain digits if formatting ever changed which characters are shown
    val shown = if (display.count(::isDialChar) == raw.length) display else raw
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val stepPx = with(LocalDensity.current) { 14.dp.toPx() }
    val currentCursor by rememberUpdatedState(cursor.coerceIn(0, raw.length))
    val currentShown by rememberUpdatedState(shown)
    val move by rememberUpdatedState(onMoveCursor)
    val longPress by rememberUpdatedState(onLongPress)
    val blink by rememberInfiniteTransition(label = "cursor").animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 1000
                1f at 0
                1f at 499
                0f at 500
                0f at 999
            },
            repeatMode = RepeatMode.Restart,
        ),
        label = "blink",
    )
    Text(
        shown,
        textAlign = TextAlign.Center,
        color = c.ink,
        fontSize = numberSize(shown.length),
        fontWeight = FontWeight.Light,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Clip,
        onTextLayout = { layout = it },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { pos ->
                        layout?.let { l ->
                            val offset = l.getOffsetForPosition(Offset(pos.x, l.size.height / 2f))
                            move(rawIndex(currentShown, offset))
                        }
                    },
                    onLongPress = { longPress() },
                )
            }
            .pointerInput(Unit) {
                var travelled = 0f
                var at = 0
                detectHorizontalDragGestures(
                    onDragStart = { travelled = 0f; at = currentCursor },
                ) { change, dx ->
                    change.consume()
                    travelled += dx
                    while (travelled >= stepPx) { travelled -= stepPx; at++; move(at) }
                    while (travelled <= -stepPx) { travelled += stepPx; at = (at - 1).coerceAtLeast(0); move(at) }
                }
            }
            .drawWithContent {
                drawContent()
                val l = layout ?: return@drawWithContent
                val idx = displayIndex(currentShown, currentCursor).coerceIn(0, currentShown.length)
                val r = l.getCursorRect(idx)
                drawLine(
                    color = c.accent.copy(alpha = blink),
                    start = Offset(r.left, r.top),
                    end = Offset(r.left, r.bottom),
                    strokeWidth = 2.dp.toPx(),
                )
            },
    )
}

/** Steps the number down in size so 16 digits (with spaces) still fit on one line. */
private fun numberSize(length: Int): TextUnit = when {
    length <= 12 -> 32.sp
    length <= 16 -> 26.sp
    length <= 20 -> 21.sp
    else -> 17.sp
}

private fun clipboardText(context: Context): String? = runCatching {
    val clip = context.getSystemService(ClipboardManager::class.java)?.primaryClip
    if (clip == null || clip.itemCount == 0) null else clip.getItemAt(0).coerceToText(context)?.toString()
}.getOrNull()

@Composable
private fun BarDivider() {
    Box(
        Modifier
            .fillMaxHeight()
            .padding(vertical = 12.dp)
            .width(1.dp)
            .background(LocalDialerColors.current.inkMuted.copy(alpha = 0.25f))
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DialKey(key: Char, letters: String, scale: Float, onKey: (Char) -> Unit, onLongKey: (Char) -> Unit, modifier: Modifier) {
    val c = LocalDialerColors.current
    val press by rememberUpdatedState(onKey)
    val longPress by rememberUpdatedState(onLongKey)
    Box(
        modifier
            .height(54.dp * scale)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 40.dp * scale),
                onLongClick = { longPress(key) },
                onClick = { press(key) },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(key.toString(), color = c.ink, fontSize = 30.sp * scale, lineHeight = 32.sp * scale, textAlign = TextAlign.End, modifier = Modifier.width(30.dp * scale))
            Spacer(Modifier.width(8.dp * scale))
            Column(Modifier.width(46.dp * scale)) {
                if (key == '1') {
                    Icon(Icons.Filled.Voicemail, contentDescription = "Long-press for voicemail", tint = c.inkMuted, modifier = Modifier.size(16.dp * scale))
                } else {
                    Text(letters, color = c.inkMuted, fontSize = 12.sp * scale, letterSpacing = 1.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
                }
                // Thin line under the letters, as on classic keypads
                if (key != '*' && key != '#') {
                    Spacer(Modifier.height(3.dp * scale))
                    Box(Modifier.fillMaxWidth().height(2.5.dp).background(c.ink.copy(alpha = 0.8f)))
                }
            }
        }
    }
}

/**
 * Haptic tick (only if Vibrate on tap is ticked) plus a DTMF tone,
 * following the phone's dial-pad-tone setting and silent mode.
 */
@Composable
fun rememberKeyFeedback(vibrate: Boolean, durationMs: Int): (Char) -> Unit {
    val context = LocalContext.current
    val view = LocalView.current
    val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 60) }.getOrNull() }
    DisposableEffect(tone) { onDispose { tone?.release() } }
    val tonesOn = remember {
        runCatching {
            Settings.System.getInt(context.contentResolver, Settings.System.DTMF_TONE_WHEN_DIALING, 1) == 1
        }.getOrDefault(false)
    }
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    return remember(tone, tonesOn, vibrate, durationMs) {
        { key: Char ->
            if (vibrate) {
                // System default is the phone's own light tick; otherwise vibrate for the chosen length
                if (durationMs <= 0) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                else vibrateFor(context, durationMs)
            }
            if (tonesOn && audio.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                dtmfTone(key)?.let { tone?.startTone(it, 120) }
            }
        }
    }
}

/** Stands in for the system's haptics when Vibrate on tap is off, so long-presses don't buzz either. */
object NoHaptics : HapticFeedback {
    override fun performHapticFeedback(hapticFeedbackType: HapticFeedbackType) = Unit
}

private fun dtmfTone(key: Char): Int? = when (key) {
    in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (key - '0')
    '*' -> ToneGenerator.TONE_DTMF_S
    '#' -> ToneGenerator.TONE_DTMF_P
    else -> null
}
