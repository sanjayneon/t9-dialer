package com.t9dialer.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.t9dialer.app.Actions

/** One thing the app needs, and the Android permissions behind it. */
private class Need(val title: String, val why: String, val icon: ImageVector, val permissions: List<String>)

private val NEEDS = listOf(
    Need("Contacts", "Find people by name", Icons.Filled.Contacts, listOf(Manifest.permission.READ_CONTACTS)),
    Need("Call history", "Call log, recent calls and deleting calls", Icons.Filled.History,
        listOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG)),
    Need("Phone calls", "Call straight from the app", Icons.Filled.Call, listOf(Manifest.permission.CALL_PHONE)),
    Need("Send SMS", "Emergency message", Icons.AutoMirrored.Filled.Message, listOf(Manifest.permission.SEND_SMS)),
    Need("Location", "Your location in the emergency message", Icons.Filled.LocationOn,
        listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)),
)

private enum class Status { ALLOWED, NOT_YET, BLOCKED }

private fun granted(context: Context, p: String) =
    ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

/**
 * Shown the first time the app opens (and from Settings > General > Permissions):
 * every permission with a tick once allowed, one button to ask for all of them, and
 * a way to unlock any that Android has blocked as "restricted" for an app installed from a file.
 */
@Composable
fun SetupScreen(onDone: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val activity = context as? Activity
    var asked by rememberSaveable { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }   // re-read statuses after a request or a trip to Settings

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        asked = true
        refresh++
    }
    BackHandler(onBack = onDone)

    val statuses = remember(refresh, asked) {
        NEEDS.map { need ->
            when {
                granted(context, need.permissions.first()) -> Status.ALLOWED
                // Asked already, still refused, and Android won't show its prompt again: blocked (often "restricted")
                asked && activity != null &&
                    need.permissions.none { ActivityCompat.shouldShowRequestPermissionRationale(activity, it) } -> Status.BLOCKED
                else -> Status.NOT_YET
            }
        }
    }
    val allAllowed = statuses.all { it == Status.ALLOWED }
    val anyBlocked = statuses.any { it == Status.BLOCKED }
    val missing = NEEDS.zip(statuses).filter { it.second != Status.ALLOWED }.flatMap { it.first.permissions }

    Column(
        Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Welcome to $APP_NAME", color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            if (allAllowed) "Everything is allowed. You're all set."
            else "Allow these so every feature works. You only need to do this once.",
            color = c.inkMuted, fontSize = 15.sp, lineHeight = 21.sp,
        )
        Spacer(Modifier.height(16.dp))
        NEEDS.zip(statuses).forEach { (need, status) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(need.icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(need.title, color = c.ink, fontSize = 16.sp)
                    Text(
                        if (status == Status.BLOCKED) "Blocked by Android" else need.why,
                        color = if (status == Status.BLOCKED) c.missed else c.inkMuted, fontSize = 13.sp,
                    )
                }
                when (status) {
                    Status.ALLOWED -> Icon(Icons.Filled.CheckCircle, contentDescription = "Allowed", tint = c.call)
                    Status.BLOCKED -> Icon(Icons.Filled.Lock, contentDescription = "Blocked", tint = c.missed)
                    Status.NOT_YET -> Icon(Icons.Filled.RadioButtonUnchecked, contentDescription = "Not allowed yet", tint = c.inkMuted)
                }
            }
            HorizontalDivider(thickness = 0.5.dp, color = c.inkMuted.copy(alpha = 0.2f))
        }
        Spacer(Modifier.height(16.dp))
        if (anyBlocked) {
            Text(
                "Android blocks some permissions for apps installed from a file. To unlock them: tap the button, " +
                    "then the \u22ee menu at the top right, then Allow restricted settings. Next, open Permissions and " +
                    "allow the ones marked blocked, then come back here.",
                color = c.ink, fontSize = 14.sp, lineHeight = 20.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(c.missed.copy(alpha = 0.12f)).padding(12.dp),
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { Actions.openAppSettings(context) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.missed, contentColor = c.bg),
                shape = RoundedCornerShape(12.dp),
            ) { Text("Unlock in Settings", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(8.dp))
        }
        if (!allAllowed && missing.isNotEmpty()) {
            Button(
                onClick = { request.launch(missing.distinct().toTypedArray()) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
                shape = RoundedCornerShape(12.dp),
            ) { Text(if (asked) "Ask again" else "Allow all", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
        if (allAllowed) {
            Button(
                onClick = onDone,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
                shape = RoundedCornerShape(12.dp),
            ) { Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        } else {
            TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                Text("Skip for now", color = c.inkMuted, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
