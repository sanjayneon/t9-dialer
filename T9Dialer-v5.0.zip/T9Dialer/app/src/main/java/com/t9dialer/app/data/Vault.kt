package com.t9dialer.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Two separate sets of hidden notes, each opened by its own keypad code. */
enum class Vault(val id: String, val defaultCode: String) {
    FIRST("a", "123456##"),
    SECOND("b", "654321##"),
}

/** A note: its text and the ids of any photos added to it (each photo is its own encrypted file). */
class SecretNote(val id: Long, val text: String, val updated: Long, val photos: List<String> = emptyList())

/**
 * An unlocked set of notes. Holds the key made from the code only while the notes are open;
 * drop it (by closing the notes screen) to lock them again.
 */
class VaultSession internal constructor(
    val vault: Vault,
    private val store: VaultStore,
    private var key: SecretKey,
    private var salt: ByteArray,
    notes: List<SecretNote>,
) {
    var notes: List<SecretNote> = notes
        private set

    fun save(list: List<SecretNote>) {
        notes = list
        store.write(vault, salt, key, list)
    }

    /** New code from digits (the part before ##). Slow on purpose; call off the main thread. Returns an error or null. */
    fun changeCode(digits: String): String? = store.changeCode(this, digits)

    /** Stores a prepared photo and its thumbnail, encrypted; returns the photo's id. Call off the main thread. */
    fun addPhoto(photo: ByteArray, thumb: ByteArray): String = store.writePhoto(vault, key, photo, thumb)

    /** The full photo, decrypted, or null. Call off the main thread. */
    fun photo(id: String): ByteArray? = store.readPhoto(vault, key, id, thumb = false)

    /** The small preview, decrypted, or null. Call off the main thread. */
    fun thumb(id: String): ByteArray? = store.readPhoto(vault, key, id, thumb = true)

    fun deletePhotos(ids: Collection<String>) = store.deletePhotos(vault, ids)

    internal fun rekey(newSalt: ByteArray, newKey: SecretKey) {
        // Photos are locked with the code too, so re-lock them with the new one first
        store.reencryptPhotos(vault, key, newKey)
        salt = newSalt
        key = newKey
        store.write(vault, salt, key, notes)
    }
}

/**
 * Hidden notes, protected in two layers:
 *  1. Inner: AES-256-GCM with a key made from the code (PBKDF2, 120,000 rounds, random salt).
 *     Without the right code the notes can't be decrypted, even by someone in full control of the phone.
 *  2. Outer: AES-256-GCM with a key locked in Android's hardware keystore, so a copied file is
 *     useless on any other device and every code guess has to be made, slowly, on this phone.
 * Files live in the app's private no-backup folder. The code itself is never stored anywhere.
 * After 5 wrong codes, code checks pause (30 seconds, doubling each time, up to an hour), silently.
 */
class VaultStore(private val context: Context) {

    private val sp = context.getSharedPreferences("vault", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    /** Tries [code] against both sets. Slow on purpose; call off the main thread. */
    fun open(code: String): VaultSession? {
        if (code.length <= 2 || !code.endsWith("##")) return null
        if (System.currentTimeMillis() < sp.getLong("lock_until", 0)) return null
        for (v in Vault.entries) {
            tryOpen(v, code)?.let {
                sp.edit().putInt("fails", 0).putLong("lock_until", 0).apply()
                return it
            }
        }
        val fails = sp.getInt("fails", 0) + 1
        val pause = if (fails < MAX_TRIES) 0L
                    else minOf(30_000L shl minOf(fails - MAX_TRIES, 7), 3_600_000L)
        sp.edit().putInt("fails", fails).putLong("lock_until", System.currentTimeMillis() + pause).apply()
        return null
    }

    private fun tryOpen(v: Vault, code: String): VaultSession? {
        val file = file(v)
        if (file.exists()) {
            val payload = try { hardwareDecrypt(file.readBytes()) } catch (_: Exception) { return null }
            if (payload.size < HEADER || !payload.copyOfRange(0, 4).contentEquals(MAGIC)) return null
            val salt = payload.copyOfRange(4, 20)
            val key = derive(code, salt)
            val plain = try { codeDecrypt(key, payload, 20) } catch (_: Exception) { return null }
            val notes = parse(plain)
            // Tidy up photo files no note refers to any more (e.g. left over from a crash)
            removeUnusedPhotos(v, notes.flatMap { it.photos }.toSet())
            return VaultSession(v, this, key, salt, notes)
        }
        // First time on this version: the old scheme (a stored code hash, or the starting code).
        // Re-encrypt the old notes with the code just typed, then remove the old copy.
        if (!legacyOpens(v, code)) return null
        val notes = legacyLoad(v)
        val salt = ByteArray(16).also { random.nextBytes(it) }
        val key = derive(code, salt)
        write(v, salt, key, notes)
        legacyFile(v).delete()
        sp.edit().remove("hash_${v.id}").remove("salt_${v.id}").apply()
        return VaultSession(v, this, key, salt, notes)
    }

    /** Whether [code] opens either set of notes (used to keep the emergency code different). Slow; call off the main thread. */
    fun isUsed(code: String): Boolean = Vault.entries.any { tryOpen(it, code) != null }

    internal fun changeCode(session: VaultSession, digits: String): String? {
        if (digits.length !in MIN_DIGITS..MAX_DIGITS || !digits.all { it.isDigit() }) {
            return "Use $MIN_DIGITS to $MAX_DIGITS digits."
        }
        val code = "$digits##"
        if (Vault.entries.any { it != session.vault && tryOpen(it, code) != null }) return "Choose a different code."
        val salt = ByteArray(16).also { random.nextBytes(it) }
        session.rekey(salt, derive(code, salt))
        return null
    }

    internal fun write(v: Vault, salt: ByteArray, key: SecretKey, notes: List<SecretNote>) {
        val json = JSONArray()
        notes.forEach { n ->
            json.put(
                JSONObject().put("id", n.id).put("text", n.text).put("updated", n.updated)
                    .put("photos", JSONArray().apply { n.photos.forEach { put(it) } })
            )
        }
        val inner = codeEncrypt(key, json.toString().toByteArray(Charsets.UTF_8))
        writeSafely(file(v), hardwareEncrypt(MAGIC + salt + inner))
    }

    /** Temporary file first, so a crash mid-save can't damage what was there. */
    private fun writeSafely(target: File, bytes: ByteArray) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    // ---------- photos: each one encrypted with the code key inside the hardware key ----------

    private fun photoDir(v: Vault) = File(context.noBackupFilesDir, "vault_${v.id}_photos").apply { mkdirs() }

    internal fun writePhoto(v: Vault, key: SecretKey, photo: ByteArray, thumb: ByteArray): String {
        val id = ByteArray(12).also { random.nextBytes(it) }.joinToString("") { "%02x".format(it) }
        val dir = photoDir(v)
        writeSafely(File(dir, "$id.t"), hardwareEncrypt(codeEncrypt(key, thumb)))
        writeSafely(File(dir, "$id.p"), hardwareEncrypt(codeEncrypt(key, photo)))
        return id
    }

    internal fun readPhoto(v: Vault, key: SecretKey, id: String, thumb: Boolean): ByteArray? = try {
        val f = File(photoDir(v), if (thumb) "$id.t" else "$id.p")
        codeDecrypt(key, hardwareDecrypt(f.readBytes()), 0)
    } catch (_: Exception) {
        null
    }

    internal fun deletePhotos(v: Vault, ids: Collection<String>) {
        val dir = photoDir(v)
        for (id in ids) { File(dir, "$id.p").delete(); File(dir, "$id.t").delete() }
    }

    internal fun reencryptPhotos(v: Vault, old: SecretKey, new: SecretKey) {
        photoDir(v).listFiles()?.forEach { f ->
            if (f.name.endsWith(".tmp")) { f.delete(); return@forEach }
            runCatching {
                val plain = codeDecrypt(old, hardwareDecrypt(f.readBytes()), 0)
                writeSafely(f, hardwareEncrypt(codeEncrypt(new, plain)))
            }
        }
    }

    private fun removeUnusedPhotos(v: Vault, keep: Set<String>) {
        photoDir(v).listFiles()?.forEach { f -> if (f.name.substringBefore('.') !in keep) f.delete() }
    }

    private fun parse(plain: ByteArray): List<SecretNote> = try {
        val json = JSONArray(String(plain, Charsets.UTF_8))
        List(json.length()) { i ->
            val o = json.getJSONObject(i)
            val photos = o.optJSONArray("photos")?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()
            SecretNote(o.getLong("id"), o.getString("text"), o.getLong("updated"), photos)
        }
    } catch (_: Exception) { emptyList() }

    private fun file(v: Vault) = File(context.noBackupFilesDir, "vault_${v.id}.v2")

    // ---------- keys ----------

    private fun derive(code: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(code.toCharArray(), salt, ROUNDS, 256)
        try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            return SecretKeySpec(bytes, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    private fun hardwareKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    // Each encrypted blob is a 12-byte IV followed by the ciphertext and tag.
    private fun hardwareEncrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(GCM)
        cipher.init(Cipher.ENCRYPT_MODE, hardwareKey())
        return cipher.iv + cipher.doFinal(plain)
    }

    private fun hardwareDecrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(GCM)
        cipher.init(Cipher.DECRYPT_MODE, hardwareKey(), GCMParameterSpec(128, data, 0, IV))
        return cipher.doFinal(data, IV, data.size - IV)
    }

    private fun codeEncrypt(key: SecretKey, plain: ByteArray): ByteArray {
        val iv = ByteArray(IV).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance(GCM)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(plain)
    }

    private fun codeDecrypt(key: SecretKey, data: ByteArray, offset: Int): ByteArray {
        val cipher = Cipher.getInstance(GCM)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data, offset, IV))
        return cipher.doFinal(data, offset + IV, data.size - offset - IV)
    }

    // ---------- version 3.5/3.6 format, read once to upgrade ----------

    private fun legacyFile(v: Vault) = File(context.noBackupFilesDir, "notes_${v.id}.bin")

    private fun legacyOpens(v: Vault, code: String): Boolean {
        val hash = sp.getString("hash_${v.id}", null) ?: return code == v.defaultCode
        val salt = sp.getString("salt_${v.id}", null) ?: return false
        val digest = MessageDigest.getInstance("SHA-256").digest((salt + code).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return hash == digest
    }

    private fun legacyLoad(v: Vault): List<SecretNote> {
        val f = legacyFile(v)
        if (!f.exists()) return emptyList()
        return try { parse(hardwareDecrypt(f.readBytes())) } catch (_: Exception) { emptyList() }
    }

    companion object {
        const val MAX_NOTES = 10
        const val MIN_DIGITS = 8
        const val MAX_DIGITS = 12
        private const val MAX_TRIES = 5
        private const val ROUNDS = 120_000
        private const val KEY_ALIAS = "dialer_next_notes"
        private const val GCM = "AES/GCM/NoPadding"
        private const val IV = 12
        private val MAGIC = byteArrayOf(0x44, 0x4E, 0x56, 0x32)   // "DNV2"
        private const val HEADER = 4 + 16 + IV + 16
    }
}
