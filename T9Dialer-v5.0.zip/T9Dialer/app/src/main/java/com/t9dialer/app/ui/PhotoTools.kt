package com.t9dialer.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.roundToInt

/** Turns pasted, picked or camera photos into a sharp but compact JPEG plus a small preview. */
object PhotoTools {
    private const val PHOTO_EDGE = 2000   // longest side of the stored photo, in pixels
    private const val THUMB_EDGE = 360

    fun readUri(context: Context, uri: Uri): ByteArray? =
        runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()

    /** A photo on the clipboard (copied from Gallery, WhatsApp, Chrome...), or null. */
    fun clipboardImage(context: Context): Uri? {
        val clip = context.getSystemService(ClipboardManager::class.java)?.primaryClip ?: return null
        for (i in 0 until clip.itemCount) {
            val uri = clip.getItemAt(i).uri ?: continue
            val type = runCatching { context.contentResolver.getType(uri) }.getOrNull()
                ?: if (clip.description.hasMimeType("image/*")) "image/*" else null
            if (type?.startsWith("image/") == true) return uri
        }
        return null
    }

    /** (photo, thumbnail) as JPEG bytes, or null if the data isn't an image. Slow; call off the main thread. */
    fun prepare(bytes: ByteArray): Pair<ByteArray, ByteArray>? {
        val big = decode(bytes, PHOTO_EDGE) ?: return null
        val photo = big.jpeg(85)
        val scale = THUMB_EDGE.toFloat() / max(big.width, big.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(big, (big.width * scale).roundToInt().coerceAtLeast(1), (big.height * scale).roundToInt().coerceAtLeast(1), true)
        } else big
        val thumb = small.jpeg(80)
        if (small !== big) small.recycle()
        big.recycle()
        return photo to thumb
    }

    private fun decode(bytes: ByteArray, edge: Int): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            // ImageDecoder also turns sideways camera photos the right way up
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val s = minOf(1f, edge.toFloat() / max(w, h))
                decoder.setTargetSize((w * s).roundToInt().coerceAtLeast(1), (h * s).roundToInt().coerceAtLeast(1))
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= edge) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            val s = minOf(1f, edge.toFloat() / max(bmp.width, bmp.height))
            if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).roundToInt(), (bmp.height * s).roundToInt(), true) else bmp
        }
    }.getOrNull()

    private fun Bitmap.jpeg(quality: Int): ByteArray =
        ByteArrayOutputStream().also { compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
}
