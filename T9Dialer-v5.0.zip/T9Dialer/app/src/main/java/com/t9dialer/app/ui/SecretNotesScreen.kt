package com.t9dialer.app.ui

import android.app.Activity
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.runtime.key
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File
import androidx.core.content.FileProvider
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Image
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Password
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.t9dialer.app.data.SecretNote
import com.t9dialer.app.data.VaultSession
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.t9dialer.app.data.VaultStore

/**
 * Hidden notes, opened by typing a secret code on the keypad. Up to 10 notes per code, each with text and photos.
 * "Save & lock" encrypts and hides everything again. The notes also lock themselves when
 * the app goes to the background, and the screen can't be captured while they're open.
 */
@Composable
fun SecretNotesScreen(session: VaultSession, onLock: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    var notes by remember { mutableStateOf(session.notes) }
    val scope = rememberCoroutineScope()
    var editingId by remember { mutableStateOf<Long?>(null) }   // null = list, NEW = new note
    // The open note as a column of pieces: text, photo, text, photo, ... text
    var blocks by remember { mutableStateOf<List<Block>>(emptyList()) }
    var focusKey by remember { mutableStateOf<Long?>(null) }      // text piece that last had the cursor
    var photoMenu by remember { mutableStateOf<Long?>(null) }     // photo whose long-press menu is open
    val keys = remember { longArrayOf(0) }
    fun nextKey() = ++keys[0]
    var addingPhoto by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<String?>(null) }          // photo shown full screen
    val thumbs = remember { mutableStateMapOf<String, ImageBitmap>() }  // decrypted previews, in memory only
    // True while the gallery or camera is open for us, so leaving the app briefly doesn't lock the notes
    var pickingOutside by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var changingCode by remember { mutableStateOf(false) }

    // No screenshots, screen recording or previews in the recent-apps screen while notes are open
    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun persist(list: List<SecretNote>) {
        notes = list
        session.save(list)
    }

    /** Saves whatever is in the editor (an empty note is simply not kept). */
    fun commitDraft() {
        val id = editingId ?: return
        val text = serialize(blocks).trimEnd()
        val photos = blocks.filterIsInstance<Block.Pic>().map { it.photo }
        val now = System.currentTimeMillis()
        val old = notes.firstOrNull { it.id == id }
        val empty = text.lines().all { it.isBlank() } && photos.isEmpty()
        // Photo files that are no longer part of this note
        val dropped = (old?.photos.orEmpty() - photos.toSet()) + (if (empty) photos else emptyList())
        persist(
            when {
                id == NEW && empty -> notes
                id == NEW -> notes + SecretNote(now, text, now, photos)
                empty -> notes.filterNot { it.id == id }
                else -> notes.map {
                    if (it.id == id && (it.text != text || it.photos != photos)) SecretNote(id, text, now, photos) else it
                }
            }
        )
        if (dropped.isNotEmpty()) session.deletePhotos(dropped)
    }

    fun openNote(note: SecretNote?) {
        blocks = toBlocks(note, ::nextKey)
        focusKey = null
        editingId = note?.id ?: NEW
    }

    /** Puts a photo where the cursor is (or at the end), splitting that text in two around it. */
    fun insertPhoto(photoId: String) {
        val list = blocks
        var idx = list.indexOfFirst { it.key == focusKey && it is Block.Txt }
        if (idx < 0) idx = list.lastIndex
        val t = list[idx] as Block.Txt
        val text = t.value.text
        val cut = if (t.key == focusKey) t.value.selection.start.coerceIn(0, text.length) else text.length
        val before = text.substring(0, cut).removeSuffix("\n")
        val after = text.substring(cut).removePrefix("\n")
        val afterKey = nextKey()
        blocks = list.take(idx) +
            Block.Txt(t.key, TextFieldValue(before, TextRange(before.length))) +
            Block.Pic(nextKey(), photoId) +
            Block.Txt(afterKey, TextFieldValue(after, TextRange(0))) +
            list.drop(idx + 1)
        focusKey = afterKey   // a second photo goes right after this one
    }

    fun removePhotoBlock(key: Long) { blocks = normalize(blocks.filterNot { it.key == key }, ::nextKey) }

    /** Moves a photo up or down past the text next to it. */
    fun movePhoto(key: Long, up: Boolean) {
        val list = blocks.toMutableList()
        val i = list.indexOfFirst { it.key == key }
        val j = if (up) i - 1 else i + 1
        if (i < 0 || j !in list.indices) return
        val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        blocks = normalize(list, ::nextKey)
    }

    /** Shrinks, encrypts and stores a photo, then adds it to the note being edited. */
    fun addPhoto(bytes: ByteArray?) {
        if (bytes == null) { Toast.makeText(context, "Couldn't read that photo", Toast.LENGTH_SHORT).show(); return }
        addingPhoto = true
        scope.launch {
            val id = withContext(Dispatchers.Default) {
                PhotoTools.prepare(bytes)?.let { (photo, thumb) -> session.addPhoto(photo, thumb) }
            }
            addingPhoto = false
            if (id == null) Toast.makeText(context, "That isn't a photo", Toast.LENGTH_SHORT).show()
            else insertPhoto(id)
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
        pickingOutside = false
        uris.forEach { uri -> addPhoto(PhotoTools.readUri(context, uri)) }
    }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        pickingOutside = false
        val f = cameraFile
        cameraFile = null
        if (ok && f != null) addPhoto(runCatching { f.readBytes() }.getOrNull())
        f?.delete()   // the unencrypted camera file is removed straight away
    }
    fun takePhoto() {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val f = File(dir, "shot.jpg")
        cameraFile = f
        pickingOutside = true
        runCatching { camera.launch(FileProvider.getUriForFile(context, "${context.packageName}.files", f)) }
            .onFailure { pickingOutside = false; Toast.makeText(context, "No camera app found", Toast.LENGTH_SHORT).show() }
    }

    fun saveAndLock() {
        commitDraft()
        editingId = null
        onLock()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { if (!pickingOutside) saveAndLock() }
    BackHandler {
        if (editingId != null) { commitDraft(); editingId = null } else saveAndLock()
    }

    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        if (editingId == null) {
            // ---------- list of notes ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { saveAndLock() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Lock and close", tint = c.ink) }
                Text("Notes", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box {
                    var menu by remember { mutableStateOf(false) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = c.inkMuted) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Change code") },
                            leadingIcon = { Icon(Icons.Filled.Password, contentDescription = null) },
                            onClick = { menu = false; changingCode = true },
                        )
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            ) {
                if (notes.isEmpty()) {
                    Text("No notes yet.", color = c.inkMuted, fontSize = 15.sp, modifier = Modifier.padding(vertical = 12.dp))
                }
                for (note in notes.sortedByDescending { it.updated }) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(NotePaper)
                            .clickable { openNote(note) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                    ) {
                        val lines = note.text.lines().filterNot { PHOTO_LINE.matches(it) }.filter { it.isNotBlank() }
                        Text(
                            lines.firstOrNull() ?: "Photo note",
                            color = NoteInk, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        val rest = lines.drop(1).joinToString(" ").trim()
                        if (rest.isNotEmpty()) {
                            Text(rest, color = NoteInkSoft, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (note.photos.isNotEmpty()) {
                            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                note.photos.take(3).forEach { id ->
                                    Thumb(id, session, thumbs, Modifier.padding(end = 6.dp).size(44.dp))
                                }
                                Text(
                                    if (note.photos.size == 1) "1 photo" else "${note.photos.size} photos",
                                    color = NoteInkSoft, fontSize = 12.sp,
                                )
                            }
                        }
                        Text(
                            DateUtils.getRelativeTimeSpanString(note.updated).toString(),
                            color = NoteInkSoft, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (notes.size < VaultStore.MAX_NOTES) {
                    OutlinedButton(onClick = { openNote(null) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("New note  (${notes.size} of ${VaultStore.MAX_NOTES})")
                    }
                } else {
                    Text(
                        "You have ${VaultStore.MAX_NOTES} notes, the most allowed. Delete one to add another.",
                        color = c.inkMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
            LockButton { saveAndLock() }
        } else {
            // ---------- one note ----------
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { commitDraft(); editingId = null }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Save and go back to notes", tint = c.ink)
                }
                Text(if (editingId == NEW) "New note" else "Note", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (editingId != NEW) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete note", tint = c.missed) }
                }
            }
            // The note itself: text with photos placed inside it, at full width
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NotePaper)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                val last = blocks.lastIndex
                blocks.forEachIndexed { i, b ->
                    key(b.key) {
                        when (b) {
                            is Block.Txt -> BasicTextField(
                                value = b.value,
                                onValueChange = { v -> blocks = blocks.map { if (it.key == b.key) Block.Txt(b.key, v) else it } },
                                textStyle = TextStyle(color = NoteInk, fontSize = 17.sp, lineHeight = 24.sp),
                                cursorBrush = SolidColor(NoteInk),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(if (i == last) Modifier.heightIn(min = 160.dp) else Modifier)
                                    .onFocusChanged { if (it.isFocused) focusKey = b.key },
                                decorationBox = { inner ->
                                    Box {
                                        if (blocks.size == 1 && b.value.text.isEmpty()) {
                                            Text("Write your note", color = NoteInkSoft, fontSize = 17.sp)
                                        }
                                        inner()
                                    }
                                },
                            )
                            is Block.Pic -> Box(Modifier.padding(vertical = 6.dp)) {
                                InlinePhoto(
                                    b.photo, session,
                                    onOpen = { viewing = b.photo },
                                    onMenu = { photoMenu = b.key },
                                )
                                DropdownMenu(expanded = photoMenu == b.key, onDismissRequest = { photoMenu = null }) {
                                    DropdownMenuItem(text = { Text("View full screen") }, onClick = { photoMenu = null; viewing = b.photo })
                                    if (i > 1 || (blocks[0] as? Block.Txt)?.value?.text?.isNotEmpty() == true) {
                                        DropdownMenuItem(text = { Text("Move up") }, onClick = { photoMenu = null; movePhoto(b.key, up = true) })
                                    }
                                    if (i < last - 1 || (blocks[last] as? Block.Txt)?.value?.text?.isNotEmpty() == true) {
                                        DropdownMenuItem(text = { Text("Move down") }, onClick = { photoMenu = null; movePhoto(b.key, up = false) })
                                    }
                                    DropdownMenuItem(text = { Text("Remove from note") }, onClick = { photoMenu = null; removePhotoBlock(b.key) })
                                }
                            }
                        }
                    }
                }
                if (addingPhoto) {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NoteInk, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                    }
                }
            }
            Text(
                "Photos go where the cursor is. Long-press a photo to move or remove it.",
                color = c.inkMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, top = 6.dp),
            )
            // Add photos: gallery, camera, or a photo copied to the clipboard
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                PhotoAction(Icons.Filled.PhotoLibrary, "Gallery") {
                    pickingOutside = true
                    gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                PhotoAction(Icons.Filled.PhotoCamera, "Camera") { takePhoto() }
                PhotoAction(Icons.Filled.ContentPaste, "Paste photo") {
                    val uri = PhotoTools.clipboardImage(context)
                    if (uri == null) Toast.makeText(context, "No photo on the clipboard. Copy one first.", Toast.LENGTH_SHORT).show()
                    else addPhoto(PhotoTools.readUri(context, uri))
                }
            }
            LockButton { saveAndLock() }
        }
    }

    viewing?.let { id ->
        PhotoViewer(id, session, onRemove = {
            blocks = normalize(blocks.filterNot { it is Block.Pic && it.photo == id }, ::nextKey)
            viewing = null
        }, onClose = { viewing = null })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this note?") },
            text = { Text("It can't be recovered.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = editingId
                    editingId = null
                    val photos = (notes.firstOrNull { it.id == id }?.photos.orEmpty() +
                        blocks.filterIsInstance<Block.Pic>().map { it.photo }).distinct()
                    persist(notes.filterNot { it.id == id })
                    session.deletePhotos(photos)
                }) { Text("Delete", color = c.missed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    if (changingCode) {
        ChangeCodeDialog(
            // Making a key from the code is slow on purpose, so it runs off the main thread
            onSave = { digits, result -> scope.launch { result(withContext(Dispatchers.Default) { session.changeCode(digits) }) } },
            onDismiss = { changingCode = false },
        )
    }
}

// ---------- a note as pieces: text and photos, in order ----------

private sealed class Block(val key: Long) {
    class Txt(key: Long, val value: TextFieldValue) : Block(key)
    class Pic(key: Long, val photo: String) : Block(key)
}

/** A photo is stored in the note's text as its own line, like ⟦photo:ab12…⟧, at the spot it appears. */
private val PHOTO_LINE = Regex("^\u27E6photo:([A-Za-z0-9]+)\u27E7$")
private fun photoLine(id: String) = "\u27E6photo:$id\u27E7"

private fun toBlocks(note: SecretNote?, nextKey: () -> Long): List<Block> {
    val out = mutableListOf<Block>()
    val lines = mutableListOf<String>()
    val placed = mutableSetOf<String>()
    for (line in note?.text.orEmpty().split("\n")) {
        val m = PHOTO_LINE.matchEntire(line)
        if (m != null) {
            out += Block.Txt(nextKey(), TextFieldValue(lines.joinToString("\n")))
            lines.clear()
            out += Block.Pic(nextKey(), m.groupValues[1])
            placed += m.groupValues[1]
        } else {
            lines += line
        }
    }
    out += Block.Txt(nextKey(), TextFieldValue(lines.joinToString("\n")))
    // Notes from version 4.0 kept photos separately; show those at the end
    note?.photos?.filterNot { it in placed }?.forEach { id ->
        out += Block.Pic(nextKey(), id)
        out += Block.Txt(nextKey(), TextFieldValue(""))
    }
    return normalize(out, nextKey)
}

private fun serialize(blocks: List<Block>): String = blocks.joinToString("\n") {
    when (it) {
        is Block.Txt -> it.value.text
        is Block.Pic -> photoLine(it.photo)
    }
}

/** Keeps the pieces as text, photo, text, photo, ... text: joins neighbouring texts, adds empty text between photos. */
private fun normalize(list: List<Block>, nextKey: () -> Long): List<Block> {
    val out = mutableListOf<Block>()
    for (b in list) {
        val prev = out.lastOrNull()
        when {
            b is Block.Txt && prev is Block.Txt -> {
                val a = prev.value.text
                val joined = when { a.isEmpty() -> b.value.text; b.value.text.isEmpty() -> a; else -> a + "\n" + b.value.text }
                out[out.lastIndex] = Block.Txt(prev.key, TextFieldValue(joined, TextRange(joined.length)))
            }
            b is Block.Pic && (prev == null || prev is Block.Pic) -> {
                out += Block.Txt(nextKey(), TextFieldValue(""))
                out += b
            }
            else -> out += b
        }
    }
    if (out.lastOrNull() !is Block.Txt) out += Block.Txt(nextKey(), TextFieldValue(""))
    return out
}

/** A photo at the full width of the note. Tap to view full screen, long-press for move and remove. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun InlinePhoto(id: String, session: VaultSession, onOpen: () -> Unit, onMenu: () -> Unit) {
    var bmp by remember(id) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(id) {
        bmp = withContext(Dispatchers.Default) { session.photo(id)?.let { decodeForNote(it) } }
    }
    val image = bmp
    val shape = RoundedCornerShape(10.dp)
    if (image == null) {
        Box(Modifier.fillMaxWidth().height(180.dp).clip(shape).background(NoteInk.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = NoteInk, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    } else {
        Image(
            image,
            contentDescription = "Photo in note",
            contentScale = ContentScale.FillWidth,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(image.width.toFloat() / image.height.coerceAtLeast(1))
                .clip(shape)
                .combinedClickable(onClick = onOpen, onLongClick = onMenu, onLongClickLabel = "Move or remove photo"),
        )
    }
}

/** Decodes a stored photo at about phone-screen width, using half the memory of a full-quality image. */
private fun decodeForNote(bytes: ByteArray): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1100) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
}

/** A small decrypted preview; loads in the background the first time it's shown. */
@Composable
private fun Thumb(id: String, session: VaultSession, cache: MutableMap<String, ImageBitmap>, modifier: Modifier) {
    val bmp = cache[id]
    LaunchedEffect(id) {
        if (cache[id] == null) {
            withContext(Dispatchers.Default) {
                session.thumb(id)?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
            }?.let { cache[id] = it }
        }
    }
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(NotePaper), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, contentDescription = "Photo", contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
    }
}

@Composable
private fun PhotoAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(24.dp))
        Text(label, color = c.inkMuted, fontSize = 12.sp)
    }
}

/** Full-screen photo with Close and Remove. The decrypted image only ever lives in memory. */
@Composable
private fun PhotoViewer(id: String, session: VaultSession, onRemove: () -> Unit, onClose: () -> Unit) {
    var bmp by remember(id) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(id) {
        bmp = withContext(Dispatchers.Default) {
            session.photo(id)?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
        }
    }
    // Its own window, so it needs its own no-screenshots flag
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val image = bmp
            if (image != null) {
                Image(image, contentDescription = "Photo", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp)) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, contentDescription = "Remove photo from note", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun LockButton(onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
        shape = RoundedCornerShape(14.dp),
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text("Save & lock", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** New code: digits only; "##" is always added at the end. [onSave] returns an error or null. */
@Composable
private fun ChangeCodeDialog(onSave: (String, (String?) -> Unit) -> Unit, onDismiss: () -> Unit) {
    val c = LocalDialerColors.current
    var code by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (done) "Code changed" else "Change code") },
        text = {
            if (done) {
                Text("From now on, type $code## on the keypad to open these notes. The old code no longer works.")
            } else {
                Column {
                    Text(
                        "Enter ${VaultStore.MIN_DIGITS} to ${VaultStore.MAX_DIGITS} digits. ## is added at the end automatically.",
                        color = c.inkMuted, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = code,
                        onValueChange = { v -> code = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("New code") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = again,
                        onValueChange = { v -> again = v.filter { it.isDigit() }.take(VaultStore.MAX_DIGITS); error = null },
                        label = { Text("Type it again") },
                        suffix = { Text("##") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    error?.let { Text(it, color = c.missed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = {
            if (done) {
                TextButton(onClick = onDismiss) { Text("OK") }
            } else {
                TextButton(enabled = !saving, onClick = {
                    if (code != again) {
                        error = "The two codes don't match."
                    } else {
                        saving = true
                        onSave(code) { problem ->
                            saving = false
                            error = problem
                            if (problem == null) done = true
                        }
                    }
                }) { Text(if (saving) "Saving…" else "Save") }
            }
        },
        dismissButton = { if (!done) TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private const val NEW = -1L

// Notes look like bright yellow sticky notes with dark text, easy to read on both themes
private val NotePaper = Color(0xFFFFF1B8)
private val NoteInk = Color(0xFF2B2410)
private val NoteInkSoft = Color(0xFF6B5B2E)
