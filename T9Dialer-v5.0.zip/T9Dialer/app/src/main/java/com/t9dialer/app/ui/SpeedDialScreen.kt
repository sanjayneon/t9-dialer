package com.t9dialer.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.t9dialer.app.Actions
import com.t9dialer.app.data.PhoneEntry
import com.t9dialer.app.data.SpeedDial
import com.t9dialer.app.data.numberKey
import com.t9dialer.app.data.withDialPrefix

/**
 * Speed dial page: a 3 x 3 grid for keys 1 to 9. Key 1 stays voicemail.
 * An empty key shows a round + that opens the contacts list; a filled key shows the
 * contact's photo, and tapping it lets you change or remove that speed dial.
 * Speed dials 10 to 99 (set from a contact's long-press menu) are listed underneath.
 */
@Composable
fun SpeedDialScreen(vm: DialerViewModel, onBack: () -> Unit) {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    var pickFor by rememberSaveable { mutableIntStateOf(0) }   // slot waiting for a picked contact
    var editing by remember { mutableStateOf<SpeedDial?>(null) }

    BackHandler(onBack = onBack)

    // Photos come from the phone's contacts, matched by number
    val byKey = remember(state) {
        HashMap<String, PhoneEntry>().apply { state.contactIndex.forEach { putIfAbsent(it.entry.key, it.entry) } }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val slot = pickFor
        pickFor = 0
        if (result.resultCode != Activity.RESULT_OK || uri == null || slot == 0) return@rememberLauncherForActivityResult
        val picked = runCatching {
            context.contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) (cur.getString(0) ?: cur.getString(1)) to cur.getString(1) else null
            }
        }.getOrNull()
        if (picked?.second.isNullOrBlank()) {
            Toast.makeText(context, "That contact has no phone number", Toast.LENGTH_SHORT).show()
        } else {
            vm.setSpeedDial(slot, picked!!.first, picked.second)
            vm.refresh()
        }
    }
    fun pickContact(slot: Int) {
        pickFor = slot
        try {
            picker.launch(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI))
        } catch (_: ActivityNotFoundException) {
            pickFor = 0
            Toast.makeText(context, "No contacts app found", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().background(LocalMenuLook.current.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink) }
            Text("Speed dial", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            Text(
                "Assign contacts",
                color = c.inkMuted, fontSize = 16.sp,
                modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 20.dp),
            )
            for (row in 0 until 3) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0 until 3) {
                        val slot = row * 3 + col + 1
                        Box(Modifier.weight(1f)) {
                            when {
                                slot == 1 -> VoicemailTile()
                                else -> {
                                    val d = prefs.speedDials[slot]
                                    if (d == null) EmptyTile(slot) { pickContact(slot) }
                                    else FilledTile(d, byKey[numberKey(d.number)]) { editing = d }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }

            val more = prefs.speedDials.values.filter { it.slot >= 10 }.sortedBy { it.slot }
            if (more.isNotEmpty()) {
                Text(
                    "Speed dials 10 to 99", color = c.inkMuted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp),
                )
                for (d in more) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { editing = d }.padding(horizontal = 4.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${d.slot}", color = c.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(40.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color = c.ink, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(d.number, color = c.inkMuted, fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
                Text(
                    "To call 10 to 99, tap the first digit on the keypad, then long-press the second.",
                    color = c.inkMuted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp),
                )
            }
        }
    }

    editing?.let { d ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Speed dial ${d.slot}") },
            text = {
                Column {
                    Text(d.name, color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Text(d.number, color = c.inkMuted, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    EditOption(Icons.Filled.Call, "Call now", c.call) {
                        editing = null
                        Actions.call(context, withDialPrefix(d.number, prefs.dialPrefix))
                    }
                    EditOption(Icons.Filled.SwapHoriz, "Change contact", c.accent) {
                        editing = null
                        pickContact(d.slot)
                    }
                    EditOption(Icons.Filled.Delete, "Remove from speed dial", c.missed) {
                        editing = null
                        vm.removeSpeedDial(d.slot)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { editing = null }) { Text("Close") } },
        )
    }
}

/**
 * One key on the grid, laid out like the phone's own speed dial page:
 * the key number at the top left, a large circle, and a label underneath.
 */
@Composable
private fun SpeedKey(slot: Int, label: String, onClick: () -> Unit, circle: @Composable () -> Unit) {
    val c = LocalDialerColors.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(KeyCircle)) {
            Text(
                "$slot", color = c.inkMuted, fontSize = 22.sp, fontWeight = FontWeight.Light,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 6.dp),
            )
            Box(Modifier.align(Alignment.Center).size(KeyCircle).clip(CircleShape), contentAlignment = Alignment.Center) {
                circle()
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            label, color = c.inkMuted, fontSize = 15.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 19.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

private val KeyCircle = 72.dp

@Composable
private fun VoicemailTile() {
    val c = LocalDialerColors.current
    val context = LocalContext.current
    SpeedKey(1, "Voicemail", onClick = {
        Toast.makeText(context, "1 is kept for voicemail: long-press 1 to call it", Toast.LENGTH_SHORT).show()
    }) {
        Box(Modifier.fillMaxSize().background(c.inkMuted.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Voicemail, contentDescription = null, tint = c.inkMuted, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun EmptyTile(slot: Int, onAdd: () -> Unit) {
    val c = LocalDialerColors.current
    SpeedKey(slot, "Add", onClick = onAdd) {
        // Plain round + button
        Box(Modifier.fillMaxSize().background(c.panel), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Add, contentDescription = "Add speed dial $slot", tint = c.inkMuted, modifier = Modifier.size(36.dp))
        }
    }
}

@Composable
private fun FilledTile(d: SpeedDial, contact: PhoneEntry?, onEdit: () -> Unit) {
    val c = LocalDialerColors.current
    SpeedKey(d.slot, d.name, onClick = onEdit) {
        // Round contact photo, or a coloured circle with their initial
        val initial = d.name.firstOrNull { it.isLetter() }?.uppercaseChar()
        val (bg, fg) = c.avatars[Math.floorMod(d.name.hashCode(), c.avatars.size)]
        Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
            Text(initial?.toString() ?: "#", color = fg, fontSize = 32.sp, fontWeight = FontWeight.Normal)
            if (contact?.photoUri != null) {
                AsyncImage(model = contact.photoUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
            }
        }
    }
}

@Composable
private fun EditOption(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    val c = LocalDialerColors.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Text(label, color = c.ink, fontSize = 16.sp)
    }
}
