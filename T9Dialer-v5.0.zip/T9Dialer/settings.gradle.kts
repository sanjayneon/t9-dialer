pluginManagement {
    repositories {
        google()
        // Google's official copy of Maven Central, tried first: if Maven Central refuses the
        // GitHub build machine (403 Forbidden), the build carries on from here.
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
    }
}
rootProject.name = "T9Dialer"
include(":app")
